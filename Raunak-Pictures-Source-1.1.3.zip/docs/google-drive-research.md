# Google Drive and Android backup references

- Google Drive API supports upload/download and requires OAuth 2.0 for access to user-owned Drive. Drive API overview: https://developers.google.com/workspace/drive/api/guides/about-sdk
- Google OAuth requires platform-appropriate OAuth client credentials, user authorization/consent, scoped access token, and token refresh as needed: https://developers.google.com/identity/protocols/oauth2
- `drive.appdata` is a non-sensitive scope for the hidden `appDataFolder`; contents are not visible in normal Drive UI and are accessible only to the creating app. https://developers.google.com/workspace/drive/api/guides/appdata
- Drive API standard use is currently available at no additional cost; API usage limits apply and user's Drive storage constraints remain relevant. https://developers.google.com/workspace/drive/api/guides/limits
- Android Auto Backup uses the user's Google Drive account and has a 25 MB per-app limit; scheduling is system-controlled (at least 24 hours since the previous backup, idle, connected conditions) and restore normally happens during install/device setup. It is not per-record immediate sync. https://developer.android.com/identity/data/autobackup

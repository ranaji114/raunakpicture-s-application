import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.raunakpictures.studiomanagement',
  appName: 'Raunak Pictures',
  webDir: 'dist'
};

export default config;

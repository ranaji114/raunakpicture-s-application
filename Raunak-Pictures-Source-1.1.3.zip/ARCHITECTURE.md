# Raunak Pictures — Offline-first Android architecture

## Overview

The current black-and-gold React/Capacitor interface remains in place. On Android, all app data operations cross the `OfflineData` Capacitor bridge and commit to Room before the UI is told that a write succeeded. The browser/PWA build keeps its local adapter for preview and browser use; it is not the APK’s source of truth. A one-time launch migration imports the previous APK’s localStorage arrays/logo into Room and then removes those legacy keys after Room has accepted them.

The Android data path is:

```text
React screen → src/services/storage.ts → OfflineData Capacitor plugin
             → StudioRepository → Room (local commit)
             → unique WorkManager request → DriveSyncWorker → Drive API v3 appDataFolder
```

No custom backend or Firebase database is used. The Room database remains usable without an account, Wi-Fi or mobile data.

## Room schema

`AppDatabase` is `raunak-pictures.db`, Room schema version 1. The `sync_records` table uses the composite key `(recordType, id)` and stores:

| Column | Meaning |
| --- | --- |
| `recordType` | `booking`, `event`, `service`, `payment`, or `purchase` |
| `id` | Stable ID supplied by the app UI |
| `bookingId` | Parent booking ID for child/purchase rows, nullable |
| `payloadJson` | Complete typed record JSON; bookings also retain their nested UI data |
| `updatedAt` | UTC ISO-8601 timestamp used for conflict resolution |
| `sync_status` | Exactly `PENDING`, `SYNCED`, or `FAILED` |
| `deletedAt` | Nullable tombstone timestamp; deletion is synced instead of erasing the row |

The separate `settings` table stores `(key,value,updatedAt,syncStatus)`; this covers the custom logo as well as future settings. A `data_migrations` marker makes import of old WebView data one-time. `StudioRepository` wraps related mutations in Room transactions. Booking, event, service and payment data are independently represented in Room, allowing each row to carry its own synchronization state. Payload JSON preserves the existing UI’s field names and backward compatibility.

## Local mutation behavior

Create, edit, cancel, restore, payment and purchase changes run through `StudioRepository`. The database mutation is committed before the Capacitor promise resolves. The plugin then requests unique WorkManager work. Delete operations create timestamped tombstones so that a later sync can propagate the deletion to Drive; they do not remove local data immediately. If upload fails, Room records remain on-device and are set to `FAILED` (or remain `PENDING` for an authorization requirement).

The service imports old localStorage data only during startup migration. For all subsequent Android loads and writes it calls the native bridge. `BackupRestore` calls Room export/import on Android. The old JSON backup format shipped with the prior localStorage APK is also accepted and converted into version-1 records.

## Drive synchronization

`SyncScheduler` creates unique, connected-network WorkManager work with a battery-not-low constraint and exponential retry starting at 30 seconds. `ConnectivitySyncObserver` uses `ConnectivityManager` and schedules a run when validated internet returns; WorkManager’s `NetworkType.CONNECTED` constraint is the durable execution gate, including after process death or reboot.

A worker obtains the user’s authorized Drive access token, reads the current private backup if present, and merges records by `(recordType,id)`. A strictly newer `updatedAt` wins; when timestamps tie, a local dirty record wins. UTC ISO-8601 timestamps are compared lexicographically. Tombstones are preserved as records. It pulls newer remote records into Room, builds the canonical backup, uploads only when local data is dirty or no backup exists, and marks a local row `SYNCED` only if its timestamp still matches the version uploaded. If an edit occurs while upload is in flight, the newer row remains pending for another run.

The Drive document is compressed JSON (gzip) with this versioned shape:

```json
{
  "backupVersion": 1,
  "lastSyncTime": "2026-11-04T00:00:00Z",
  "userData": [{ "recordType": "booking", "id": "…", "updatedAt": "…", "deletedAt": null, "data": {} }],
  "settings": [{ "key": "customLogo", "value": "…", "updatedAt": "…" }],
  "otherRecords": [{ "recordType": "event", "id": "…", "bookingId": "…", "updatedAt": "…", "deletedAt": null, "data": {} }]
}
```

The one compressed snapshot is stored as `raunak-pictures-backup.json.gz` in the hidden Drive `appDataFolder`, using the `drive.appdata` OAuth scope. The folder is deliberately not visible in the ordinary Drive file list. Since the requested document is a single coherent backup snapshot, a changed sync rewrites that compressed snapshot; unchanged local records are not resent in separate per-record API requests, and clean/pull-only runs do not upload it.

## Google authorization and setup

The Backup & Restore screen has **Connect Google Drive**, **Sync now**, account, pending/failed counts, last success and error status. Native Google Sign-In requests the `drive.file` scope. The Android app accepts only the studio owner's Google account (`raunakpictures101@gmail.com`) for interactive sign-in and also checks the account before background Drive sync. Google Play services obtains/refreshes the Drive access token for WorkManager; no server-side token or backend is involved.

To enable real Drive access, configure a Google Cloud project, enable Drive API, and create an Android OAuth client for package `com.raunakpictures.studiomanagement`. The debug build uses SHA-1 `57:2E:45:8C:1F:C8:DD:8E:1D:21:25:37:24:1E:8E:F2:18:B1:6C:59`; a release-signed APK needs its own release certificate SHA-1. Google account sign-in and user consent are required. For long-term use, set the External OAuth app to **In production**; add the required app branding and complete Google's basic verification steps if prompted. The app-side email allowlist still accepts only the owner account. Without the Cloud setup, all offline Room features still work, but Drive cannot authenticate. No Google account credentials are embedded in the app.

## Backup and restore

Manual JSON export reads from Room on Android and can be saved to Documents. The Drive snapshot is a separate automatic remote backup. Restore validates `backupVersion` and every record before Room tables are cleared; the Room transaction rolls back if any insert fails. Import schedules a subsequent sync. Invalid Drive JSON, invalid manual files or network failures never clear the current local database.

## Failure behavior

- **Offline / no validated network:** WorkManager waits; writes stay local and dirty.
- **No Google account:** Worker records that authorization is required and leaves local records pending; connecting an account schedules sync.
- **Transient network/Drive error:** Dirty records move to `FAILED`; WorkManager retries with backoff; `FAILED` rows remain eligible.
- **Non-retryable Drive response or malformed remote document:** Preserve Room data and surface the error; user can reconnect or restore a valid local backup.
- **Concurrent edits:** Conditional `updatedAt` checks prevent an older upload from marking a newer local edit synced.
- **Delete conflict:** A newer tombstone wins by timestamp and is retained in the remote snapshot.

The database is protected by Android’s application sandbox; Drive AppData is hidden from ordinary Drive browsing, but it is not an end-to-end encrypted vault. Use a device lock and protect the Google account.

## Source layout

```text
src/services/offlineData.ts                              typed Capacitor interface
src/services/storage.ts                                  browser adapter + Android Room routing
src/components/BackupRestore.tsx                         manual backup, restore, Drive state/actions
android/app/src/main/java/.../OfflineDataPlugin.kt       native bridge + Google sign-in UI
android/app/src/main/java/.../data/                      Room entity, DAO, database, repository
android/app/src/main/java/.../sync/                      connectivity observer, scheduler, Drive client, worker
android/app/src/test/java/.../data/StudioRepositoryTest.kt Room repository Robolectric tests
android/app/schemas/                                     exported Room schema snapshot
```

## Official references

Drive API overview and OAuth: https://developers.google.com/workspace/drive/api/guides/about-sdk and https://developers.google.com/identity/protocols/oauth2. AppData is hidden app-specific storage: https://developers.google.com/workspace/drive/api/guides/appdata. Drive limits: https://developers.google.com/workspace/drive/api/guides/limits. Android Auto Backup is a separate OS-managed backup with a 25 MB per-app limit and system-controlled scheduling; it is not per-booking sync: https://developer.android.com/identity/data/autobackup.

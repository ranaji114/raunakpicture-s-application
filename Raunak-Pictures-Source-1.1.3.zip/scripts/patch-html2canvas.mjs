import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const files = [
  resolve(root, 'node_modules/html2canvas/dist/html2canvas.esm.js'),
  resolve(root, 'node_modules/html2canvas/dist/html2canvas.js'),
];

const parserPatch = `var oklabColor = function (_context, args, isLch) {
    var tokens = args.filter(function (token) { return token.type !== 31 /* WHITESPACE_TOKEN */ && token.type !== 4 /* COMMA_TOKEN */; });
    var slash = tokens.findIndex(function (token) { return token.type === 6 /* DELIM_TOKEN */ && token.value === '/'; });
    var alphaToken = slash >= 0 ? tokens[slash + 1] : undefined;
    if (slash >= 0) tokens = tokens.slice(0, slash);
    if (tokens.length < 3) return COLORS.TRANSPARENT;
    var component = function (token, scale) {
        return token.type === 16 /* PERCENTAGE_TOKEN */ ? token.number * scale / 100 : token.number;
    };
    var L = component(tokens[0], 1);
    var x = component(tokens[1], isLch ? 0.4 : 0.004);
    var y;
    if (isLch) {
        var hue = tokens[2].number;
        var unit = tokens[2].unit || 'deg';
        var angle = unit === 'turn' ? hue * 2 * Math.PI : unit === 'rad' ? hue : unit === 'grad' ? hue * Math.PI / 200 : hue * Math.PI / 180;
        y = x * Math.sin(angle);
        x = x * Math.cos(angle);
    } else {
        y = component(tokens[2], 0.004);
    }
    var alpha = alphaToken ? component(alphaToken, 1) : 1;
    var l = Math.pow(L + 0.3963377774 * x + 0.2158037573 * y, 3);
    var m = Math.pow(L - 0.1055613458 * x - 0.0638541728 * y, 3);
    var s = Math.pow(L - 0.0894841775 * x - 1.291485548 * y, 3);
    var encode = function (value) {
        value = value <= 0.0031308 ? 12.92 * value : 1.055 * Math.pow(Math.max(0, value), 1 / 2.4) - 0.055;
        return Math.max(0, Math.min(1, value)) * 255;
    };
    return pack(
        encode(4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s),
        encode(-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s),
        encode(-0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s),
        Math.max(0, Math.min(1, alpha))
    );
};
var oklab = function (context, args) { return oklabColor(context, args, false); };
var oklch = function (context, args) { return oklabColor(context, args, true); };
`;

for (const path of files) {
  let source = readFileSync(path, 'utf8');
  if (source.includes('var oklabColor = function')) continue;
  const dispatch = 'var SUPPORTED_COLOR_FUNCTIONS = {\n';
  if (!source.includes(dispatch)) throw new Error(`html2canvas parser marker not found: ${path}`);
  source = source.replace(dispatch, `${parserPatch}${dispatch}`);
  source = source.replace(
    /(var SUPPORTED_COLOR_FUNCTIONS = \{\n)(\s*hsl: hsl,\n\s*hsla: hsl,\n\s*rgb: rgb,\n\s*rgba: rgb)\n(\s*\};)/,
    (_match, start, functions, end) => `${start}${functions},\n${functions.match(/\n(\s*)rgba:/)[1]}oklab: oklab,\n${functions.match(/\n(\s*)rgba:/)[1]}oklch: oklch\n${end}`,
  );
  if (!source.includes('oklab: oklab') || !source.includes('oklch: oklch')) {
    throw new Error(`Failed to add Oklab/Oklch parser functions: ${path}`);
  }
  writeFileSync(path, source);
  console.log(`Patched html2canvas Oklab/Oklch parser: ${path}`);
}

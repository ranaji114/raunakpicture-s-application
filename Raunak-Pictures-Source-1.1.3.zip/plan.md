# Offline-first Android conversion plan

## Product and design

Keep the existing Raunak Pictures React/Capacitor interface and its black-and-gold branding. Add a native Kotlin data and sync layer behind a Capacitor plugin. The APK remains a fully offline Android app; the UI never treats browser localStorage as authoritative. The dashboard keeps the personalized “Welcome back, Raunak!” greeting, and the existing creator/contact page remains available.

## Architecture

- **React/Capacitor UI (`src/`)**: booking, payments, calendar, purchases, backup/restore and sync status screens. A typed service adapter calls the Capacitor plugin for native Android data. A browser-only adapter may remain for local UI development, but the APK uses Room exclusively.
- **Native bridge (`android/app/src/main/java/com/raunakpictures/studiomanagement/`)**: a custom Capacitor plugin exposes booking/purchase CRUD, backup/restore, Google account connection, and sync status. Mutations complete in Room before the UI reports success.
- **Room database (`data/`)**: normalized Booking, Event, Service, Payment, Purchase and Settings entities. Every syncable entity carries `sync_status` (`PENDING`, `SYNCED`, `FAILED`), `updatedAt`, and a deletion tombstone field where needed. IDs are stable UUIDs. Foreign keys/cascades preserve relationships; Room migrations are versioned.
- **Repository**: local writes are transactional and first. Successful writes enqueue unique WorkManager work; no network is required for CRUD. Database change observers refresh React state.
- **WorkManager**: unique, connected-network work with exponential backoff. Each run gathers dirty/tombstoned rows, obtains a Google access token, downloads the existing appData backup, merges each record by `updatedAt`, writes the merged canonical JSON backup, and marks only unchanged local revisions `SYNCED`. Errors are recorded as `FAILED`; a WorkManager retry leaves rows eligible for retry. New edits re-mark records `PENDING`.
- **Drive**: use Google Drive API v3 with the `drive.appdata` scope. One versioned JSON file in the hidden `appDataFolder`; no backend, Firebase or share sheet. AppData is intentionally not visible in the normal Drive file list. Restore reads and validates this document, then transactionally imports it into Room. The user authorizes Google access once through native Google Sign-In/authorization.
- **Connectivity**: WorkManager's `NetworkType.CONNECTED` constraint is the reliable scheduling gate. A `ConnectivityManager.NetworkCallback` may update the UI and enqueue work promptly; it does not replace the WorkManager constraint.
- **Conflict/error safety**: local Room remains authoritative until a successful remote merge. Merge by `(recordType,id)` and greatest `updatedAt`; equal timestamps prefer the local dirty row. Preserve tombstones until the remote document confirms them. Use request timeouts, bounded payload size, gzip only above a threshold, exponential retry/backoff, and expose last sync/error status. Never clear local data on network/auth failure.

## Backup document

```json
{
  "backupVersion": 1,
  "lastSyncTime": "ISO-8601",
  "userData": [],
  "settings": [],
  "otherRecords": []
}
```

`userData` carries booking records; `otherRecords` carries events, services, payments and purchases; `settings` carries app settings. Each object includes `recordType`, stable `id`, `updatedAt`, `deletedAt` (nullable), and typed `data`. Sync status is local metadata and need not be treated as remote truth.

## Folder responsibilities

```text
src/services/nativeData.ts                 React-to-Capacitor typed adapter
src/components/BackupRestore.tsx            file export/import and Drive status UI
android/app/src/main/java/.../data/          Room entities, DAO, database, repository
android/app/src/main/java/.../drive/         Google auth, Drive API client, JSON codec
android/app/src/main/java/.../sync/          worker, scheduler, connectivity observer
android/app/src/main/java/.../bridge/        Capacitor plugin methods and serialization
android/app/src/main/res/xml/                backup rules / network configuration if needed
```

## Implementation constraints

The Android OAuth client is required to run Google Sign-In and Drive sync against a real account. The APK can compile with a documented placeholder, but live sync cannot be end-to-end validated until the client ID and its matching package/SHA-1 configuration are supplied. User's current debug package is `com.raunakpictures.studiomanagement`; current debug SHA-1 is `6E:F9:93:D1:DF:1C:40:E1:64:5D:0D:3C:2D:BB:B4:F3:27:0C:4A:B7`. The Android UI should never claim `SYNCED` before Drive confirms upload.

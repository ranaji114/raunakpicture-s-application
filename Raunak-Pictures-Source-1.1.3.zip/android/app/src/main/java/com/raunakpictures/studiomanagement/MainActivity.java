package com.raunakpictures.studiomanagement;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        registerPlugin(OfflineDataPlugin.class);
        super.onCreate(savedInstanceState);
    }
}

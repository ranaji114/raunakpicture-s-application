package com.raunakpictures.studiomanagement.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index

object SyncStatus {
    const val PENDING = "PENDING"
    const val SYNCED = "SYNCED"
    const val FAILED = "FAILED"
    val valid = setOf(PENDING, SYNCED, FAILED)
}

@Entity(tableName = "sync_records", primaryKeys = ["recordType", "id"], indices = [Index("bookingId"), Index("sync_status")])
data class SyncRecordEntity(
    val recordType: String,
    val id: String,
    val bookingId: String? = null,
    val payloadJson: String,
    val updatedAt: String,
    @ColumnInfo(name = "sync_status") val syncStatus: String = SyncStatus.PENDING,
    val deletedAt: String? = null
)

@Entity(tableName = "settings", primaryKeys = ["key"])
data class SettingEntity(
    val key: String,
    val value: String?,
    val updatedAt: String,
    @ColumnInfo(name = "sync_status") val syncStatus: String = SyncStatus.PENDING
)

@Entity(tableName = "data_migrations", primaryKeys = ["key"])
data class MigrationMarker(val key: String, val completedAt: String)

@androidx.room.Dao
interface SyncDao {
    @androidx.room.Query("SELECT * FROM sync_records ORDER BY updatedAt DESC") suspend fun allRecords(): List<SyncRecordEntity>
    @androidx.room.Query("SELECT * FROM sync_records WHERE recordType = :type AND deletedAt IS NULL ORDER BY updatedAt DESC") suspend fun activeByType(type: String): List<SyncRecordEntity>
    @androidx.room.Query("SELECT * FROM sync_records WHERE sync_status IN ('PENDING','FAILED') ORDER BY updatedAt") suspend fun dirtyRecords(): List<SyncRecordEntity>
    @androidx.room.Query("SELECT * FROM sync_records WHERE recordType = :type AND bookingId = :bookingId") suspend fun recordsForBooking(type: String, bookingId: String): List<SyncRecordEntity>
    @androidx.room.Query("SELECT * FROM sync_records WHERE bookingId = :id OR (recordType = 'booking' AND id = :id)") suspend fun recordsIncludingBooking(id: String): List<SyncRecordEntity>
    @androidx.room.Query("SELECT * FROM sync_records WHERE recordType = :type AND id = :id LIMIT 1") suspend fun get(type: String, id: String): SyncRecordEntity?
    @androidx.room.Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE) suspend fun upsert(record: SyncRecordEntity)
    @androidx.room.Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE) suspend fun upsertAll(records: List<SyncRecordEntity>)
    @androidx.room.Query("UPDATE sync_records SET sync_status = 'SYNCED' WHERE recordType = :type AND id = :id AND updatedAt = :updatedAt") suspend fun markSyncedIfUnchanged(type: String, id: String, updatedAt: String): Int
    @androidx.room.Query("UPDATE sync_records SET sync_status = :status WHERE recordType = :type AND id = :id") suspend fun updateStatus(type: String, id: String, status: String): Int
    @androidx.room.Query("DELETE FROM sync_records WHERE recordType = :type AND id = :id") suspend fun delete(type: String, id: String): Int
    @androidx.room.Query("SELECT * FROM settings WHERE key = :key LIMIT 1") suspend fun setting(key: String): SettingEntity?
    @androidx.room.Query("SELECT * FROM settings") suspend fun settings(): List<SettingEntity>
    @androidx.room.Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE) suspend fun upsertSetting(setting: SettingEntity)
    @androidx.room.Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE) suspend fun upsertSettings(settings: List<SettingEntity>)
    @androidx.room.Query("UPDATE settings SET sync_status = 'SYNCED' WHERE key = :key AND updatedAt = :updatedAt") suspend fun markSettingSyncedIfUnchanged(key: String, updatedAt: String): Int
    @androidx.room.Query("SELECT * FROM settings WHERE sync_status IN ('PENDING','FAILED')") suspend fun dirtySettings(): List<SettingEntity>
    @androidx.room.Query("UPDATE settings SET sync_status = :status WHERE key = :key") suspend fun updateSettingStatus(key: String, status: String): Int
    @androidx.room.Query("SELECT * FROM data_migrations WHERE key = :key LIMIT 1") suspend fun migration(key: String): MigrationMarker?
    @androidx.room.Insert(onConflict = androidx.room.OnConflictStrategy.IGNORE) suspend fun insertMigration(marker: MigrationMarker)
    @androidx.room.Query("DELETE FROM sync_records") suspend fun clearRecords()
    @androidx.room.Query("DELETE FROM settings") suspend fun clearSettings()
}

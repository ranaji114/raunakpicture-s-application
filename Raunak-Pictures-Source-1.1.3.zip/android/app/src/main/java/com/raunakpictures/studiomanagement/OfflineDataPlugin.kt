package com.raunakpictures.studiomanagement

import androidx.activity.result.ActivityResult
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.ActivityCallback as CapacitorActivityCallback
import com.getcapacitor.annotation.CapacitorPlugin
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.raunakpictures.studiomanagement.data.AppDatabase
import com.raunakpictures.studiomanagement.data.StudioRepository
import com.raunakpictures.studiomanagement.sync.AllowedOwnerGoogleAccount
import com.raunakpictures.studiomanagement.sync.ConnectivitySyncObserver
import com.raunakpictures.studiomanagement.sync.DriveApiClient
import com.raunakpictures.studiomanagement.sync.SyncScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Capacitor boundary. Every mutating call commits to Room before returning to JavaScript. */
@CapacitorPlugin(name = "OfflineData")
class OfflineDataPlugin : Plugin() {
    private val pluginScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var repository: StudioRepository
    private var networkObserver: ConnectivitySyncObserver? = null

    override fun load() {
        super.load()
        repository = StudioRepository(AppDatabase.get(context))
        networkObserver = ConnectivitySyncObserver(context).also { runCatching { it.register() } }
    }

    private fun runRoom(call: PluginCall, work: suspend StudioRepository.() -> JSObject) {
        pluginScope.launch {
            try {
                val result = withContext(Dispatchers.IO) { repository.work() }
                call.resolve(result)
            } catch (error: Exception) {
                call.reject(error.message ?: "Local database operation failed", "ROOM_OPERATION_FAILED", error)
            }
        }
    }

    private fun dataJson(bookings: List<JSONObject>, purchases: List<JSONObject>, logo: String?): JSObject =
        JSObject().apply {
            put("bookings", JSONArray(bookings))
            put("purchases", JSONArray(purchases))
            put("customLogo", logo ?: JSONObject.NULL)
        }

    @PluginMethod
    fun initialize(call: PluginCall) = runRoom(call) {
        initializeOrMigrateLegacy(
            call.getString("legacyBookings"),
            call.getString("legacyPurchases"),
            call.getString("legacyLogo")
        )
        SyncScheduler.schedule(context)
        dataJson(listBookings(), listPurchases(), customLogo())
    }

    @PluginMethod
    fun getData(call: PluginCall) = runRoom(call) {
        dataJson(listBookings(), listPurchases(), customLogo())
    }

    @PluginMethod
    fun saveBooking(call: PluginCall) = runRoom(call) {
        val booking = call.getObject("booking") ?: throw IllegalArgumentException("Missing booking")
        val id = JSONObject(booking.toString()).getString("id")
        saveBooking(JSONObject(booking.toString()))
        SyncScheduler.schedule(context)
        JSObject().put("saved", true).put("booking", findBooking(id) ?: JSONObject.NULL)
    }

    @PluginMethod
    fun cancelBooking(call: PluginCall) = runRoom(call) {
        val id = call.getString("id") ?: error("Missing booking id")
        setBookingStatus(id, "cancelled", call.getString("reason"))
        SyncScheduler.schedule(context)
        JSObject().put("saved", true).put("booking", findBooking(id) ?: JSONObject.NULL)
    }

    @PluginMethod
    fun restoreBooking(call: PluginCall) = runRoom(call) {
        val id = call.getString("id") ?: error("Missing booking id")
        setBookingStatus(id, "active")
        SyncScheduler.schedule(context)
        JSObject().put("saved", true).put("booking", findBooking(id) ?: JSONObject.NULL)
    }

    @PluginMethod
    fun deleteBooking(call: PluginCall) = runRoom(call) {
        deleteBooking(call.getString("id") ?: error("Missing booking id"))
        SyncScheduler.schedule(context)
        JSObject().put("saved", true)
    }

    @PluginMethod
    fun removeBookingLocally(call: PluginCall) = runRoom(call) {
        removeBookingLocally(call.getString("id") ?: error("Missing booking id"))
        JSObject().put("saved", true)
    }

    @PluginMethod
    fun addPayment(call: PluginCall) = runRoom(call) {
        val payment = call.getObject("payment") ?: throw IllegalArgumentException("Missing payment")
        val id = call.getString("bookingId") ?: error("Missing booking id")
        addPayment(id, JSONObject(payment.toString()))
        SyncScheduler.schedule(context)
        JSObject().put("saved", true).put("booking", findBooking(id) ?: JSONObject.NULL)
    }

    @PluginMethod
    fun savePurchase(call: PluginCall) = runRoom(call) {
        val purchase = call.getObject("purchase") ?: throw IllegalArgumentException("Missing purchase")
        val id = JSONObject(purchase.toString()).getString("id")
        savePurchase(JSONObject(purchase.toString()))
        SyncScheduler.schedule(context)
        JSObject().put("saved", true).put("purchase", findPurchase(id) ?: JSONObject.NULL)
    }

    @PluginMethod
    fun deletePurchase(call: PluginCall) = runRoom(call) {
        deletePurchase(call.getString("id") ?: error("Missing purchase id"))
        SyncScheduler.schedule(context)
        JSObject().put("saved", true)
    }

    @PluginMethod
    fun saveCustomLogo(call: PluginCall) = runRoom(call) {
        setCustomLogo(call.getString("value"))
        SyncScheduler.schedule(context)
        JSObject().put("saved", true)
    }

    @PluginMethod
    fun exportBackup(call: PluginCall) = runRoom(call) {
        JSObject().put("backup", exportBackup())
    }

    @PluginMethod
    fun restoreBackup(call: PluginCall) = runRoom(call) {
        val backup = call.getObject("backup") ?: throw IllegalArgumentException("Missing backup")
        restoreBackup(JSONObject(backup.toString()))
        SyncScheduler.schedule(context)
        JSObject().put("restored", true)
    }

    @PluginMethod
    fun getSyncStatus(call: PluginCall) = runRoom(call) {
        val prefs = context.getSharedPreferences("drive_sync_state", android.content.Context.MODE_PRIVATE)
        val dirty = dirtyRecords()
        val settings = dirtySettings()
        val account = GoogleSignIn.getLastSignedInAccount(context)
            ?.takeIf { AllowedOwnerGoogleAccount.matches(it.email) }
        JSObject().apply {
            put("connected", account != null)
            put("email", account?.email ?: JSONObject.NULL)
            put("pendingCount", dirty.count { it.syncStatus == "PENDING" } + settings.count { it.syncStatus == "PENDING" })
            put("failedCount", dirty.count { it.syncStatus == "FAILED" } + settings.count { it.syncStatus == "FAILED" })
            put("authRequired", prefs.getBoolean("auth_required", account == null) || account == null)
            put("lastError", prefs.getString("last_error", null) ?: JSONObject.NULL)
            put("lastSyncTime", prefs.getString("last_sync_time", null) ?: JSONObject.NULL)
            put("driveFileCount", prefs.getInt("drive_file_count", -1))
        }
    }

    @PluginMethod
    fun connectGoogle(call: PluginCall) {
        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(com.google.android.gms.common.api.Scope("https://www.googleapis.com/auth/drive.file"))
            .build()
        val client = GoogleSignIn.getClient(activity, options)
        startActivityForResult(call, client.signInIntent, "googleSignInResult")
    }

    @CapacitorActivityCallback
    private fun googleSignInResult(call: PluginCall, result: ActivityResult) {
        try {
            val account = GoogleSignIn.getSignedInAccountFromIntent(result.data).getResult(ApiException::class.java)
            if (!AllowedOwnerGoogleAccount.matches(account.email)) {
                context.getSharedPreferences("drive_sync_state", android.content.Context.MODE_PRIVATE).edit()
                    .putBoolean("auth_required", true).apply()
                val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestEmail()
                    .requestScopes(com.google.android.gms.common.api.Scope("https://www.googleapis.com/auth/drive.file"))
                    .build()
                GoogleSignIn.getClient(activity, options).signOut().addOnCompleteListener {
                    call.reject("Sirf app owner account ${AllowedOwnerGoogleAccount.EMAIL} connect ho sakta hai.", "OWNER_ACCOUNT_REQUIRED")
                }
                return
            }
            context.getSharedPreferences("drive_sync_state", android.content.Context.MODE_PRIVATE).edit()
                .putBoolean("auth_required", false).remove("last_error").apply()
            SyncScheduler.schedule(context)
            call.resolve(JSObject().put("connected", true).put("email", account.email ?: ""))
        } catch (error: Exception) {
            call.reject("Google Sign-In did not complete: ${error.message}", "GOOGLE_SIGN_IN_FAILED", error)
        }
    }

    @PluginMethod
    fun disconnectGoogle(call: PluginCall) {
        GoogleSignIn.getClient(activity, GoogleSignInOptions.DEFAULT_SIGN_IN).signOut()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    context.getSharedPreferences("drive_sync_state", android.content.Context.MODE_PRIVATE).edit()
                        .putBoolean("auth_required", true).apply()
                    call.resolve(JSObject().put("connected", false))
                } else call.reject("Could not disconnect Google account", "GOOGLE_SIGN_OUT_FAILED", task.exception)
            }
    }

    @PluginMethod
    fun syncNow(call: PluginCall) {
        if (GoogleSignIn.getLastSignedInAccount(context) == null) {
            call.reject("Connect a Google account before syncing", "GOOGLE_ACCOUNT_REQUIRED")
            return
        }
        SyncScheduler.schedule(context)
        call.resolve(JSObject().put("scheduled", true))
    }

    @PluginMethod
    fun restoreFromDrive(call: PluginCall) = runRoom(call) {
        val remote = DriveApiClient(context).downloadLatest()
            ?: throw IllegalStateException("Google Drive mein Raunak Pictures ka backup nahi mila")
        val driveBookings = remote.json.optJSONArray("userData")?.length() ?: 0
        val driveOtherRecords = remote.json.optJSONArray("otherRecords")?.length() ?: 0
        if (driveBookings == 0 && driveOtherRecords == 0) {
            throw IllegalStateException("Google Drive backup file mili, lekin usmein koi booking ya purchase record nahi hai")
        }
        restoreBackup(remote.json)
        SyncScheduler.schedule(context)
        val data = dataJson(listBookings(), listPurchases(), customLogo())
        val appBookings = data.getJSONArray("bookings")
        val cancelledInApp = (0 until appBookings.length()).count { appBookings.optJSONObject(it)?.optString("status") == "cancelled" }
        JSObject()
            .put("restored", true)
            .put("driveBookings", driveBookings)
            .put("cancelledBookingsInApp", cancelledInApp)
            .put("driveOtherRecords", driveOtherRecords)
            .put("bookingsInApp", appBookings.length())
            .put("purchasesInApp", data.getJSONArray("purchases").length())
    }
}

package com.raunakpictures.studiomanagement.sync

/** This private studio app accepts Drive authorization only from its owner account. */
internal object AllowedOwnerGoogleAccount {
    const val EMAIL = "raunakpictures101@gmail.com"

    fun matches(email: String?): Boolean = email?.trim()?.equals(EMAIL, ignoreCase = true) == true
}

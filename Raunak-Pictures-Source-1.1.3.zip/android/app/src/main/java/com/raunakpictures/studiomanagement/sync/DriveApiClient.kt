package com.raunakpictures.studiomanagement.sync

import android.content.Context
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.UserRecoverableAuthException
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

class AuthRequiredException(message: String, cause: Throwable? = null) : Exception(message, cause)
class DriveApiException(message: String, val retryable: Boolean, cause: Throwable? = null) : Exception(message, cause)
data class RemoteBackup(val fileId: String, val json: JSONObject)
data class RemoteRecordFile(val fileId: String, val recordType: String, val id: String, val json: JSONObject)

/** Drive stores each record as its own file so an individual booking can be removed independently. */
class DriveApiClient(private val context: Context) {
    companion object {
        private const val LEGACY_FILE_NAME = "raunak-pictures-backup.json.gz"
        private const val FOLDER_NAME = "Raunak Pictures Backups"
        private const val FOLDER_MIME = "application/vnd.google-apps.folder"
        private const val SCOPE = "oauth2:https://www.googleapis.com/auth/drive.file"
        private const val BASE = "https://www.googleapis.com/drive/v3/files"
        private const val TIMEOUT_MS = 20_000
    }

    private fun account(): GoogleSignInAccount {
        val signedIn = GoogleSignIn.getLastSignedInAccount(context)
            ?: throw AuthRequiredException("Google Sign-In is required for Drive backup")
        if (!AllowedOwnerGoogleAccount.matches(signedIn.email)) {
            throw AuthRequiredException("Only the studio owner's Google account can sync Drive backups")
        }
        return signedIn
    }

    private fun token(): String {
        val user = account()
        return try {
            GoogleAuthUtil.getToken(context, user.account!!, SCOPE)
        } catch (e: UserRecoverableAuthException) {
            throw AuthRequiredException("Google Drive authorization is required", e)
        } catch (e: Exception) {
            throw DriveApiException("Unable to obtain Drive access token", true, e)
        }
    }

    /** Read the previous all-in-one backup for one-time migration to per-record files. */
    fun downloadLegacyBackup(): RemoteBackup? {
        val folderId = findBackupFolderId() ?: return null
        val query = "name='$LEGACY_FILE_NAME' and '$folderId' in parents and trashed=false"
        val url = URL("$BASE?spaces=drive&fields=files(id,name,modifiedTime)&orderBy=modifiedTime%20desc&q=" + java.net.URLEncoder.encode(query, "UTF-8"))
        val files = request("GET", url, null, "application/json").optJSONArray("files") ?: return null
        if (files.length() == 0) return null
        val id = files.getJSONObject(0).getString("id")
        val bytes = requestBytes("GET", URL("$BASE/$id?alt=media"), null, "application/json")
        val json = GZIPInputStream(ByteArrayInputStream(bytes)).bufferedReader(Charsets.UTF_8).use { JSONObject(it.readText()) }
        return RemoteBackup(id, json)
    }

    /** Aggregate per-record files (or the legacy snapshot) into the UI's normal backup envelope. */
    fun downloadLatest(): RemoteBackup? {
        val legacy = downloadLegacyBackup()
        val records = listRecordFiles()
        if (legacy == null && records.isEmpty()) return null
        val aggregate = if (legacy != null) JSONObject(legacy.json.toString()) else JSONObject()
            .put("backupVersion", 1).put("lastSyncTime", java.time.Instant.now().toString())
            .put("userData", JSONArray()).put("otherRecords", JSONArray()).put("settings", JSONArray())
        if (legacy == null) return RemoteBackup("", aggregateRecords(aggregate, records))
        return RemoteBackup(legacy.fileId, aggregateRecords(aggregate, records))
    }

    private fun aggregateRecords(base: JSONObject, files: List<RemoteRecordFile>): JSONObject {
        val users = base.optJSONArray("userData") ?: JSONArray()
        val others = base.optJSONArray("otherRecords") ?: JSONArray()
        val settings = base.optJSONArray("settings") ?: JSONArray()
        val userIndexes = (0 until users.length()).associateBy { users.getJSONObject(it).optString("id") }.toMutableMap()
        val otherIndexes = (0 until others.length()).associateBy { "${others.getJSONObject(it).optString("recordType")}\u0000${others.getJSONObject(it).optString("id")}" }.toMutableMap()
        val settingIndexes = (0 until settings.length()).associateBy { settings.getJSONObject(it).optString("key") }.toMutableMap()
        files.forEach { file ->
            when (file.recordType) {
                "setting" -> {
                    val index = settingIndexes[file.id]
                    if (index == null) { settingIndexes[file.id] = settings.length(); settings.put(file.json) }
                    else settings.put(index, file.json)
                }
                "booking" -> {
                    val index = userIndexes[file.id]
                    if (index == null) { userIndexes[file.id] = users.length(); users.put(file.json) }
                    else users.put(index, file.json)
                }
                else -> {
                    val key = "${file.recordType}\u0000${file.id}"
                    val index = otherIndexes[key]
                    if (index == null) { otherIndexes[key] = others.length(); others.put(file.json) }
                    else others.put(index, file.json)
                }
            }
        }
        return base.put("backupVersion", 1).put("userData", users).put("otherRecords", others).put("settings", settings)
    }

    fun listRecordFiles(): List<RemoteRecordFile> {
        val folderId = findBackupFolderId() ?: return emptyList()
        val query = "'$folderId' in parents and trashed=false"
        val result = mutableListOf<RemoteRecordFile>()
        var pageToken: String? = null
        do {
            val params = "spaces=drive&fields=nextPageToken,files(id,name,appProperties)&pageSize=1000&q=" + java.net.URLEncoder.encode(query, "UTF-8") +
                (pageToken?.let { "&pageToken=" + java.net.URLEncoder.encode(it, "UTF-8") } ?: "")
            val page = request("GET", URL("$BASE?$params"), null, "application/json")
            val files = page.optJSONArray("files") ?: JSONArray()
            for (i in 0 until files.length()) {
                val meta = files.getJSONObject(i)
                val properties = meta.optJSONObject("appProperties") ?: continue
                val type = properties.optString("recordType")
                val id = properties.optString("recordId")
                if (type.isBlank() || id.isBlank()) continue
                val fileId = meta.getString("id")
                val bytes = requestBytes("GET", URL("$BASE/$fileId?alt=media"), null, "application/json")
                val json = GZIPInputStream(ByteArrayInputStream(bytes)).bufferedReader(Charsets.UTF_8).use { JSONObject(it.readText()) }
                result += RemoteRecordFile(fileId, type, id, json)
            }
            pageToken = page.optString("nextPageToken").takeIf { it.isNotBlank() && it != "null" }
        } while (pageToken != null)
        return result
    }

    fun uploadSnapshot(json: JSONObject, existingFileId: String?) {
        val bytes = ByteArrayOutputStream().also { output ->
            GZIPOutputStream(output).use { it.write(json.toString().toByteArray(Charsets.UTF_8)) }
        }.toByteArray()
        val metadata = JSONObject().put("name", LEGACY_FILE_NAME).put("mimeType", "application/gzip")
            .apply { if (existingFileId == null) put("parents", JSONArray().put(ensureBackupFolderId())) }
        uploadMultipart(metadata, bytes, existingFileId)
    }

    fun deleteRecordFile(fileId: String) {
        requestBytes("DELETE", URL("$BASE/$fileId"), null, "application/json")
    }

    fun deleteLegacyBackup(fileId: String) {
        if (fileId.isNotBlank()) requestBytes("DELETE", URL("$BASE/$fileId"), null, "application/json")
    }

    private fun uploadMultipart(metadata: JSONObject, bytes: ByteArray, existingFileId: String?) {
        val boundary = "raunak-${System.nanoTime()}"
        val body = ByteArrayOutputStream().apply {
            write("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n".toByteArray())
            write(metadata.toString().toByteArray(Charsets.UTF_8))
            write("\r\n--$boundary\r\nContent-Type: application/gzip\r\n\r\n".toByteArray())
            write(bytes)
            write("\r\n--$boundary--\r\n".toByteArray())
        }.toByteArray()
        val method = if (existingFileId == null) "POST" else "PATCH"
        val url = if (existingFileId == null) URL("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id")
            else URL("https://www.googleapis.com/upload/drive/v3/files/$existingFileId?uploadType=multipart&fields=id")
        requestBytes(method, url, body, "multipart/related; boundary=$boundary")
    }

    private fun findBackupFolderId(): String? {
        val query = "name='$FOLDER_NAME' and mimeType='$FOLDER_MIME' and 'root' in parents and trashed=false"
        val url = URL("$BASE?spaces=drive&fields=files(id,name)&pageSize=10&q=" + java.net.URLEncoder.encode(query, "UTF-8"))
        val files = request("GET", url, null, "application/json").optJSONArray("files") ?: return null
        return if (files.length() > 0) files.getJSONObject(0).getString("id") else null
    }

    private fun ensureBackupFolderId(): String = findBackupFolderId() ?: run {
        val metadata = JSONObject().put("name", FOLDER_NAME).put("mimeType", FOLDER_MIME).put("parents", JSONArray().put("root"))
        val response = requestBytes("POST", URL("$BASE?fields=id"), metadata.toString().toByteArray(Charsets.UTF_8), "application/json")
        JSONObject(response.toString(Charsets.UTF_8)).getString("id")
    }

    private fun request(method: String, url: URL, body: ByteArray?, contentType: String): JSONObject =
        JSONObject(requestBytes(method, url, body, contentType).toString(Charsets.UTF_8))

    private fun requestBytes(method: String, url: URL, body: ByteArray?, contentType: String): ByteArray {
        val bearer = token()
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = if (method == "PATCH") "POST" else method
            if (method == "PATCH") setRequestProperty("X-HTTP-Method-Override", "PATCH")
            connectTimeout = TIMEOUT_MS; readTimeout = TIMEOUT_MS
            setRequestProperty("Authorization", "Bearer $bearer")
            if (body != null) { doOutput = true; setRequestProperty("Content-Type", contentType); setFixedLengthStreamingMode(body.size) }
        }
        try {
            if (body != null) conn.outputStream.use { it.write(body) }
            val code = conn.responseCode
            val stream: InputStream? = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream?.use { it.readBytes() } ?: ByteArray(0)
            if (code !in 200..299) {
                val detail = response.toString(Charsets.UTF_8).take(500)
                throw DriveApiException("Drive API $method returned HTTP $code at ${url.path}: $detail", code == 408 || code == 429 || code >= 500)
            }
            return response
        } catch (e: DriveApiException) { throw e }
        catch (e: Exception) { throw DriveApiException("Drive request failed", true, e) }
        finally { conn.disconnect() }
    }
}

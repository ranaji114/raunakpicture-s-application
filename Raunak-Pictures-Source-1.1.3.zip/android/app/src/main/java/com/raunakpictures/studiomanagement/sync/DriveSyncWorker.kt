package com.raunakpictures.studiomanagement.sync

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.raunakpictures.studiomanagement.data.AppDatabase
import com.raunakpictures.studiomanagement.data.SettingEntity
import com.raunakpictures.studiomanagement.data.SyncRecordEntity
import com.raunakpictures.studiomanagement.data.SyncStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

class DriveSyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    companion object {
        const val PREFS = "drive_sync_state"
        const val KEY_AUTH_REQUIRED = "auth_required"
        const val KEY_LAST_ERROR = "last_error"
        const val KEY_LAST_SYNC_TIME = "last_sync_time"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        if (!hasValidatedInternet()) return@withContext Result.retry()
        val dao = AppDatabase.get(applicationContext).syncDao()
        val dirtyRecords = dao.dirtyRecords()
        val dirtySettings = dao.dirtySettings()
        try {
            val client = DriveApiClient(applicationContext)
            // The 1.1.1 build may have created individual files; read them all so
            // this single-snapshot build can safely fold them back into one file.
            val perRecordFiles = client.listRecordFiles()
            val remote = client.downloadLatest()
            val remoteRows = parseRows(remote?.json ?: JSONObject())
            val mergedRows = mergeRows(dao.allRecords(), remoteRows)
            val mergedSettings = mergeSettings(dao.settings(), remote?.json?.optJSONArray("settings") ?: JSONArray())

            // Apply the conflict winners locally before upload; local data is never cleared on failure.
            dao.upsertAll(mergedRows)
            if (mergedSettings.isNotEmpty()) dao.upsertSettings(mergedSettings)
            val document = makeBackup(mergedRows, mergedSettings)
            // Keep one visible Drive backup file; create/migrate it when needed.
            if (dirtyRecords.isNotEmpty() || dirtySettings.isNotEmpty() || remote == null || remote.fileId.isBlank() || perRecordFiles.isNotEmpty()) {
                client.uploadSnapshot(document, remote?.fileId?.takeIf { it.isNotBlank() })
                perRecordFiles.forEach { client.deleteRecordFile(it.fileId) }
            }

            // A user's edit made during the upload has a newer updatedAt and is deliberately not acknowledged.
            dirtyRecords.forEach { row -> dao.markSyncedIfUnchanged(row.recordType, row.id, row.updatedAt) }
            dirtySettings.forEach { setting -> dao.markSettingSyncedIfUnchanged(setting.key, setting.updatedAt) }
            applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_AUTH_REQUIRED, false)
                .putString(KEY_LAST_SYNC_TIME, document.getString("lastSyncTime"))
                .putInt("drive_file_count", 1)
                .remove(KEY_LAST_ERROR)
                .apply()
            Result.success()
        } catch (e: AuthRequiredException) {
            applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_AUTH_REQUIRED, true)
                .putString(KEY_LAST_ERROR, e.message ?: "Google sign-in is required")
                .apply()
            // Local records remain PENDING/FAILED; sign-in will enqueue work again.
            Result.success()
        } catch (e: Exception) {
            dirtyRecords.forEach { row -> runCatching { dao.updateStatus(row.recordType, row.id, SyncStatus.FAILED) } }
            dirtySettings.forEach { setting -> runCatching { dao.updateSettingStatus(setting.key, SyncStatus.FAILED) } }
            applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_AUTH_REQUIRED, false)
                .putString(KEY_LAST_ERROR, e.message ?: "Sync failed")
                .apply()
            if (e is DriveApiException && !e.retryable) Result.failure() else Result.retry()
        }
    }

    private fun hasValidatedInternet(): Boolean {
        val manager = applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun key(type: String, id: String) = "$type\u0000$id"

    private fun parseRows(document: JSONObject): List<SyncRecordEntity> {
        if (document.length() > 0 && document.optInt("backupVersion", -1) != 1) {
            throw IllegalArgumentException("Unsupported Drive backup version")
        }
        val result = ArrayList<SyncRecordEntity>()
        listOf("userData", "otherRecords").forEach { field ->
            val rows = document.optJSONArray(field) ?: return@forEach
            for (i in 0 until rows.length()) {
                val row = rows.optJSONObject(i) ?: throw IllegalArgumentException("Invalid Drive record")
                val type = row.optString("recordType")
                val id = row.optString("id")
                val updatedAt = row.optString("updatedAt")
                val data = row.optJSONObject("data")
                require(type.isNotBlank() && id.isNotBlank() && updatedAt.isNotBlank() && data != null) {
                    "Drive record is missing its identity, timestamp, or data"
                }
                if (data.optString("id") != id) throw IllegalArgumentException("Drive record identity does not match its payload")
                val deletedAt = row.optString("deletedAt").takeIf { it.isNotBlank() && it != "null" }
                result += SyncRecordEntity(
                    recordType = type,
                    id = id,
                    bookingId = row.optString("bookingId").takeIf { it.isNotBlank() && it != "null" },
                    payloadJson = data.toString(),
                    updatedAt = updatedAt,
                    syncStatus = SyncStatus.SYNCED,
                    deletedAt = deletedAt,
                )
            }
        }
        return result
    }

    /** ISO-8601 UTC timestamps sort lexicographically, so conflict selection needs no locale parsing. */
    private fun mergeRows(localRows: List<SyncRecordEntity>, remoteRows: List<SyncRecordEntity>): List<SyncRecordEntity> {
        val winners = LinkedHashMap<String, SyncRecordEntity>()
        (localRows + remoteRows).forEach { candidate ->
            val mapKey = key(candidate.recordType, candidate.id)
            val current = winners[mapKey]
            val candidatePending = candidate.syncStatus == SyncStatus.PENDING || candidate.syncStatus == SyncStatus.FAILED
            val currentPending = current?.syncStatus == SyncStatus.PENDING || current?.syncStatus == SyncStatus.FAILED
            if (current == null || candidate.updatedAt > current.updatedAt ||
                (candidate.updatedAt == current.updatedAt && candidatePending && !currentPending)) {
                winners[mapKey] = candidate
            }
        }
        return winners.values.toList()
    }

    private fun mergeSettings(localSettings: List<SettingEntity>, remoteRows: JSONArray): List<SettingEntity> {
        val winners = LinkedHashMap<String, SettingEntity>()
        localSettings.forEach { winners[it.key] = it }
        for (i in 0 until remoteRows.length()) {
            val row = remoteRows.optJSONObject(i) ?: throw IllegalArgumentException("Invalid Drive setting")
            val key = row.optString("key")
            val updatedAt = row.optString("updatedAt")
            require(key.isNotBlank() && updatedAt.isNotBlank()) { "Drive setting is missing its key or timestamp" }
            val remote = SettingEntity(key, if (row.isNull("value")) null else row.optString("value"), updatedAt, SyncStatus.SYNCED)
            val local = winners[key]
            val localPending = local?.syncStatus == SyncStatus.PENDING || local?.syncStatus == SyncStatus.FAILED
            if (local == null || remote.updatedAt > local.updatedAt ||
                (remote.updatedAt == local.updatedAt && !localPending)) winners[key] = remote
        }
        return winners.values.toList()
    }

    private fun makeBackup(rows: List<SyncRecordEntity>, settings: List<SettingEntity>): JSONObject {
        val userData = JSONArray()
        val otherRecords = JSONArray()
        rows.forEach { row ->
            val deleted = row.deletedAt != null
            val record = JSONObject()
                .put("recordType", row.recordType)
                .put("id", row.id)
                .put("updatedAt", row.updatedAt)
                // Retain a minimal tombstone so an older device cannot revive
                // a permanently deleted record, but do not keep its booking data.
                .put("data", if (deleted) JSONObject().put("id", row.id) else JSONObject(row.payloadJson))
            row.bookingId?.let { record.put("bookingId", it) }
            record.put("deletedAt", row.deletedAt ?: JSONObject.NULL)
            if (row.recordType == "booking") userData.put(record) else otherRecords.put(record)
        }
        val settingsArray = JSONArray()
        settings.forEach { setting ->
            settingsArray.put(JSONObject()
                .put("key", setting.key)
                .put("value", setting.value ?: JSONObject.NULL)
                .put("updatedAt", setting.updatedAt))
        }
        return JSONObject()
            .put("backupVersion", 1)
            .put("lastSyncTime", Instant.now().toString())
            .put("userData", userData)
            .put("settings", settingsArray)
            .put("otherRecords", otherRecords)
    }
}

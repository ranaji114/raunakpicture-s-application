package com.raunakpictures.studiomanagement.sync

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import java.util.concurrent.atomic.AtomicBoolean

/** Register from an application-owned lifecycle; WorkManager remains the durable scheduler. */
class ConnectivitySyncObserver(context: Context) {
    private val appContext = context.applicationContext
    private val manager = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    @Volatile private var registered = false
    private val validated = AtomicBoolean(false)

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { scheduleOnValidatedTransition() }
        override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
            if (capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) scheduleOnValidatedTransition()
        }
        override fun onLost(network: Network) {
            validated.set(false)
            scheduleOnValidatedTransition()
        }
    }

    private fun scheduleOnValidatedTransition() {
        if (isValidatedInternetAvailable() && validated.compareAndSet(false, true)) SyncScheduler.schedule(appContext)
    }

    fun register() {
        if (registered) return
        registered = true
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        try {
            manager.registerNetworkCallback(request, callback)
            scheduleOnValidatedTransition()
        } catch (e: RuntimeException) {
            registered = false
            throw e
        }
    }

    fun unregister() {
        if (!registered) return
        try { manager.unregisterNetworkCallback(callback) } catch (_: IllegalArgumentException) { }
        registered = false
    }

    private fun isValidatedInternetAvailable(): Boolean {
        val network = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
}

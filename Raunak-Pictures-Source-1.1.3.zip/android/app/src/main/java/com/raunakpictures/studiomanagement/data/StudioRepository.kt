package com.raunakpictures.studiomanagement.data

import androidx.room.withTransaction
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.UUID

/** Room is authoritative: every public mutation commits locally before a caller can enqueue sync. */
class StudioRepository(private val db: AppDatabase) {
    private val dao get() = db.syncDao()
    private fun now() = Instant.now().toString()
    private fun json(value: JSONObject) = value.toString()
    private fun array(value: String) = JSONArray(value)
    private fun records(type: String, items: JSONArray, bookingId: String? = null, stamp: String = now()): List<SyncRecordEntity> {
        val out = mutableListOf<SyncRecordEntity>()
        for (i in 0 until items.length()) {
            val obj = items.optJSONObject(i) ?: throw IllegalArgumentException("Invalid $type record")
            val id = obj.optString("id").takeIf { it.isNotBlank() } ?: throw IllegalArgumentException("Missing $type id")
            out += SyncRecordEntity(type, id, bookingId, obj.toString(), obj.optString("updatedAt", stamp).ifBlank { stamp }, SyncStatus.PENDING)
        }
        return out
    }

    /** One-time migration takes raw JSON arrays captured from existing browser data; never reads localStorage itself. */
    suspend fun initializeOrMigrateLegacy(bookingsJson: String?, purchasesJson: String?, customLogo: String? = null) = db.withTransaction {
        if (dao.migration("legacy-v1") != null) return@withTransaction
        if (dao.allRecords().isEmpty()) {
            bookingsJson?.let { source ->
                val bookings = array(source)
                for (i in 0 until bookings.length()) saveBookingInternal(bookings.getJSONObject(i), false)
            }
            purchasesJson?.let { source -> for (r in records("purchase", array(source))) dao.upsert(r) }
            if (customLogo != null) dao.upsertSetting(SettingEntity("customLogo", customLogo, now()))
        }
        dao.insertMigration(MigrationMarker("legacy-v1", now()))
    }

    suspend fun listBookings(): List<JSONObject> = dao.activeByType("booking").map { JSONObject(it.payloadJson) }
    suspend fun listActiveBookings(): List<JSONObject> = listBookings().filter { it.optString("status") == "active" }
    suspend fun listPurchases(): List<JSONObject> = dao.activeByType("purchase").map { JSONObject(it.payloadJson) }
    suspend fun findBooking(id: String): JSONObject? = dao.get("booking", id)?.takeIf { it.deletedAt == null }?.let { JSONObject(it.payloadJson) }
    suspend fun findPurchase(id: String): JSONObject? = dao.get("purchase", id)?.takeIf { it.deletedAt == null }?.let { JSONObject(it.payloadJson) }
    suspend fun saveBooking(raw: JSONObject) = db.withTransaction { saveBookingInternal(raw, true) }

    private suspend fun saveBookingInternal(raw: JSONObject, markChildrenRemoved: Boolean) {
        validateBooking(raw)
        val stamp = now(); val booking = JSONObject(raw.toString()).put("updatedAt", stamp)
        dao.upsert(SyncRecordEntity("booking", booking.getString("id"), null, json(booking), stamp))
        for ((field, type) in listOf("events" to "event", "services" to "service", "payments" to "payment")) {
            val proposed = records(type, booking.getJSONArray(field), booking.getString("id"), stamp)
            val existingChildren = dao.recordsForBooking(type, booking.getString("id"))
            val existingById = existingChildren.associateBy { it.id }
            val children = proposed.map { next ->
                val previous = existingById[next.id]
                if (previous != null && previous.deletedAt == null && previous.payloadJson == next.payloadJson) previous
                else next.copy(updatedAt = stamp, syncStatus = SyncStatus.PENDING, deletedAt = null)
            }
            dao.upsertAll(children)
            // A child removed by editing its parent remains as a tombstone for remote deletion propagation.
            if (markChildrenRemoved) {
                val keep = children.map { it.id }.toSet()
                val removedChildren = existingChildren.filter { it.id !in keep && it.deletedAt == null }
                dao.upsertAll(removedChildren.map { it.copy(updatedAt = stamp, syncStatus = SyncStatus.PENDING, deletedAt = stamp) })
            }
        }
    }

    suspend fun deleteBooking(id: String) = db.withTransaction {
        val stamp = now()
        val affected = dao.recordsIncludingBooking(id)
        dao.upsertAll(affected.map { it.copy(updatedAt = stamp, syncStatus = SyncStatus.PENDING, deletedAt = stamp) })
    }

    /** Remove the local copy only. A later sync can restore it from the Drive snapshot. */
    suspend fun removeBookingLocally(id: String) = db.withTransaction {
        dao.recordsIncludingBooking(id).forEach { dao.delete(it.recordType, it.id) }
    }

    suspend fun setBookingStatus(id: String, status: String, reason: String? = null) = db.withTransaction {
        require(status in setOf("active", "cancelled", "completed"))
        val row = dao.get("booking", id) ?: throw NoSuchElementException("Booking not found")
        val item = JSONObject(row.payloadJson).put("status", status).put("updatedAt", now())
        if (status == "cancelled") { item.put("cancelledAt", now()); if (reason != null) item.put("cancellationReason", reason) }
        else { item.remove("cancelledAt"); item.remove("cancellationReason") }
        saveBookingInternal(item, false)
    }

    suspend fun addPayment(bookingId: String, payment: JSONObject) = db.withTransaction {
        val row = dao.get("booking", bookingId) ?: throw NoSuchElementException("Booking not found")
        val b = JSONObject(row.payloadJson); val payments = b.optJSONArray("payments") ?: JSONArray()
        val p = JSONObject(payment.toString()); if (!p.has("id")) p.put("id", UUID.randomUUID().toString()); payments.put(p); b.put("payments", payments)
        val services = b.optJSONArray("services") ?: JSONArray(); var total = 0.0
        for (i in 0 until services.length()) total += services.optJSONObject(i)?.optDouble("total", 0.0) ?: 0.0
        var paid = 0.0; var advance: JSONObject? = null
        for (i in 0 until payments.length()) { val current = payments.optJSONObject(i) ?: continue; paid += current.optDouble("amount", 0.0); if (advance == null && current.optBoolean("isAdvance")) advance = current }
        if (advance == null && payments.length() > 0) advance = payments.optJSONObject(0)
        b.put("totalAmount", total).put("totalPaid", paid).put("totalAdvance", advance?.optDouble("amount", 0.0) ?: 0.0).put("remainingAmount", (total - paid).coerceAtLeast(0.0))
        saveBookingInternal(b, false)
    }

    suspend fun savePurchase(purchase: JSONObject) = db.withTransaction {
        require(purchase.optString("id").isNotBlank() && purchase.optString("name").isNotBlank())
        val p = JSONObject(purchase.toString()); val stamp = now(); val id = p.getString("id"); p.put("updatedAt", stamp)
        dao.upsert(SyncRecordEntity("purchase", id, p.optString("bookingId").takeIf { it.isNotBlank() }, p.toString(), stamp))
    }
    suspend fun deletePurchase(id: String) = db.withTransaction {
        val old = dao.get("purchase", id) ?: return@withTransaction
        val stamp = now(); dao.upsert(old.copy(updatedAt = stamp, syncStatus = SyncStatus.PENDING, deletedAt = stamp))
    }
    suspend fun setCustomLogo(value: String?) { dao.upsertSetting(SettingEntity("customLogo", value, now())) }
    suspend fun customLogo(): String? = dao.setting("customLogo")?.value
    suspend fun dirtyRecords() = dao.dirtyRecords()
    suspend fun dirtySettings() = dao.dirtySettings()
    suspend fun allRecords() = dao.allRecords()
    suspend fun markSyncedIfUnchanged(type: String, id: String, updatedAt: String) = dao.markSyncedIfUnchanged(type, id, updatedAt)
    suspend fun setSyncStatus(type: String, id: String, status: String) { require(status in SyncStatus.valid); dao.updateStatus(type, id, status) }

    /** Versioned, typed envelope; payloads remain exact UI JSON and sync metadata stays outside them. */
    suspend fun exportBackup(): JSONObject {
        val records = dao.allRecords()
        val settings = dao.settings()
        return JSONObject().put("backupVersion", 1).put("lastSyncTime", now())
            .put("userData", JSONArray().also { out -> records.filter { it.recordType == "booking" }.forEach { out.put(JSONObject().put("recordType", it.recordType).put("id", it.id).put("updatedAt", it.updatedAt).put("deletedAt", it.deletedAt ?: JSONObject.NULL).put("data", JSONObject(it.payloadJson))) } })
            .put("settings", JSONArray().also { out -> settings.forEach { out.put(JSONObject().put("key", it.key).put("value", it.value ?: JSONObject.NULL).put("updatedAt", it.updatedAt)) } })
            .put("otherRecords", JSONArray().also { out -> records.filter { it.recordType != "booking" }.forEach { out.put(JSONObject().put("recordType", it.recordType).put("id", it.id).put("bookingId", it.bookingId ?: JSONObject.NULL).put("updatedAt", it.updatedAt).put("deletedAt", it.deletedAt ?: JSONObject.NULL).put("data", JSONObject(it.payloadJson))) } })
    }

    suspend fun restoreBackup(backup: JSONObject) = db.withTransaction {
        val normalized = if (backup.optInt("backupVersion", -1) == 1) backup else convertLegacyBackup(backup)
        require(normalized.optInt("backupVersion", -1) == 1) { "Unsupported backup version" }
        val users = normalized.optJSONArray("userData") ?: throw IllegalArgumentException("Missing userData")
        val others = normalized.optJSONArray("otherRecords") ?: throw IllegalArgumentException("Missing otherRecords")
        val settings = normalized.optJSONArray("settings") ?: JSONArray()
        val imported = mutableListOf<SyncRecordEntity>()
        fun unpack(a: JSONArray, expected: String?) {
            for (i in 0 until a.length()) {
                val row = a.optJSONObject(i) ?: throw IllegalArgumentException("Invalid backup record")
                val type = row.optString("recordType", expected ?: ""); val id = row.optString("id"); val data = row.optJSONObject("data") ?: throw IllegalArgumentException("Missing record data")
                require(type.isNotBlank() && id.isNotBlank() && data.optString("id") == id)
                val deletedAt = row.optString("deletedAt").takeIf { it.isNotBlank() && it != "null" }
                if (type == "booking" && deletedAt == null) validateBooking(data)
                // Preserve Drive tombstones; otherwise an older snapshot can
                // revive records that were already deleted on another device.
                imported += SyncRecordEntity(type, id, row.optString("bookingId").takeIf { it.isNotBlank() && it != "null" }, data.toString(), row.optString("updatedAt", now()), SyncStatus.SYNCED, deletedAt)
            }
        }
        unpack(users, "booking"); unpack(others, null)
        val importedSettings = (0 until settings.length()).map { i -> val s = settings.getJSONObject(i); SettingEntity(s.getString("key"), if (s.isNull("value")) null else s.getString("value"), s.optString("updatedAt", now()), SyncStatus.SYNCED) }
        // Drive restore is deliberately non-destructive. Keep every existing
        // local row; replace only when the Drive version is newer. Never replace
        // a newer local tombstone with an older live Drive row.
        imported.forEach { remote ->
            val local = dao.get(remote.recordType, remote.id)
            if (local == null || remote.updatedAt > local.updatedAt) dao.upsert(remote)
        }
        importedSettings.forEach { remote ->
            val local = dao.setting(remote.key)
            if (local == null || remote.updatedAt > local.updatedAt) dao.upsertSetting(remote)
        }
    }


    /** Convert backups produced by the previous localStorage-based APK without dropping its nested records. */
    private fun convertLegacyBackup(old: JSONObject): JSONObject {
        require(old.optString("app") == "raunak-pictures" && old.optInt("schemaVersion", -1) == 1) {
            "Unsupported backup format"
        }
        val bookings = old.optJSONArray("bookings") ?: throw IllegalArgumentException("Missing legacy bookings")
        val purchases = old.optJSONArray("purchases") ?: throw IllegalArgumentException("Missing legacy purchases")
        val users = JSONArray(); val other = JSONArray(); val stamp = now()
        for (i in 0 until bookings.length()) {
            val booking = bookings.optJSONObject(i) ?: throw IllegalArgumentException("Invalid legacy booking")
            validateBooking(booking)
            users.put(JSONObject().put("recordType", "booking").put("id", booking.getString("id"))
                .put("updatedAt", booking.optString("updatedAt", stamp).ifBlank { stamp })
                .put("deletedAt", JSONObject.NULL).put("data", booking))
            listOf("events" to "event", "services" to "service", "payments" to "payment").forEach { (field, type) ->
                val children = booking.optJSONArray(field) ?: JSONArray()
                for (j in 0 until children.length()) {
                    val child = children.optJSONObject(j) ?: throw IllegalArgumentException("Invalid legacy $type")
                    val id = child.optString("id")
                    require(id.isNotBlank()) { "Legacy $type is missing an ID" }
                    other.put(JSONObject().put("recordType", type).put("id", id)
                        .put("bookingId", booking.getString("id")).put("updatedAt", stamp)
                        .put("deletedAt", JSONObject.NULL).put("data", child))
                }
            }
        }
        for (i in 0 until purchases.length()) {
            val purchase = purchases.optJSONObject(i) ?: throw IllegalArgumentException("Invalid legacy purchase")
            val id = purchase.optString("id"); require(id.isNotBlank()) { "Legacy purchase is missing an ID" }
            other.put(JSONObject().put("recordType", "purchase").put("id", id)
                .put("updatedAt", stamp).put("deletedAt", JSONObject.NULL).put("data", purchase))
        }
        val settings = JSONArray()
        if (old.has("customLogo") && !old.isNull("customLogo")) {
            settings.put(JSONObject().put("key", "customLogo").put("value", old.getString("customLogo")).put("updatedAt", stamp))
        }
        return JSONObject().put("backupVersion", 1).put("lastSyncTime", stamp)
            .put("userData", users).put("settings", settings).put("otherRecords", other)
    }

    private fun validateBooking(b: JSONObject) {
        require(b.optString("id").isNotBlank() && b.has("customerName")) { "Invalid booking" }
        listOf("events", "services", "payments").forEach { require(b.optJSONArray(it) != null) { "Invalid booking $it" } }
    }
}

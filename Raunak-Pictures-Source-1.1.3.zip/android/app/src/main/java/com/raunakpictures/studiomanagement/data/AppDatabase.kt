package com.raunakpictures.studiomanagement.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [SyncRecordEntity::class, SettingEntity::class, MigrationMarker::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun syncDao(): SyncDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "raunak-pictures.db")
                .build().also { INSTANCE = it }
        }
    }
}

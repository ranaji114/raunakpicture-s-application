package com.raunakpictures.studiomanagement.data

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import android.content.Context
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class StudioRepositoryTest {
    private lateinit var database: AppDatabase
    private lateinit var repository: StudioRepository

    @Before
    fun setUp() {
        database = Room.inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext<Context>(),
            AppDatabase::class.java,
        ).allowMainThreadQueries().build()
        repository = StudioRepository(database)
    }

    @After
    fun tearDown() {
        database.close()
    }

    private fun sampleBooking() = JSONObject()
        .put("id", "booking-1")
        .put("customerName", "Test Customer")
        .put("status", "active")
        .put("events", JSONArray().put(JSONObject().put("id", "event-1").put("name", "Wedding")))
        .put("services", JSONArray().put(JSONObject().put("id", "service-1").put("name", "Photography").put("total", 12000)))
        .put("payments", JSONArray().put(JSONObject().put("id", "payment-1").put("amount", 2000).put("isAdvance", true)))
        .put("totalAmount", 12000)
        .put("totalPaid", 2000)
        .put("totalAdvance", 2000)
        .put("remainingAmount", 10000)

    @Test
    fun bookingAndChildRecordsAreCommittedLocallyBeforeSync() = runBlocking {
        repository.saveBooking(sampleBooking())
        val bookings = repository.listBookings()
        assertEquals(1, bookings.size)
        assertEquals("Test Customer", bookings.single().getString("customerName"))
        val records = repository.allRecords()
        assertEquals(setOf("booking", "event", "service", "payment"), records.map { it.recordType }.toSet())
        assertTrue(records.all { it.syncStatus == SyncStatus.PENDING })
        assertTrue(records.all { it.updatedAt.isNotBlank() })
    }

    @Test
    fun deleteUsesTombstonesSoRemoteCanReceiveDeletion() = runBlocking {
        repository.saveBooking(sampleBooking())
        repository.deleteBooking("booking-1")
        assertTrue(repository.listBookings().isEmpty())
        val records = repository.allRecords()
        assertEquals(4, records.size)
        assertTrue(records.all { it.deletedAt != null && it.syncStatus == SyncStatus.PENDING })
    }

    @Test
    fun versionedBackupRestoresAndRejectsInvalidDataWithoutClearingCurrentRows() = runBlocking {
        repository.saveBooking(sampleBooking())
        val backup = repository.exportBackup()
        assertEquals(1, backup.getInt("backupVersion"))
        assertEquals(1, backup.getJSONArray("userData").length())
        assertEquals(3, backup.getJSONArray("otherRecords").length())

        repository.restoreBackup(backup)
        assertEquals(1, repository.listBookings().size)
        assertEquals(4, repository.allRecords().size)

        val broken = JSONObject().put("backupVersion", 1).put("userData", JSONArray())
        assertThrows(IllegalArgumentException::class.java) { runBlocking { repository.restoreBackup(broken) } }
        assertEquals("failed import must not clear current Room data", 1, repository.listBookings().size)
    }

    @Test
    fun previousLocalStorageBackupRemainsRestorable() = runBlocking {
        val legacy = JSONObject()
            .put("app", "raunak-pictures")
            .put("schemaVersion", 1)
            .put("bookings", JSONArray().put(sampleBooking()))
            .put("purchases", JSONArray().put(JSONObject().put("id", "purchase-1").put("name", "Prints")))
            .put("customLogo", "data:image/png;base64,abc")
        repository.restoreBackup(legacy)
        assertEquals(1, repository.listBookings().size)
        assertEquals(1, repository.listPurchases().size)
        assertEquals("data:image/png;base64,abc", repository.customLogo())
        assertTrue(repository.allRecords().any { it.recordType == "event" })
    }
}

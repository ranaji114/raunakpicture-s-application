package com.raunakpictures.studiomanagement.sync

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AllowedOwnerGoogleAccountTest {
    @Test
    fun acceptsOwnerEmailCaseInsensitively() {
        assertTrue(AllowedOwnerGoogleAccount.matches("raunakpictures101@gmail.com"))
        assertTrue(AllowedOwnerGoogleAccount.matches("  RaunakPictures101@gmail.com  "))
    }

    @Test
    fun rejectsOtherOrMissingEmail() {
        assertFalse(AllowedOwnerGoogleAccount.matches("someone.else@gmail.com"))
        assertFalse(AllowedOwnerGoogleAccount.matches(null))
        assertFalse(AllowedOwnerGoogleAccount.matches(""))
    }
}

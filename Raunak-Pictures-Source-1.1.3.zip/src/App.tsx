import React, { useState, useEffect, useMemo } from 'react';
import { App as CapacitorApp } from '@capacitor/app';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { BookingForm } from './components/BookingForm';
import { AllBookings } from './components/AllBookings';
import { CalendarView } from './components/CalendarView';
import { PaymentsView } from './components/PaymentsView';
import { InternalPurchases as InternalPurchasesView } from './components/InternalPurchases';
import { CancelledBookings as CancelledBookingsView } from './components/CancelledBookings';
import { CreatorPage } from './components/CreatorPage';
import { BackupRestore } from './components/BackupRestore';
import { BookingDetailsModal } from './components/BookingDetailsModal';
import { ReceiptModal } from './components/ReceiptModal';
import { AddPaymentModal } from './components/AddPaymentModal';
import { CancelBookingModal } from './components/CancelBookingModal';
import { SplashScreen } from './components/SplashScreen';
import { 
  ActiveTab, 
  Booking, 
  InternalPurchase, 
  PaymentItem 
} from './types';
import { 
  saveBooking, 
  cancelBooking, 
  restoreBooking, 
  deleteBooking, 
  removeBookingLocally,
  addPaymentToBooking, 
  savePurchase, 
  deletePurchase,
  saveCustomLogo,
  initializeAppData,
  readAppData,
} from './services/storage';

function upsertById<T extends { id: string }>(items: T[], updated: T): T[] {
  const index = items.findIndex(item => item.id === updated.id);
  if (index < 0) return [updated, ...items];
  return items.map((item, itemIndex) => itemIndex === index ? updated : item);
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isOpenMobile, setIsOpenMobile] = useState(false);
  const [showSplash, setShowSplash] = useState(true);
  const [customLogo, setCustomLogo] = useState<string | null>(null);

  // Android data is loaded from Room after the one-time legacy migration.
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [purchases, setPurchases] = useState<InternalPurchase[]>([]);

  // Dynamically sync favicon with custom logo if set
  useEffect(() => {
    if (customLogo) {
      const favicon = document.getElementById('app-favicon') as HTMLLinkElement | null;
      if (favicon) {
        favicon.href = customLogo;
      }
    }
  }, [customLogo]);

  // Modal & Edit states
  const [editingBooking, setEditingBooking] = useState<Booking | null>(null);
  const [detailsBooking, setDetailsBooking] = useState<Booking | null>(null);
  const [receiptBooking, setReceiptBooking] = useState<Booking | null>(null);
  const [paymentBooking, setPaymentBooking] = useState<Booking | null>(null);
  const [cancelTargetBooking, setCancelTargetBooking] = useState<Booking | null>(null);

  // Toast / notification feedback
  const [notification, setNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 3500);
  };

  // Read current data from the platform repository (Room on Android; local adapter in browser).
  const reloadData = async () => {
    const data = await readAppData();
    setBookings(data.bookings);
    setPurchases(data.purchases);
    setCustomLogo(data.customLogo);
    return data;
  };

  // Migrate the previous Capacitor localStorage data into Room once, then use Room only.
  useEffect(() => {
    let alive = true;
    initializeAppData().then(data => {
      if (!alive) return;
      setBookings(data.bookings);
      setPurchases(data.purchases);
      setCustomLogo(data.customLogo);
    }).catch(error => {
      console.error('App data initialization failed', error);
      if (alive) showNotification('स्थानीय डेटा लोड नहीं हुआ। कृपया ऐप को दोबारा खोलें।');
    });
    return () => { alive = false; };
  }, []);

  // Android hardware back navigates through app UI instead of immediately closing.
  useEffect(() => {
    let listener: { remove: () => Promise<void> } | undefined;
    void CapacitorApp.addListener('backButton', () => {
      if (receiptBooking) { setReceiptBooking(null); return; }
      if (paymentBooking) { setPaymentBooking(null); return; }
      if (cancelTargetBooking) { setCancelTargetBooking(null); return; }
      if (detailsBooking) { setDetailsBooking(null); return; }
      if (editingBooking) { setEditingBooking(null); setActiveTab('all-bookings'); return; }
      if (activeTab !== 'dashboard') { setActiveTab('dashboard'); return; }
      void CapacitorApp.exitApp();
    }).then(handle => { listener = handle; });
    return () => { void listener?.remove(); };
  }, [activeTab, receiptBooking, paymentBooking, cancelTargetBooking, detailsBooking, editingBooking]);

  // Keep details modal synchronized if current booking was edited or had payments added
  useEffect(() => {
    if (detailsBooking) {
      const refreshed = bookings.find(b => b.id === detailsBooking.id);
      if (refreshed) {
        setDetailsBooking(refreshed);
      }
    }
  }, [bookings]);

  // Handler: Save or Update Booking
  const handleSaveBooking = async (bookingData: Booking) => {
    try {
      const savedBooking = await saveBooking(bookingData);
      setBookings(current => upsertById(current, savedBooking));
      setEditingBooking(null);
      setActiveTab('all-bookings');
      showNotification('बुकिंग डिवाइस में सुरक्षित कर ली गई!');
    } catch (error) { console.error(error); showNotification('बुकिंग सेव नहीं हो सकी। कृपया फिर प्रयास करें।'); }
  };

  // Handler: Cancel Booking (via prompt modal)
  const handleConfirmCancel = async (bookingId: string, reason: string) => {
    try {
      const updatedBooking = await cancelBooking(bookingId, reason);
      if (updatedBooking) setBookings(current => upsertById(current, updatedBooking));
      setCancelTargetBooking(null);
      if (detailsBooking?.id === bookingId) setDetailsBooking(null);
      showNotification('बुकिंग रद्द हुई और डिवाइस में सुरक्षित है।');
    } catch (error) { console.error(error); showNotification('बुकिंग रद्द नहीं हो सकी।'); }
  };

  // Handler: Restore Cancelled Booking
  const handleRestoreBooking = async (id: string) => {
    try {
      const restoredBooking = await restoreBooking(id);
      if (restoredBooking) setBookings(current => upsertById(current, restoredBooking));
      showNotification('बुकिंग फिर से सक्रिय हुई।');
    }
    catch (error) { console.error(error); showNotification('बुकिंग restore नहीं हो सकी।'); }
  };

  // Handler: Delete Booking Permanently
  const handleDeleteBooking = async (id: string) => {
    try {
      await deleteBooking(id);
      setBookings(current => current.filter(booking => booking.id !== id));
      if (detailsBooking?.id === id) setDetailsBooking(null);
      showNotification('App se booking hide ki aur Drive backup mein permanent deletion sync ke liye queue ki.');
    } catch (error) { console.error(error); showNotification('बुकिंग हटाई नहीं जा सकी।'); }
  };

  const handleRemoveBookingLocally = async (id: string) => {
    try {
      await removeBookingLocally(id);
      setBookings(current => current.filter(booking => booking.id !== id));
      if (detailsBooking?.id === id) setDetailsBooking(null);
      showNotification('बुकिंग इस फोन से हटाई गई। अगली सफल sync पर Drive backup में बची booking वापस आ सकती है।');
    } catch (error) { console.error(error); showNotification('बुकिंग फोन से नहीं हटाई जा सकी।'); }
  };

  // Handler: Add Payment to Booking
  const handleSavePayment = async (bookingId: string, paymentData: Omit<PaymentItem, 'id'>) => {
    try {
      const updatedBooking = await addPaymentToBooking(bookingId, paymentData);
      if (updatedBooking) setBookings(current => upsertById(current, updatedBooking));
      setPaymentBooking(null);
      showNotification('भुगतान डिवाइस में सुरक्षित किया गया।');
    }
    catch (error) { console.error(error); showNotification('भुगतान सेव नहीं हो सका।'); }
  };

  // Handler: Add Internal Purchase
  const handleAddPurchase = async (purchaseData: InternalPurchase) => {
    try {
      const savedPurchase = await savePurchase(purchaseData);
      setPurchases(current => upsertById(current, savedPurchase));
      showNotification('खरीद रिकॉर्ड डिवाइस में सुरक्षित किया गया।');
    }
    catch (error) { console.error(error); showNotification('खरीद रिकॉर्ड सेव नहीं हुआ।'); }
  };

  // Handler: Delete Internal Purchase
  const handleDeletePurchase = async (id: string) => {
    try {
      await deletePurchase(id);
      setPurchases(current => current.filter(purchase => purchase.id !== id));
      showNotification('खरीद हटाकर sync के लिए कतार में रखी गई।');
    }
    catch (error) { console.error(error); showNotification('खरीद रिकॉर्ड हटाया नहीं जा सका।'); }
  };

  // Handler: Update custom logo / icon
  const handleLogoUpload = async (dataUrl: string) => {
    try { await saveCustomLogo(dataUrl); setCustomLogo(dataUrl); showNotification('नया लोगो डिवाइस में सुरक्षित किया गया।'); }
    catch (error) { console.error(error); showNotification('लोगो सेव नहीं हो सका।'); }
  };

  // Navigation handlers
  const handleEditClick = (booking: Booking) => {
    setEditingBooking(booking);
    setDetailsBooking(null);
    setActiveTab('new-booking');
  };

  const handleNewBookingTab = () => {
    setEditingBooking(null);
    setActiveTab('new-booking');
  };

  const { activeCount, cancelledCount } = useMemo(() => {
    const cancelled = bookings.reduce((count, booking) => count + Number(booking.status === 'cancelled'), 0);
    return { activeCount: bookings.length - cancelled, cancelledCount: cancelled };
  }, [bookings]);

  return (
    <div className="min-h-screen bg-[#0B0B0B] text-white flex flex-col antialiased selection:bg-[#F5C542] selection:text-[#0B0B0B]">
      {/* Animated Splash Screen on App Launch */}
      {showSplash && (
        <SplashScreen
          logoUrl={customLogo}
          onFinish={() => setShowSplash(false)}
        />
      )}

      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-5 right-5 z-50 px-4 py-3 rounded-lg bg-[#F5C542] text-[#0B0B0B] font-bold text-xs sm:text-sm shadow-2xl flex items-center gap-2 border border-[#DDAE30] animate-bounce font-hindi">
          <span>✓</span>
          <span>{notification}</span>
        </div>
      )}

      {/* Main Desktop Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          if (tab === 'new-booking') {
            setEditingBooking(null);
          }
          setActiveTab(tab);
        }}
        isOpenMobile={isOpenMobile}
        setIsOpenMobile={setIsOpenMobile}
        activeCount={activeCount}
        cancelledCount={cancelledCount}
        logoUrl={customLogo}
        onLogoUpload={handleLogoUpload}
      />

      {/* Main Layout Area */}
      <div className="lg:pl-72 flex-1 flex flex-col min-w-0 pb-16 lg:pb-8">
        {/* Header */}
        <Header
          activeTab={activeTab}
          setActiveTab={(tab) => {
            if (tab === 'new-booking') {
              setEditingBooking(null);
            }
            setActiveTab(tab);
          }}
          setIsOpenMobile={setIsOpenMobile}
          logoUrl={customLogo}
        />

        {/* Dynamic Page Views */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {activeTab === 'dashboard' && (
            <Dashboard
              bookings={bookings}
              setActiveTab={(tab) => {
                if (tab === 'new-booking') {
                  setEditingBooking(null);
                }
                setActiveTab(tab);
              }}
              onViewBooking={(b) => setDetailsBooking(b)}
              onGenerateReceipt={(b) => setReceiptBooking(b)}
              logoUrl={customLogo}
            />
          )}

          {activeTab === 'new-booking' && (
            <BookingForm
              initialBooking={editingBooking}
              onSave={handleSaveBooking}
              onCancel={() => {
                setEditingBooking(null);
                setActiveTab('all-bookings');
              }}
            />
          )}

          {activeTab === 'all-bookings' && (
            <AllBookings
              bookings={bookings}
              onViewBooking={(b) => setDetailsBooking(b)}
              onEditBooking={handleEditClick}
              onGenerateReceipt={(b) => setReceiptBooking(b)}
              onAddPayment={(b) => setPaymentBooking(b)}
              onCancelBooking={(b) => setCancelTargetBooking(b)}
              onDeleteBooking={handleDeleteBooking}
              onRemoveBookingLocally={handleRemoveBookingLocally}
              onNewBookingClick={handleNewBookingTab}
            />
          )}

          {activeTab === 'calendar' && (
            <CalendarView
              bookings={bookings}
              purchases={purchases}
              onViewBooking={(b) => setDetailsBooking(b)}
              onGenerateReceipt={(b) => setReceiptBooking(b)}
            />
          )}

          {activeTab === 'payments' && (
            <PaymentsView
              bookings={bookings}
              onAddPayment={(b) => setPaymentBooking(b)}
              onViewBooking={(b) => setDetailsBooking(b)}
              onGenerateReceipt={(b) => setReceiptBooking(b)}
            />
          )}

          {activeTab === 'internal-purchases' && (
            <InternalPurchasesView
              purchases={purchases}
              bookings={bookings}
              onAddPurchase={handleAddPurchase}
              onDeletePurchase={handleDeletePurchase}
            />
          )}

          {activeTab === 'cancelled-bookings' && (
            <CancelledBookingsView
              bookings={bookings}
              onViewBooking={(b) => setDetailsBooking(b)}
              onRestoreBooking={handleRestoreBooking}
              onDeletePermanently={handleDeleteBooking}
              onGenerateReceipt={(b) => setReceiptBooking(b)}
            />
          )}

          {activeTab === 'creator' && <CreatorPage />}
          {activeTab === 'backup-restore' && (
            <BackupRestore onRestored={async () => { await reloadData(); }} />
          )}
        </main>
      </div>

      {/* Booking Details Modal */}
      {detailsBooking && (
        <BookingDetailsModal
          booking={detailsBooking}
          purchases={purchases}
          onClose={() => setDetailsBooking(null)}
          onEdit={handleEditClick}
          onAddPayment={(b) => {
            setPaymentBooking(b);
          }}
          onGenerateReceipt={(b) => {
            setReceiptBooking(b);
          }}
          onCancel={(b) => {
            setCancelTargetBooking(b);
          }}
        />
      )}

      {/* Customer Receipt Modal with PDF export and print */}
      {receiptBooking && (
        <ReceiptModal
          booking={receiptBooking}
          onClose={() => setReceiptBooking(null)}
          logoUrl={customLogo}
        />
      )}

      {/* Add Payment Modal */}
      {paymentBooking && (
        <AddPaymentModal
          booking={paymentBooking}
          onClose={() => setPaymentBooking(null)}
          onSavePayment={handleSavePayment}
        />
      )}

      {/* Cancel Confirmation Modal */}
      {cancelTargetBooking && (
        <CancelBookingModal
          booking={cancelTargetBooking}
          onClose={() => setCancelTargetBooking(null)}
          onConfirmCancel={handleConfirmCancel}
        />
      )}
    </div>
  );
}

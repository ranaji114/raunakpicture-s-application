import React, { useMemo } from 'react';
import { 
  Calendar, 
  CreditCard, 
  PlusCircle, 
  XCircle, 
  CheckCircle2, 
  Clock, 
  ArrowRight,
  TrendingUp,
  FileText,
  Eye,
  Camera,
  MapPin
} from 'lucide-react';
import { ActiveTab, Booking, RAUNAK_BUSINESS_PROFILE } from '../types';
import { formatINR } from '../services/storage';

interface DashboardProps {
  bookings: Booking[];
  setActiveTab: (tab: ActiveTab) => void;
  onViewBooking: (booking: Booking) => void;
  onGenerateReceipt: (booking: Booking) => void;
  logoUrl?: string | null;
}

export const Dashboard: React.FC<DashboardProps> = ({
  bookings,
  setActiveTab,
  onViewBooking,
  onGenerateReceipt,
  logoUrl,
}) => {
  const activeBookings = useMemo(() => bookings.filter(b => b.status !== 'cancelled'), [bookings]);
  const cancelledCount = bookings.length - activeBookings.length;

  // Total active bookings count
  const totalBookingsCount = activeBookings.length;

  // Calculate upcoming events
  const todayStr = new Date().toISOString().split('T')[0];
  const upcomingEventsCount = useMemo(() => activeBookings.reduce((count, booking) =>
    count + booking.events.filter(event => event.date >= todayStr).length, 0), [activeBookings, todayStr]);

  // Financial totals strictly from active bookings
  const { totalBookingAmount, totalAdvanceReceived, totalPendingPayments } = useMemo(() => activeBookings.reduce((totals, booking) => ({
    totalBookingAmount: totals.totalBookingAmount + (booking.totalAmount || 0),
    totalAdvanceReceived: totals.totalAdvanceReceived + (booking.totalAdvance || 0),
    totalPendingPayments: totals.totalPendingPayments + (booking.remainingAmount || 0),
  }), { totalBookingAmount: 0, totalAdvanceReceived: 0, totalPendingPayments: 0 }), [activeBookings]);

  // 6 specific required cards
  const metricsCards = [
    {
      id: 'total-bookings',
      title: 'Total Bookings',
      value: totalBookingsCount.toString(),
      subtext: 'Active client contracts',
      icon: Camera,
      color: '#FFFFFF',
      accentColor: '#F5C542',
      targetTab: 'all-bookings' as ActiveTab,
    },
    {
      id: 'upcoming-events',
      title: 'Upcoming Events',
      value: upcomingEventsCount.toString(),
      subtext: 'Scheduled photo/video shoots',
      icon: Calendar,
      color: '#FFFFFF',
      accentColor: '#F5C542',
      targetTab: 'calendar' as ActiveTab,
    },
    {
      id: 'total-booking-amount',
      title: 'Total Booking Amount',
      value: formatINR(totalBookingAmount),
      subtext: 'Total value of active shoots',
      icon: TrendingUp,
      color: '#F5C542',
      accentColor: '#F5C542',
      targetTab: 'payments' as ActiveTab,
    },
    {
      id: 'advance-received',
      title: 'Advance Received',
      value: formatINR(totalAdvanceReceived),
      subtext: 'Advance deposits secured',
      icon: CheckCircle2,
      color: '#22C55E',
      accentColor: '#22C55E',
      targetTab: 'payments' as ActiveTab,
    },
    {
      id: 'pending-payments',
      title: 'Pending Payments',
      value: formatINR(totalPendingPayments),
      subtext: 'Balance receivable from clients',
      icon: Clock,
      color: totalPendingPayments > 0 ? '#F5C542' : '#22C55E',
      accentColor: totalPendingPayments > 0 ? '#F5C542' : '#22C55E',
      targetTab: 'payments' as ActiveTab,
    },
    {
      id: 'cancelled-bookings',
      title: 'Cancelled Bookings',
      value: cancelledCount.toString(),
      subtext: 'Archived cancelled records',
      icon: XCircle,
      color: cancelledCount > 0 ? '#EF4444' : '#A3A3A3',
      accentColor: '#EF4444',
      targetTab: 'cancelled-bookings' as ActiveTab,
    },
  ];

  // Quick action items as required:
  const quickActions = [
    {
      title: 'New Booking',
      desc: 'नया ग्राहक पंजीकरण करें',
      icon: PlusCircle,
      tab: 'new-booking' as ActiveTab,
      primary: true,
    },
    {
      title: 'All Bookings',
      desc: 'सभी बुकिंग देखें एवं प्रबंधित करें',
      icon: Camera,
      tab: 'all-bookings' as ActiveTab,
      primary: false,
    },
    {
      title: 'Calendar',
      desc: 'तारीखों के अनुसार शूट शेड्यूल',
      icon: Calendar,
      tab: 'calendar' as ActiveTab,
      primary: false,
    },
    {
      title: 'Payments',
      desc: 'भुगतान रिकॉर्ड एवं बाकी राशि',
      icon: CreditCard,
      tab: 'payments' as ActiveTab,
      primary: false,
    },
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Studio Banner / Welcome */}
      <div className="relative overflow-hidden rounded-xl bg-gradient-to-r from-[#151515] via-[#1C1C1C] to-[#151515] border border-white/10 p-6 sm:p-8 flex items-center justify-between">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#F5C542]/10 border border-[#F5C542]/30 text-[#F5C542] text-xs font-semibold uppercase tracking-wider mb-3">
            Raunak Pictures • Business Suite
          </div>
          <p className="mb-2 text-sm font-semibold text-[#F5C542]">Welcome back, {RAUNAK_BUSINESS_PROFILE.owner}!</p>
          <h2 className="text-2xl sm:text-3xl font-brand font-bold text-white tracking-wide">
            आपकी कल्पना, <span className="text-[#F5C542]">हमारी रचना..</span>
          </h2>
          <p className="mt-2 text-sm text-[#A3A3A3] font-hindi leading-relaxed">
            मुड़िला बाजार, कादीपुर रोड, सुल्तानपुर। फोटोग्राफी, वीडियोग्राफी एवं इवेंट मैनेजमेंट कंट्रोल सेंटर।
          </p>
        </div>

        {/* Studio Circular Logo in Banner */}
        <div className="hidden sm:block shrink-0 ml-4 relative z-10">
          <div className="w-24 h-24 lg:w-28 lg:h-28 rounded-full border-2 border-[#EF4444]/70 p-0.5 shadow-[0_0_30px_rgba(239,68,68,0.25)] overflow-hidden bg-[#0B0B0B]">
            <img
              src={logoUrl || '/assets/aistudio/logo.r_1362e06b.png'}
              alt="Raunak Pictures"
              className="w-full h-full object-cover rounded-full"
            />
          </div>
        </div>
      </div>

      {/* 6 Required Dashboard Cards */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold text-white tracking-wide flex items-center gap-2">
            <span>Key Business Metrics</span>
            <span className="text-xs text-[#A3A3A3] font-normal font-hindi">(वास्तविक आँकड़े)</span>
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {metricsCards.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.id}
                onClick={() => setActiveTab(card.targetTab)}
                className="group cursor-pointer rounded-lg bg-[#1C1C1C] border border-white/10 p-5 hover:border-[#F5C542]/40 transition-all hover:shadow-[0_8px_30px_rgba(0,0,0,0.5)] relative overflow-hidden"
              >
                <div 
                  className="absolute top-0 left-0 right-0 h-[2px] opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ backgroundColor: card.accentColor }}
                />
                
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-[11px] font-semibold tracking-wider uppercase text-[#A3A3A3]">
                      {card.title}
                    </p>
                    <p 
                      className="text-2xl sm:text-3xl font-bold mt-2 font-mono tracking-tight"
                      style={{ color: card.color }}
                    >
                      {card.value}
                    </p>
                    <p className="text-xs text-[#737373] mt-1.5 flex items-center gap-1">
                      {card.subtext}
                    </p>
                  </div>
                  <div 
                    className="p-2.5 rounded-lg bg-[#151515] border border-white/5 text-[#A3A3A3] group-hover:text-white transition-colors"
                  >
                    <Icon className="w-5 h-5" style={{ color: card.accentColor }} />
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-xs text-[#A3A3A3] group-hover:text-[#F5C542] transition-colors">
                  <span className="font-hindi text-[11px]">विवरण खोलें</span>
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-base font-semibold text-white tracking-wide mb-4">
          Quick Actions
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.title}
                onClick={() => setActiveTab(action.tab)}
                className={`p-4 rounded-lg text-left transition-all flex flex-col justify-between border ${
                  action.primary
                    ? 'bg-[#F5C542] text-[#0B0B0B] border-[#F5C542] hover:bg-[#DDAE30] shadow-[0_0_20px_rgba(245,197,66,0.15)]'
                    : 'bg-[#1C1C1C] text-white border-white/10 hover:border-[#F5C542]/40 hover:bg-[#201F1F]'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-3">
                  <span className="font-semibold text-sm">{action.title}</span>
                  <Icon className={`w-5 h-5 ${action.primary ? 'text-[#0B0B0B]' : 'text-[#F5C542]'}`} />
                </div>
                <div className={`text-xs font-hindi ${action.primary ? 'text-[#0B0B0B]/80 font-medium' : 'text-[#A3A3A3]'}`}>
                  {action.desc}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Recent Bookings Overview */}
      <div className="rounded-xl bg-[#1C1C1C] border border-white/10 overflow-hidden">
        <div className="p-5 border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-semibold text-white">Recent Client Bookings</h3>
            <p className="text-xs text-[#A3A3A3]">हाल ही में दर्ज की गई सक्रिय बुकिंग सूची</p>
          </div>
          <button
            onClick={() => setActiveTab('all-bookings')}
            className="text-xs text-[#F5C542] hover:underline flex items-center gap-1 font-medium"
          >
            <span>View All ({activeBookings.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {activeBookings.length === 0 ? (
          <div className="p-8 text-center text-[#737373]">
            <p className="font-hindi text-sm">अभी कोई सक्रिय बुकिंग उपलब्ध नहीं है।</p>
            <button
              onClick={() => setActiveTab('new-booking')}
              className="mt-3 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#F5C542] text-[#0B0B0B] text-xs font-semibold"
            >
              <PlusCircle className="w-4 h-4" />
              नई बुकिंग जोड़ें
            </button>
          </div>
        ) : (
          <div className="divide-y divide-white/5">
            {activeBookings.slice(0, 5).map((b) => {
              const primaryEvent = b.events[0];
              return (
                <div
                  key={b.id}
                  className="p-4 sm:p-5 hover:bg-white/[0.02] transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1.5 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-hindi font-semibold text-white text-base">
                        {b.customerName}
                      </span>
                      <span className="text-xs text-[#A3A3A3] font-mono">
                        {b.mobile}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-[#F5C542]/10 text-[#F5C542] border border-[#F5C542]/20 font-hindi">
                        {b.events.length} कार्यक्रम
                      </span>
                    </div>

                    {primaryEvent && (
                      <div className="flex items-center gap-3 text-xs text-[#A3A3A3] font-hindi">
                        <span className="flex items-center gap-1 text-[#F5C542]">
                          <Calendar className="w-3.5 h-3.5" />
                          {primaryEvent.date}
                        </span>
                        <span className="truncate">{primaryEvent.name}</span>
                        {primaryEvent.location && (
                          <span className="hidden sm:flex items-center gap-1 text-[#737373] truncate">
                            <MapPin className="w-3 h-3" />
                            {primaryEvent.location}
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between md:justify-end gap-4 pt-2 md:pt-0 border-t md:border-t-0 border-white/5">
                    <div className="text-left md:text-right">
                      <div className="text-sm font-bold font-mono text-white">
                        {formatINR(b.totalAmount)}
                      </div>
                      <div className="text-xs font-hindi">
                        {b.remainingAmount > 0 ? (
                          <span className="text-[#F5C542]">बाकी: {formatINR(b.remainingAmount)}</span>
                        ) : (
                          <span className="text-[#22C55E]">पूर्ण भुगतान</span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onViewBooking(b)}
                        className="p-2 rounded bg-[#151515] hover:bg-white/10 text-[#A3A3A3] hover:text-white border border-white/10 text-xs transition-colors"
                        title="विवरण देखें"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onGenerateReceipt(b)}
                        className="px-3 py-1.5 rounded bg-[#F5C542]/10 hover:bg-[#F5C542]/20 text-[#F5C542] border border-[#F5C542]/30 text-xs font-medium flex items-center gap-1.5 transition-colors"
                        title="रसीद बनाएं"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Receipt</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

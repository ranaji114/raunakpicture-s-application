import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Calendar, 
  MapPin, 
  Package, 
  CreditCard, 
  Save, 
  X,
  AlertCircle,
  Sparkles,
  Info
} from 'lucide-react';
import { Booking, EventItem, ServiceItem, PaymentMethod, PaymentItem } from '../types';
import { 
  DEFAULT_SERVICES, 
  MAIN_PACKAGE_HINDI_NAME, 
  calculateBookingFinancials, 
  formatINR 
} from '../services/storage';

interface BookingFormProps {
  initialBooking?: Booking | null;
  onSave: (booking: Booking) => void;
  onCancel: () => void;
}

export const BookingForm: React.FC<BookingFormProps> = ({
  initialBooking,
  onSave,
  onCancel,
}) => {
  // Customer Details (हिंदी)
  const [customerName, setCustomerName] = useState(initialBooking?.customerName || '');
  const [mobile, setMobile] = useState(initialBooking?.mobile || '');
  const [address, setAddress] = useState(initialBooking?.address || '');

  // Event Details (Multiple events & dates support)
  const [events, setEvents] = useState<EventItem[]>(
    initialBooking?.events?.length
      ? initialBooking.events
      : [
          {
            id: 'ev-' + Date.now(),
            name: 'शुभ विवाह (मुख्य समारोह)',
            date: new Date().toISOString().split('T')[0],
            location: '',
            notes: '',
          },
        ]
  );

  // Main Package State
  const initialMainPkg = initialBooking?.services.find(s => s.isMainPackage);
  const [includeMainPackage, setIncludeMainPackage] = useState<boolean>(
    initialBooking ? !!initialMainPkg : true
  );
  const [mainPackagePrice, setMainPackagePrice] = useState<number | ''>(
    initialMainPkg ? initialMainPkg.price : 45000
  );

  // Additional & Custom Services
  const [selectedServices, setSelectedServices] = useState<ServiceItem[]>(() => {
    if (initialBooking) {
      return initialBooking.services.filter(s => !s.isMainPackage);
    }
    // Default none pre-selected other than main package
    return [];
  });

  // Custom service input row for Hindi form
  const [newServiceName, setNewServiceName] = useState('');
  const [newServicePrice, setNewServicePrice] = useState<number | ''>('');
  const [newServiceQty, setNewServiceQty] = useState<number>(1);

  // Advance Payment inputs (for new booking or initial advance adjustments)
  const initialAdvance = initialBooking?.payments?.find(p => p.isAdvance) || initialBooking?.payments?.[0];
  const [advanceAmount, setAdvanceAmount] = useState<number | ''>(
    initialAdvance ? initialAdvance.amount : 10000
  );
  const [advanceDate, setAdvanceDate] = useState<string>(
    initialAdvance?.date || new Date().toISOString().split('T')[0]
  );
  const [advanceMethod, setAdvanceMethod] = useState<PaymentMethod>(
    initialAdvance?.method || 'नकद'
  );
  const [advanceNotes, setAdvanceNotes] = useState<string>(
    initialAdvance?.notes || 'बुकिंग के समय अग्रिम भुगतान'
  );

  // Preserved other payments if editing
  const existingOtherPayments: PaymentItem[] = (initialBooking?.payments || []).filter(
    p => p.id !== initialAdvance?.id
  );

  // Validation errors in Hindi
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Common additional service templates
  const availableServicePresets = [
    { name: 'कैंडिड फोटोग्राफी (Candid Photography)', defaultPrice: 12000 },
    { name: 'सिनेमैटिक वीडियो (Cinematic Video)', defaultPrice: 15000 },
    { name: 'क्रेन / एलईडी (Crane / LED)', defaultPrice: 8000 },
    { name: 'एलईडी वॉल (LED Wall)', defaultPrice: 18000 },
    { name: 'नंबर शीट (Number Sheet)', defaultPrice: 2500 },
  ];

  // Handlers for Events
  const addEventRow = () => {
    const newEv: EventItem = {
      id: 'ev-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
      name: '',
      date: new Date().toISOString().split('T')[0],
      location: '',
      notes: '',
    };
    setEvents([...events, newEv]);
  };

  const removeEventRow = (id: string) => {
    if (events.length <= 1) {
      setErrorMessage('कम से कम एक कार्यक्रम जोड़ना अनिवार्य है।');
      return;
    }
    setEvents(events.filter(e => e.id !== id));
  };

  const updateEventField = (id: string, field: keyof EventItem, value: string) => {
    setEvents(events.map(ev => (ev.id === id ? { ...ev, [field]: value } : ev)));
  };

  // Toggle Preset Additional Service
  const togglePresetService = (name: string, defaultPrice: number) => {
    const existingIndex = selectedServices.findIndex(s => s.name === name);
    if (existingIndex >= 0) {
      setSelectedServices(selectedServices.filter((_, idx) => idx !== existingIndex));
    } else {
      setSelectedServices([
        ...selectedServices,
        {
          id: 'srv-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
          name,
          quantity: 1,
          price: defaultPrice,
          total: defaultPrice,
          isMainPackage: false,
        },
      ]);
    }
  };

  // Add custom service via Hindi form
  const handleAddCustomService = () => {
    if (!newServiceName.trim()) {
      setErrorMessage('कृपया सेवा का नाम दर्ज करें।');
      return;
    }
    const priceNum = Number(newServicePrice) || 0;
    const qtyNum = Number(newServiceQty) || 1;
    if (priceNum < 0 || qtyNum <= 0) {
      setErrorMessage('कृपया सही मात्रा एवं कीमत दर्ज करें।');
      return;
    }

    const newSrv: ServiceItem = {
      id: 'srv-custom-' + Date.now(),
      name: newServiceName.trim(),
      quantity: qtyNum,
      price: priceNum,
      total: priceNum * qtyNum,
      isMainPackage: false,
    };

    setSelectedServices([...selectedServices, newSrv]);
    setNewServiceName('');
    setNewServicePrice('');
    setNewServiceQty(1);
    setErrorMessage(null);
  };

  // Remove a service row
  const removeServiceRow = (id: string) => {
    setSelectedServices(selectedServices.filter(s => s.id !== id));
  };

  // Update existing service quantity or price
  const updateServiceRow = (id: string, field: 'quantity' | 'price', value: number) => {
    setSelectedServices(
      selectedServices.map(s => {
        if (s.id !== id) return s;
        const newQty = field === 'quantity' ? Math.max(1, value) : s.quantity;
        const newPrice = field === 'price' ? Math.max(0, value) : s.price;
        return {
          ...s,
          quantity: newQty,
          price: newPrice,
          total: newQty * newPrice,
        };
      })
    );
  };

  // Calculate live compiled services
  const compiledServices: ServiceItem[] = [];
  if (includeMainPackage) {
    compiledServices.push({
      id: initialMainPkg ? initialMainPkg.id : 'srv-main-pkg',
      name: MAIN_PACKAGE_HINDI_NAME,
      quantity: 1,
      price: Number(mainPackagePrice) || 0,
      total: Number(mainPackagePrice) || 0,
      isMainPackage: true,
    });
  }
  selectedServices.forEach(s => compiledServices.push(s));

  // Current calculated payments
  const currentPayments: PaymentItem[] = [];
  const advNum = Number(advanceAmount) || 0;
  if (advNum > 0) {
    currentPayments.push({
      id: initialAdvance ? initialAdvance.id : 'pay-adv-' + Date.now(),
      date: advanceDate,
      amount: advNum,
      method: advanceMethod,
      notes: advanceNotes,
      isAdvance: true,
    });
  }
  existingOtherPayments.forEach(p => currentPayments.push(p));

  const financials = calculateBookingFinancials(compiledServices, currentPayments);

  // Form submission handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Validations in Hindi
    if (!customerName.trim()) {
      setErrorMessage('कृपया ग्राहक का नाम दर्ज करें।');
      return;
    }
    if (!mobile.trim() || mobile.trim().length < 10) {
      setErrorMessage('कृपया 10 अंकों का वैध मोबाइल नंबर दर्ज करें।');
      return;
    }
    if (events.length === 0) {
      setErrorMessage('कम से कम एक कार्यक्रम जोड़ना आवश्यक है।');
      return;
    }
    for (let i = 0; i < events.length; i++) {
      if (!events[i].name.trim()) {
        setErrorMessage(`कृपया कार्यक्रम क्रमांक ${i + 1} का नाम दर्ज करें।`);
        return;
      }
      if (!events[i].date) {
        setErrorMessage(`कृपया कार्यक्रम क्रमांक ${i + 1} की तारीख चुनें।`);
        return;
      }
    }
    if (compiledServices.length === 0) {
      setErrorMessage('कृपया कम से कम एक सेवा या मुख्य पैकेज चुनें।');
      return;
    }
    if (financials.totalAmount <= 0) {
      setErrorMessage('कुल बुकिंग राशि 0 से अधिक होनी चाहिए।');
      return;
    }

    const bookingPayload: Booking = {
      id: initialBooking ? initialBooking.id : 'rp-book-' + Date.now(),
      customerName: customerName.trim(),
      mobile: mobile.trim(),
      address: address.trim(),
      events: events.map(e => ({
        ...e,
        name: e.name.trim(),
        location: e.location?.trim() || '',
        notes: e.notes?.trim() || '',
      })),
      services: compiledServices,
      payments: currentPayments,
      totalAmount: financials.totalAmount,
      totalAdvance: financials.totalAdvance,
      totalPaid: financials.totalPaid,
      remainingAmount: financials.remainingAmount,
      status: initialBooking ? initialBooking.status : 'active',
      cancellationReason: initialBooking?.cancellationReason,
      cancelledAt: initialBooking?.cancelledAt,
      createdAt: initialBooking ? initialBooking.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSave(bookingPayload);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Top Banner */}
      <div className="p-4 rounded-xl bg-[#151515] border border-white/10 flex items-center justify-between">
        <div>
          <span className="text-xs px-2.5 py-0.5 rounded bg-[#F5C542]/10 text-[#F5C542] border border-[#F5C542]/20 font-hindi">
            {initialBooking ? 'बुकिंग संशोधन (Edit Booking)' : 'नई बुकिंग प्रविष्टि'}
          </span>
          <h2 className="text-xl font-bold text-white font-hindi mt-1">
            {initialBooking ? 'बुकिंग विवरण संपादित करें' : 'नया ग्राहक एवं कार्यक्रम पंजीकरण'}
          </h2>
        </div>
        <button
          onClick={onCancel}
          className="p-2 rounded-lg bg-[#1C1C1C] text-[#A3A3A3] hover:text-white border border-white/10 transition-colors"
          title="रद्द करें"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Error alert in Hindi */}
      {errorMessage && (
        <div className="p-4 rounded-lg bg-[#EF4444]/15 border border-[#EF4444]/40 text-[#EF4444] flex items-center gap-3 font-hindi text-sm">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6 font-hindi">
        {/* 1. Customer Details (ग्राहक का विवरण) */}
        <div className="rounded-xl bg-[#1C1C1C] border border-white/10 p-5 sm:p-6 space-y-4">
          <div className="border-b border-white/10 pb-3 flex items-center justify-between">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#F5C542]" />
              ग्राहक का विवरण (Customer Details)
            </h3>
            <span className="text-xs text-[#A3A3A3]">* सभी अनिवार्य फ़ील्ड भरें</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-[#A3A3A3] mb-1.5">
                ग्राहक का नाम *
              </label>
              <input
                type="text"
                value={customerName}
                onChange={e => setCustomerName(e.target.value)}
                placeholder="उदा. अमित कुमार सिंह"
                required
                className="w-full h-12 px-3.5 rounded bg-[#151515] border border-white/15 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none focus:ring-1 focus:ring-[#F5C542] text-base"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#A3A3A3] mb-1.5">
                मोबाइल नंबर * (WhatsApp / संपर्क)
              </label>
              <input
                type="tel"
                value={mobile}
                onChange={e => setMobile(e.target.value.replace(/\D/g, '').slice(0, 10))}
                placeholder="उदा. 9838123456"
                required
                className="w-full h-12 px-3.5 rounded bg-[#151515] border border-white/15 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none focus:ring-1 focus:ring-[#F5C542] text-base font-mono"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-sm font-semibold text-[#A3A3A3] mb-1.5">
                पता (Address)
              </label>
              <input
                type="text"
                value={address}
                onChange={e => setAddress(e.target.value)}
                placeholder="उदा. मुड़िला बाजार, कादीपुर रोड, सुल्तानपुर"
                className="w-full h-12 px-3.5 rounded bg-[#151515] border border-white/15 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none focus:ring-1 focus:ring-[#F5C542] text-base"
              />
            </div>
          </div>
        </div>

        {/* 2. Event Details (Multiple events and multiple dates) */}
        <div className="rounded-xl bg-[#1C1C1C] border border-white/10 p-5 sm:p-6 space-y-4">
          <div className="border-b border-white/10 pb-3 flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#F5C542]" />
                कार्यक्रम एवं तारीखें (Event Details & Dates)
              </h3>
              <p className="text-xs text-[#A3A3A3] mt-0.5">
                एक बुकिंग में कई कार्यक्रम एवं अलग-अलग तारीखें जोड़ सकते हैं (सगाई, हल्दी, विवाह, आदि)
              </p>
            </div>
            <button
              type="button"
              onClick={addEventRow}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F5C542]/10 hover:bg-[#F5C542]/20 text-[#F5C542] border border-[#F5C542]/30 text-xs font-semibold transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>कार्यक्रम जोड़ें</span>
            </button>
          </div>

          <div className="space-y-4">
            {events.map((ev, idx) => (
              <div 
                key={ev.id} 
                className="p-4 rounded-lg bg-[#151515] border border-white/10 relative space-y-3"
              >
                <div className="flex items-center justify-between pb-2 border-b border-white/5">
                  <span className="text-xs font-bold text-[#F5C542] flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5" />
                    कार्यक्रम #{idx + 1}
                  </span>
                  {events.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeEventRow(ev.id)}
                      className="text-xs text-[#EF4444] hover:text-red-400 flex items-center gap-1 p-1"
                      title="कार्यक्रम हटाएं"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>कार्यक्रम हटाएं</span>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-sm font-semibold text-[#A3A3A3] mb-1">
                      कार्यक्रम का नाम *
                    </label>
                    <input
                      type="text"
                      value={ev.name}
                      onChange={e => updateEventField(ev.id, 'name', e.target.value)}
                      placeholder="उदा. शुभ विवाह, तिलक, सगाई"
                      required
                      className="w-full h-11 px-3 rounded bg-[#1C1C1C] border border-white/15 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none text-base"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#A3A3A3] mb-1">
                      कार्यक्रम की तारीख *
                    </label>
                    <input
                      type="date"
                      value={ev.date}
                      onChange={e => updateEventField(ev.id, 'date', e.target.value)}
                      required
                      className="w-full h-11 px-3 rounded bg-[#1C1C1C] border border-white/15 text-white focus:border-[#F5C542] focus:outline-none text-base [color-scheme:dark]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#A3A3A3] mb-1">
                      कार्यक्रम का स्थान
                    </label>
                    <input
                      type="text"
                      value={ev.location || ''}
                      onChange={e => updateEventField(ev.id, 'location', e.target.value)}
                      placeholder="उदा. कादीपुर मैरिज लॉन"
                      className="w-full h-11 px-3 rounded bg-[#1C1C1C] border border-white/15 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none text-base"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#A3A3A3] mb-1">
                      अन्य जानकारी
                    </label>
                    <input
                      type="text"
                      value={ev.notes || ''}
                      onChange={e => updateEventField(ev.id, 'notes', e.target.value)}
                      placeholder="उदा. शाम 7 बजे से"
                      className="w-full h-11 px-3 rounded bg-[#1C1C1C] border border-white/15 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none text-base"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 3. Services and Pricing (सेवाएँ एवं मूल्य निर्धारण) */}
        <div className="rounded-xl bg-[#1C1C1C] border border-white/10 p-5 sm:p-6 space-y-5">
          <div className="border-b border-white/10 pb-3">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#F5C542]" />
              सेवाएँ एवं मूल्य निर्धारण (Services & Pricing)
            </h3>
            <p className="text-xs text-[#A3A3A3] mt-0.5">
              मुख्य पैकेज में फोटोग्राफी, वीडियोग्राफी, ड्रोन एवं एल्बम एक साथ सम्मिलित हैं। अतिरिक्त सेवाएँ अलग से जोड़ें।
            </p>
          </div>

          {/* Main Package Card */}
          <div className={`p-4 rounded-lg border transition-all ${
            includeMainPackage 
              ? 'bg-[#151515] border-[#F5C542]/40 shadow-[0_0_20px_rgba(245,197,66,0.05)]' 
              : 'bg-[#151515]/50 border-white/5 opacity-60'
          }`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeMainPackage}
                  onChange={e => setIncludeMainPackage(e.target.checked)}
                  className="mt-1 w-4 h-4 accent-[#F5C542] rounded"
                />
                <div>
                  <div className="font-bold text-white text-sm flex items-center gap-2">
                    <span>{MAIN_PACKAGE_HINDI_NAME}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-[#F5C542]/20 text-[#F5C542] font-mono">
                      RECOMMENDED
                    </span>
                  </div>
                  <p className="text-xs text-[#A3A3A3] mt-1">
                    सम्मिलित: पारम्परिक फोटोग्राफी + फुल एचडी वीडियोग्राफी + ड्रोन कवरेज + प्रीमियम फोटो एल्बम
                  </p>
                </div>
              </label>

              {includeMainPackage && (
                <div className="flex items-center gap-2 pl-7 sm:pl-0">
                  <span className="text-xs text-[#A3A3A3] whitespace-nowrap">पैकेज कीमत (₹):</span>
                  <input
                    type="number"
                    min="0"
                    step="500"
                    value={mainPackagePrice}
                    onChange={e => {
                      const raw = e.target.value;
                      setMainPackagePrice(raw === '' ? '' : Math.max(0, Number(raw)));
                    }}
                    className="w-32 h-10 px-3 rounded bg-[#1C1C1C] border border-white/20 text-white font-mono font-bold focus:border-[#F5C542] focus:outline-none text-right"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Additional Preset Services Buttons */}
          <div>
            <label className="block text-xs font-semibold text-[#A3A3A3] mb-2">
              अतिरिक्त सेवाएँ चुनें (त्वरित चयन)
            </label>
            <div className="flex flex-wrap gap-2">
              {availableServicePresets.map(preset => {
                const isSelected = selectedServices.some(s => s.name === preset.name);
                return (
                  <button
                    key={preset.name}
                    type="button"
                    onClick={() => togglePresetService(preset.name, preset.defaultPrice)}
                    className={`px-3 py-2 rounded-lg text-xs font-medium border transition-all flex items-center gap-2 ${
                      isSelected
                        ? 'bg-[#F5C542]/20 text-[#F5C542] border-[#F5C542]/50'
                        : 'bg-[#151515] text-[#A3A3A3] border-white/10 hover:border-white/25 hover:text-white'
                    }`}
                  >
                    <span>{preset.name}</span>
                    <span className="font-mono text-[11px] text-[#737373]">
                      ({formatINR(preset.defaultPrice)})
                    </span>
                    {isSelected && <span className="text-xs">✓</span>}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom Service Hindi Form */}
          <div className="p-4 rounded-lg bg-[#151515] border border-white/10 space-y-3">
            <h4 className="text-xs font-bold text-[#F5C542] uppercase tracking-wider flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5" />
              कस्टम सेवा जोड़ें (Add Custom Service)
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
              <div className="sm:col-span-5">
                <label className="block text-[11px] font-semibold text-[#A3A3A3] mb-1">
                  सेवा का नाम
                </label>
                <input
                  type="text"
                  value={newServiceName}
                  onChange={e => setNewServiceName(e.target.value)}
                  placeholder="उदा. एक्स्ट्रा एल्बम, प्री-वेडिंग शूट"
                  className="w-full h-10 px-3 rounded bg-[#1C1C1C] border border-white/15 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none text-xs"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[11px] font-semibold text-[#A3A3A3] mb-1">
                  मात्रा (Qty)
                </label>
                <input
                  type="number"
                  min="1"
                  value={newServiceQty}
                  onChange={e => setNewServiceQty(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full h-10 px-3 rounded bg-[#1C1C1C] border border-white/15 text-white focus:border-[#F5C542] focus:outline-none text-xs font-mono text-center"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block text-[11px] font-semibold text-[#A3A3A3] mb-1">
                  कीमत प्रति इकाई (₹)
                </label>
                <input
                  type="number"
                  min="0"
                  step="100"
                  value={newServicePrice}
                  onChange={e => setNewServicePrice(e.target.value === '' ? '' : Math.max(0, Number(e.target.value)))}
                  placeholder="0"
                  className="w-full h-10 px-3 rounded bg-[#1C1C1C] border border-white/15 text-white focus:border-[#F5C542] focus:outline-none text-xs font-mono text-right"
                />
              </div>

              <div className="sm:col-span-2">
                <button
                  type="button"
                  onClick={handleAddCustomService}
                  className="w-full h-10 px-3 rounded bg-[#F5C542] hover:bg-[#DDAE30] text-[#0B0B0B] text-xs font-bold transition-colors flex items-center justify-center gap-1"
                >
                  <Plus className="w-4 h-4" />
                  <span>सेवा जोड़ें</span>
                </button>
              </div>
            </div>
          </div>

          {/* Selected Additional Services List */}
          {selectedServices.length > 0 && (
            <div className="border border-white/10 rounded-lg overflow-hidden">
              <div className="bg-[#151515] px-4 py-2 text-xs font-bold text-[#A3A3A3] grid grid-cols-12 gap-2 border-b border-white/10">
                <span className="col-span-5">सेवा का नाम</span>
                <span className="col-span-2 text-center">मात्रा</span>
                <span className="col-span-2 text-right">कीमत</span>
                <span className="col-span-2 text-right">कुल राशि</span>
                <span className="col-span-1 text-center">हटाएं</span>
              </div>
              <div className="divide-y divide-white/5">
                {selectedServices.map(srv => (
                  <div key={srv.id} className="px-4 py-2.5 text-xs grid grid-cols-12 gap-2 items-center">
                    <span className="col-span-5 text-white font-medium truncate">
                      {srv.name}
                    </span>
                    <div className="col-span-2 text-center">
                      <input
                        type="number"
                        min="1"
                        value={srv.quantity}
                        onChange={e => updateServiceRow(srv.id, 'quantity', parseInt(e.target.value) || 1)}
                        className="w-14 h-7 px-1.5 rounded bg-[#151515] border border-white/15 text-white text-center font-mono text-xs focus:border-[#F5C542] focus:outline-none"
                      />
                    </div>
                    <div className="col-span-2 text-right">
                      <input
                        type="number"
                        min="0"
                        step="100"
                        value={srv.price}
                        onChange={e => updateServiceRow(srv.id, 'price', Number(e.target.value) || 0)}
                        className="w-20 h-7 px-1.5 rounded bg-[#151515] border border-white/15 text-white text-right font-mono text-xs focus:border-[#F5C542] focus:outline-none"
                      />
                    </div>
                    <span className="col-span-2 text-right text-[#F5C542] font-mono font-bold">
                      {formatINR(srv.total)}
                    </span>
                    <div className="col-span-1 text-center">
                      <button
                        type="button"
                        onClick={() => removeServiceRow(srv.id)}
                        className="text-[#EF4444] hover:text-red-400 p-1"
                        title="सेवा हटाएं"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* 4. Payment Management & Advance (भुगतान प्रबंधन) */}
        <div className="rounded-xl bg-[#1C1C1C] border border-white/10 p-5 sm:p-6 space-y-4">
          <div className="border-b border-white/10 pb-3">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#22C55E]" />
              भुगतान प्रबंधन (Payment & Advance)
            </h3>
            <p className="text-xs text-[#A3A3A3] mt-0.5">
              बुकिंग के समय प्राप्त अग्रिम भुगतान दर्ज करें। बाकी राशि का स्वतः हिसाब होगा।
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#A3A3A3] mb-1.5">
                अग्रिम भुगतान राशि (₹)
              </label>
              <input
                type="number"
                min="0"
                step="500"
                value={advanceAmount}
                onChange={e => setAdvanceAmount(e.target.value === '' ? '' : Math.max(0, Number(e.target.value)))}
                placeholder="0"
                className="w-full h-11 px-3.5 rounded bg-[#151515] border border-white/15 text-white font-mono font-bold text-base focus:border-[#22C55E] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A3A3A3] mb-1.5">
                भुगतान की तारीख
              </label>
              <input
                type="date"
                value={advanceDate}
                onChange={e => setAdvanceDate(e.target.value)}
                className="w-full h-11 px-3.5 rounded bg-[#151515] border border-white/15 text-white focus:border-[#F5C542] focus:outline-none text-xs [color-scheme:dark]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A3A3A3] mb-1.5">
                भुगतान का माध्यम
              </label>
              <select
                value={advanceMethod}
                onChange={e => setAdvanceMethod(e.target.value as PaymentMethod)}
                className="w-full h-11 px-3.5 rounded bg-[#151515] border border-white/15 text-white focus:border-[#F5C542] focus:outline-none text-xs"
              >
                <option value="नकद">नकद (Cash)</option>
                <option value="UPI">UPI (PhonePe / GPay / Paytm)</option>
                <option value="बैंक">बैंक ट्रांसफर (NEFT / RTGS)</option>
                <option value="अन्य">अन्य</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A3A3A3] mb-1.5">
                भुगतान से संबंधित जानकारी
              </label>
              <input
                type="text"
                value={advanceNotes}
                onChange={e => setAdvanceNotes(e.target.value)}
                placeholder="उदा. रसीद / ट्रांजेक्शन ID"
                className="w-full h-11 px-3.5 rounded bg-[#151515] border border-white/15 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none text-xs"
              />
            </div>
          </div>
        </div>

        {/* 5. Live Calculation Summary Card */}
        <div className="p-5 rounded-xl bg-gradient-to-r from-[#151515] to-[#1C1C1C] border border-[#F5C542]/30 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center sm:text-left">
            <span className="text-xs font-bold text-[#F5C542] uppercase tracking-wider">
              बुकिंग का वित्तीय विवरण (Financial Summary)
            </span>
            <div className="text-xs text-[#A3A3A3]">
              स्वचालित गणना सूत्र: बाकी राशि = कुल बुकिंग राशि - प्राप्त भुगतान
            </div>
          </div>

          <div className="flex items-center gap-6 text-center">
            <div>
              <div className="text-[11px] text-[#A3A3A3] uppercase">कुल बुकिंग राशि</div>
              <div className="text-lg sm:text-xl font-bold font-mono text-white">
                {formatINR(financials.totalAmount)}
              </div>
            </div>

            <div className="w-px h-8 bg-white/10" />

            <div>
              <div className="text-[11px] text-[#A3A3A3] uppercase">अग्रिम प्राप्त</div>
              <div className="text-lg sm:text-xl font-bold font-mono text-[#22C55E]">
                {formatINR(financials.totalPaid)}
              </div>
            </div>

            <div className="w-px h-8 bg-white/10" />

            <div>
              <div className="text-[11px] text-[#A3A3A3] uppercase">बाकी राशि</div>
              <div className="text-lg sm:text-xl font-bold font-mono text-[#F5C542]">
                {formatINR(financials.remainingAmount)}
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons in Hindi */}
        <div className="flex flex-col-reverse sm:flex-row items-center justify-end gap-3 pt-4 border-t border-white/10">
          <button
            type="button"
            onClick={onCancel}
            className="w-full sm:w-auto px-6 py-3 rounded-lg bg-transparent border border-white/20 text-white hover:bg-white/5 font-semibold text-sm transition-all"
          >
            रद्द करें (Cancel)
          </button>

          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-3 rounded-lg bg-[#F5C542] text-[#0B0B0B] font-bold text-sm hover:bg-[#DDAE30] active:scale-95 transition-all shadow-[0_0_25px_rgba(245,197,66,0.25)] flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>{initialBooking ? 'बुकिंग अपडेट करें' : 'बुकिंग सेव करें (Save Booking)'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};

import React from 'react';
import { 
  X, 
  Calendar, 
  Phone, 
  MapPin, 
  CreditCard, 
  Package, 
  FileText, 
  Edit3, 
  XCircle, 
  PlusCircle, 
  ShieldAlert,
  CheckCircle,
  Clock,
  Lock
} from 'lucide-react';
import { Booking, InternalPurchase } from '../types';
import { formatINR } from '../services/storage';

interface BookingDetailsModalProps {
  booking: Booking;
  purchases: InternalPurchase[];
  onClose: () => void;
  onEdit: (booking: Booking) => void;
  onAddPayment: (booking: Booking) => void;
  onGenerateReceipt: (booking: Booking) => void;
  onCancel: (booking: Booking) => void;
}

export const BookingDetailsModal: React.FC<BookingDetailsModalProps> = ({
  booking,
  purchases,
  onClose,
  onEdit,
  onAddPayment,
  onGenerateReceipt,
  onCancel,
}) => {
  // Find private internal purchases associated with this booking
  const relatedPurchases = purchases.filter(p => p.bookingId === booking.id);
  const totalInternalExpense = relatedPurchases.reduce((sum, p) => sum + (p.amount || 0), 0);
  const isFullyPaid = booking.remainingAmount <= 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-[#1C1C1C] border border-white/10 rounded-2xl shadow-2xl overflow-hidden my-8 max-h-[90vh] flex flex-col font-hindi">
        {/* Header */}
        <div className="p-5 sm:p-6 bg-[#151515] border-b border-white/10 flex items-center justify-between sticky top-0 z-10">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs px-2.5 py-0.5 rounded bg-[#F5C542]/20 text-[#F5C542] border border-[#F5C542]/30 font-medium">
                बुकिंग विवरण
              </span>
              <span className="text-xs text-[#737373] font-mono">ID: {booking.id}</span>
              {booking.status === 'cancelled' && (
                <span className="text-xs px-2.5 py-0.5 rounded bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/30">
                  रद्द की गई बुकिंग (Cancelled)
                </span>
              )}
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white mt-1">
              {booking.customerName}
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-[#1C1C1C] text-[#A3A3A3] hover:text-white border border-white/10 transition-colors"
            title="बंद करें"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto flex-1">
          {/* Top Info Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Customer Details */}
            <div className="p-4 rounded-xl bg-[#151515] border border-white/10 space-y-2.5">
              <h3 className="text-xs font-bold text-[#F5C542] uppercase tracking-wider">
                ग्राहक की जानकारी
              </h3>
              <div className="space-y-1.5 text-sm">
                <div className="flex items-center gap-2 text-white">
                  <span className="text-xs text-[#A3A3A3]">नाम:</span>
                  <span className="font-semibold">{booking.customerName}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#A3A3A3]">मोबाइल:</span>
                  <a href={`tel:${booking.mobile}`} className="font-mono text-[#F5C542] hover:underline flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5" />
                    {booking.mobile}
                  </a>
                </div>
                {booking.address && (
                  <div className="flex items-start gap-2 text-[#D1C5AE]">
                    <MapPin className="w-4 h-4 text-[#A3A3A3] shrink-0 mt-0.5" />
                    <span>{booking.address}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Financial Overview Card */}
            <div className="p-4 rounded-xl bg-[#151515] border border-white/10 space-y-3">
              <h3 className="text-xs font-bold text-[#F5C542] uppercase tracking-wider">
                वित्तीय स्थिति (Payment Summary)
              </h3>
              <div className="grid grid-cols-3 gap-2 text-center pt-1">
                <div className="bg-[#1C1C1C] p-2.5 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#A3A3A3] block">कुल राशि</span>
                  <span className="text-base font-bold font-mono text-white">
                    {formatINR(booking.totalAmount)}
                  </span>
                </div>
                <div className="bg-[#1C1C1C] p-2.5 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#A3A3A3] block">प्राप्त भुगतान</span>
                  <span className="text-base font-bold font-mono text-[#22C55E]">
                    {formatINR(booking.totalPaid)}
                  </span>
                </div>
                <div className="bg-[#1C1C1C] p-2.5 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#A3A3A3] block">बाकी राशि</span>
                  <span className={`text-base font-bold font-mono ${isFullyPaid ? 'text-[#22C55E]' : 'text-[#F5C542]'}`}>
                    {formatINR(booking.remainingAmount)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Cancellation Notice if cancelled */}
          {booking.status === 'cancelled' && (
            <div className="p-4 rounded-xl bg-[#EF4444]/15 border border-[#EF4444]/30 text-white space-y-1">
              <div className="flex items-center gap-2 text-[#EF4444] font-bold text-sm">
                <ShieldAlert className="w-4 h-4" />
                <span>यह बुकिंग रद्द की जा चुकी है</span>
              </div>
              <p className="text-xs text-[#D1C5AE]">
                रद्द करने का कारण: <strong className="text-white">{booking.cancellationReason || 'ग्राहक द्वारा अनुरोध'}</strong>
              </p>
              {booking.cancelledAt && (
                <p className="text-[11px] text-[#737373]">
                  तारीख: {new Date(booking.cancelledAt).toLocaleString('hi-IN')}
                </p>
              )}
            </div>
          )}

          {/* All Events & Dates */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#F5C542]" />
              <span>कार्यक्रम एवं तारीखें ({booking.events.length})</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {booking.events.map((ev, i) => (
                <div key={ev.id || i} className="p-3.5 rounded-xl bg-[#151515] border border-white/10 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs px-2 py-0.5 rounded bg-[#F5C542]/10 text-[#F5C542] font-mono font-medium">
                      तारीख: {ev.date}
                    </span>
                    <span className="text-xs text-[#737373]">#{i + 1}</span>
                  </div>
                  <h4 className="font-bold text-white text-sm">{ev.name}</h4>
                  {ev.location && (
                    <p className="text-xs text-[#A3A3A3] flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#F5C542] shrink-0" />
                      <span>{ev.location}</span>
                    </p>
                  )}
                  {ev.notes && (
                    <p className="text-xs text-[#737373] italic">
                      नोट: {ev.notes}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Selected Services & Prices */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Package className="w-4 h-4 text-[#F5C542]" />
              <span>चुनी गई सेवाएँ एवं मूल्य</span>
            </h3>
            <div className="rounded-xl bg-[#151515] border border-white/10 overflow-hidden">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#1C1C1C] text-[#A3A3A3] border-b border-white/10">
                  <tr>
                    <th className="p-3">सेवा का नाम</th>
                    <th className="p-3 text-center">मात्रा</th>
                    <th className="p-3 text-right">दर (Price)</th>
                    <th className="p-3 text-right">कुल राशि</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {booking.services.map((srv, idx) => (
                    <tr key={srv.id || idx} className="hover:bg-white/[0.02]">
                      <td className="p-3 font-medium text-white">
                        {srv.name}
                        {srv.isMainPackage && (
                          <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded bg-[#F5C542]/10 text-[#F5C542]">
                            Main Package
                          </span>
                        )}
                      </td>
                      <td className="p-3 text-center text-[#A3A3A3] font-mono">{srv.quantity}</td>
                      <td className="p-3 text-right text-[#A3A3A3] font-mono">{formatINR(srv.price)}</td>
                      <td className="p-3 text-right text-white font-mono font-bold">{formatINR(srv.total)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-[#1C1C1C] border-t border-white/10 font-bold">
                  <tr>
                    <td colSpan={3} className="p-3 text-right text-white">कुल बुकिंग राशि:</td>
                    <td className="p-3 text-right font-mono text-[#F5C542] text-sm">
                      {formatINR(booking.totalAmount)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Payment History */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-[#22C55E]" />
                <span>भुगतान इतिहास (Payment History)</span>
              </h3>
              {booking.remainingAmount > 0 && booking.status !== 'cancelled' && (
                <button
                  onClick={() => onAddPayment(booking)}
                  className="text-xs text-[#22C55E] hover:underline flex items-center gap-1 font-semibold"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>नया भुगतान जोड़ें</span>
                </button>
              )}
            </div>

            {booking.payments.length === 0 ? (
              <div className="p-4 rounded-xl bg-[#151515] border border-white/10 text-center text-xs text-[#737373]">
                कोई भुगतान दर्ज नहीं है।
              </div>
            ) : (
              <div className="rounded-xl bg-[#151515] border border-white/10 overflow-hidden">
                <table className="w-full text-xs text-left">
                  <thead className="bg-[#1C1C1C] text-[#A3A3A3] border-b border-white/10">
                    <tr>
                      <th className="p-3">तारीख</th>
                      <th className="p-3">माध्यम</th>
                      <th className="p-3">विवरण / नोट</th>
                      <th className="p-3 text-right">जमा राशि</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {booking.payments.map((p, idx) => (
                      <tr key={p.id || idx} className="hover:bg-white/[0.02]">
                        <td className="p-3 font-mono text-white">{p.date}</td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded bg-white/10 text-[#D1C5AE]">
                            {p.method}
                          </span>
                        </td>
                        <td className="p-3 text-[#A3A3A3]">
                          {p.notes || '-'}
                          {p.isAdvance && (
                            <span className="ml-1.5 text-[10px] px-1.5 py-0.2 rounded bg-[#22C55E]/15 text-[#22C55E]">
                              अग्रिम
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-[#22C55E]">
                          {formatINR(p.amount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-[#1C1C1C] border-t border-white/10 font-bold">
                    <tr>
                      <td colSpan={3} className="p-3 text-right text-[#A3A3A3]">कुल जमा:</td>
                      <td className="p-3 text-right font-mono text-[#22C55E] text-sm">
                        {formatINR(booking.totalPaid)}
                      </td>
                    </tr>
                    <tr>
                      <td colSpan={3} className="p-3 text-right text-white">बाकी देय राशि:</td>
                      <td className={`p-3 text-right font-mono text-sm ${isFullyPaid ? 'text-[#22C55E]' : 'text-[#F5C542]'}`}>
                        {formatINR(booking.remainingAmount)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </div>

          {/* Internal Purchases Section (Private to Studio - NEVER in customer receipts) */}
          <div className="p-4 rounded-xl bg-[#151515] border border-amber-500/20 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-[#F5C542]" />
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  आंतरिक खरीद एवं सप्लायर रिकॉर्ड (Private Business Records)
                </h4>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-white/10 text-[#A3A3A3]">
                ग्राहक रसीद पर यह कभी नहीं दिखेगा
              </span>
            </div>

            {relatedPurchases.length === 0 ? (
              <p className="text-xs text-[#737373]">
                इस बुकिंग से जुड़ा कोई आंतरिक खर्च दर्ज नहीं है। ('Internal Purchases' टैब से जोड़ें)
              </p>
            ) : (
              <div className="space-y-2">
                {relatedPurchases.map(p => (
                  <div key={p.id} className="p-2.5 rounded bg-[#1C1C1C] border border-white/5 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-semibold text-white">{p.name}</div>
                      <div className="text-[11px] text-[#A3A3A3]">
                        सप्लायर: {p.supplierName} ({p.mobile}) • तारीख: {p.date}
                      </div>
                    </div>
                    <div className="font-mono font-bold text-[#F5C542]">
                      {formatINR(p.amount)}
                    </div>
                  </div>
                ))}
                <div className="text-right text-xs text-[#A3A3A3] pt-1 border-t border-white/5">
                  कुल आंतरिक खर्च: <span className="font-mono text-white font-bold">{formatINR(totalInternalExpense)}</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons Footer */}
        <div className="p-4 sm:p-5 bg-[#151515] border-t border-white/10 flex flex-wrap items-center justify-between gap-3 sticky bottom-0 z-10">
          <div className="flex items-center gap-2">
            {/* Generate Receipt */}
            <button
              onClick={() => onGenerateReceipt(booking)}
              className="px-4 py-2.5 rounded-lg bg-[#F5C542] text-[#0B0B0B] font-bold text-xs sm:text-sm hover:bg-[#DDAE30] transition-colors flex items-center gap-2 shadow-[0_0_15px_rgba(245,197,66,0.2)]"
            >
              <FileText className="w-4 h-4" />
              <span>ग्राहक रसीद बनाएं (Receipt)</span>
            </button>

            {/* Add Payment if remaining */}
            {booking.remainingAmount > 0 && booking.status !== 'cancelled' && (
              <button
                onClick={() => onAddPayment(booking)}
                className="px-3.5 py-2.5 rounded-lg bg-[#22C55E]/15 hover:bg-[#22C55E]/25 text-[#22C55E] border border-[#22C55E]/30 text-xs sm:text-sm font-semibold transition-colors flex items-center gap-1.5"
              >
                <PlusCircle className="w-4 h-4" />
                <span>भुगतान जोड़ें</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Edit Booking */}
            <button
              onClick={() => onEdit(booking)}
              className="px-3.5 py-2.5 rounded-lg bg-[#1C1C1C] hover:bg-white/10 text-white border border-white/10 text-xs sm:text-sm font-medium transition-colors flex items-center gap-1.5"
            >
              <Edit3 className="w-4 h-4 text-[#F5C542]" />
              <span>संशोधित करें (Edit)</span>
            </button>

            {/* Cancel Booking (if active) */}
            {booking.status !== 'cancelled' && (
              <button
                onClick={() => onCancel(booking)}
                className="px-3.5 py-2.5 rounded-lg bg-[#EF4444]/15 hover:bg-[#EF4444]/25 text-[#EF4444] border border-[#EF4444]/30 text-xs sm:text-sm font-medium transition-colors flex items-center gap-1.5"
              >
                <XCircle className="w-4 h-4" />
                <span>रद्द करें (Cancel)</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

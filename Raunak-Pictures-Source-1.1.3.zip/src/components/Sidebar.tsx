import React from 'react';
import { 
  LayoutDashboard, 
  PlusCircle, 
  Calendar, 
  CreditCard, 
  ShoppingBag, 
  XCircle, 
  Camera, 
  ListOrdered,
  Phone,
  Instagram,
  Youtube,
  UserRound,
  Archive
} from 'lucide-react';
import { ActiveTab, RAUNAK_BUSINESS_PROFILE } from '../types';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isOpenMobile: boolean;
  setIsOpenMobile: (open: boolean) => void;
  activeCount: number;
  cancelledCount: number;
  logoUrl?: string | null;
  onLogoUpload?: (dataUrl: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isOpenMobile,
  setIsOpenMobile,
  activeCount,
  cancelledCount,
  logoUrl,
  onLogoUpload,
}) => {
  const navItems = [
    {
      id: 'dashboard' as ActiveTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'new-booking' as ActiveTab,
      label: 'New Booking',
      icon: PlusCircle,
      badge: null,
      highlight: true,
    },
    {
      id: 'all-bookings' as ActiveTab,
      label: 'All Bookings',
      icon: ListOrdered,
      badge: activeCount > 0 ? activeCount : null,
    },
    {
      id: 'calendar' as ActiveTab,
      label: 'Calendar',
      icon: Calendar,
      badge: null,
    },
    {
      id: 'payments' as ActiveTab,
      label: 'Payments',
      icon: CreditCard,
      badge: null,
    },
    {
      id: 'internal-purchases' as ActiveTab,
      label: 'Internal Purchases',
      icon: ShoppingBag,
      badge: null,
    },
    {
      id: 'cancelled-bookings' as ActiveTab,
      label: 'Cancelled Bookings',
      icon: XCircle,
      badge: cancelledCount > 0 ? cancelledCount : null,
      danger: true,
    },
    {
      id: 'creator' as ActiveTab,
      label: 'Creator & Support',
      icon: UserRound,
      badge: null,
    },
    {
      id: 'backup-restore' as ActiveTab,
      label: 'Backup & Restore',
      icon: Archive,
      badge: null,
    },
  ];

  const handleSelect = (tab: ActiveTab) => {
    setActiveTab(tab);
    setIsOpenMobile(false);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div 
          className="fixed inset-0 bg-black/80 z-40 lg:hidden backdrop-blur-sm"
          onClick={() => setIsOpenMobile(false)}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-72 bg-[#151515] border-r border-white/10 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="p-6 border-b border-white/10 bg-[#0E0E0E]">
          <div className="flex items-center gap-3">
            <div className="relative group/logo">
              <div className="w-12 h-12 rounded-full bg-[#0E0E0E] border-2 border-[#EF4444]/60 flex items-center justify-center shadow-[0_0_15px_rgba(239,68,68,0.25)] overflow-hidden">
                <img
                  src={logoUrl || '/assets/aistudio/logo.r_1362e06b.png'}
                  alt={RAUNAK_BUSINESS_PROFILE.name}
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              {onLogoUpload && (
                <label 
                  className="absolute inset-0 bg-black/60 opacity-0 group-hover/logo:opacity-100 rounded-full flex items-center justify-center cursor-pointer transition-opacity text-white text-[9px]"
                  title="Logo अपलोड करें / बदलें"
                >
                  <Camera className="w-3.5 h-3.5 text-[#F5C542]" />
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onloadend = () => {
                          if (reader.result) {
                            onLogoUpload(reader.result as string);
                          }
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
                </label>
              )}
            </div>
            <div>
              <h1 className="font-brand font-bold text-lg text-white tracking-wider flex items-center gap-1.5">
                RAUNAK <span className="text-[#F5C542]">PICTURES</span>
              </h1>
              <p className="text-[11px] text-[#A3A3A3] font-hindi tracking-wide line-clamp-1">
                {RAUNAK_BUSINESS_PROFILE.tagline}
              </p>
            </div>
          </div>
          <div className="mt-3 px-2 py-1 bg-[#1C1C1C] rounded border border-white/5 flex items-center justify-between text-[11px]">
            <span className="text-[#A3A3A3]">Studio:</span>
            <span className="text-[#F5C542] font-medium font-hindi">सुल्तानपुर, उ.प्र.</span>
          </div>
        </div>

        {/* Navigation Items */}
        <div className="flex-1 py-4 px-3 space-y-1.5 overflow-y-auto">
          <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-[#737373]">
            Studio Operations
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleSelect(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-lg text-sm font-medium transition-all group relative ${
                  isActive
                    ? 'bg-[#1C1C1C] text-[#F5C542] border border-[#F5C542]/30 shadow-[0_0_20px_rgba(245,197,66,0.06)]'
                    : 'text-[#A3A3A3] hover:text-white hover:bg-white/5 border border-transparent'
                }`}
              >
                {/* Active Indicator Bar */}
                {isActive && (
                  <span className="absolute left-0 top-2 bottom-2 w-1 bg-[#F5C542] rounded-r" />
                )}
                <div className="flex items-center gap-3">
                  <Icon 
                    className={`w-4 h-4 transition-transform group-hover:scale-110 ${
                      isActive 
                        ? 'text-[#F5C542]' 
                        : item.danger 
                        ? 'text-[#EF4444]' 
                        : item.highlight 
                        ? 'text-[#F5C542]/80' 
                        : 'text-[#A3A3A3]'
                    }`} 
                  />
                  <span className={`${item.highlight && !isActive ? 'text-white' : ''}`}>
                    {item.label}
                  </span>
                </div>
                {item.badge !== null && (
                  <span
                    className={`px-2 py-0.5 text-[11px] font-semibold rounded-full ${
                      item.danger
                        ? 'bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/30'
                        : isActive
                        ? 'bg-[#F5C542] text-[#0B0B0B]'
                        : 'bg-white/10 text-white'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>


        {/* Footer Contact Info */}
        <div className="p-4 border-t border-white/10 bg-[#0E0E0E] text-xs space-y-2">
          <div className="flex items-center justify-between text-[#A3A3A3]">
            <span>Owner:</span>
            <span className="text-white font-medium">{RAUNAK_BUSINESS_PROFILE.owner}</span>
          </div>
          <a 
            href={`tel:${RAUNAK_BUSINESS_PROFILE.mobile}`}
            className="flex items-center gap-2 text-[#F5C542] hover:underline"
          >
            <Phone className="w-3.5 h-3.5" />
            <span className="font-mono tracking-wider">{RAUNAK_BUSINESS_PROFILE.mobile}</span>
          </a>
          <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-[#737373]">
            <a 
              href={`https://instagram.com/${RAUNAK_BUSINESS_PROFILE.instagram.replace('@', '')}`}
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-1 hover:text-[#F5C542] transition-colors"
            >
              <Instagram className="w-3 h-3" />
              <span>{RAUNAK_BUSINESS_PROFILE.instagram}</span>
            </a>
            <a 
              href={RAUNAK_BUSINESS_PROFILE.youtube}
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-1 hover:text-[#EF4444] transition-colors"
              title="YouTube Channel"
            >
              <Youtube className="w-3.5 h-3.5 text-[#EF4444]" />
              <span>YouTube</span>
            </a>
          </div>
        </div>
      </aside>
    </>
  );
};

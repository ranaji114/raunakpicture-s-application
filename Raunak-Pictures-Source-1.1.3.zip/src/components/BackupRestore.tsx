import React, { useRef, useState } from 'react';
import { Download, FileUp, HardDrive, ShieldCheck, Cloud, RefreshCw, AlertCircle } from 'lucide-react';
import { Capacitor } from '@capacitor/core';
import { Directory, Encoding, Filesystem } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { createAppBackup, restoreAppBackup } from '../services/storage';
import { isNativeRoomApp, NativeSyncStatus, OfflineData } from '../services/offlineData';

interface BackupRestoreProps {
  onRestored: () => void | Promise<void>;
}

function fileDate() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

export const BackupRestore: React.FC<BackupRestoreProps> = ({ onRestored }) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const lastSuccessfulSync = useRef<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [syncStatus, setSyncStatus] = useState<NativeSyncStatus | null>(null);
  const [syncBusy, setSyncBusy] = useState(false);

  React.useEffect(() => {
    if (!isNativeRoomApp()) return;
    let alive = true;
    const refresh = async () => {
      try {
        const status = await OfflineData.getSyncStatus();
        if (!alive) return;
        const previous = lastSuccessfulSync.current;
        if (status.lastSyncTime) {
          lastSuccessfulSync.current = status.lastSyncTime;
          if (previous && previous !== status.lastSyncTime) await onRestored();
        }
        setSyncStatus(status);
      } catch (e) { console.warn('Sync status unavailable', e); }
    };
    void refresh();
    const timer = window.setInterval(() => void refresh(), 5000);
    return () => { alive = false; window.clearInterval(timer); };
  }, []);

  const handleConnectDrive = async () => {
    setSyncBusy(true); setError('');
    try { await OfflineData.connectGoogle(); await OfflineData.syncNow(); setSyncStatus(await OfflineData.getSyncStatus()); }
    catch (e) { setError(e instanceof Error ? e.message : 'Google account connect नहीं हुआ।'); }
    finally { setSyncBusy(false); }
  };

  const handleSyncNow = async () => {
    setSyncBusy(true); setError('');
    try { await OfflineData.syncNow(); setSyncStatus(await OfflineData.getSyncStatus()); }
    catch (e) { setError(e instanceof Error ? e.message : 'Sync schedule नहीं हो सका।'); }
    finally { setSyncBusy(false); }
  };

  const handleDriveRestore = async () => {
    if (!isNativeRoomApp()) return;
    if (!window.confirm('Google Drive backup current phone data ke saath merge hoga. Phone ka purana data delete nahi hoga. Kya continue karna hai?')) return;
    setSyncBusy(true); setBusy(true); setError(''); setMessage('');
    try {
      const result = await OfflineData.restoreFromDrive();
      await onRestored();
      setSyncStatus(await OfflineData.getSyncStatus());
      setMessage(`Google Drive se restore ho gaya: Drive mein ${result.driveBookings} bookings mili. App mein ${result.bookingsInApp} bookings hain (${result.bookingsInApp - result.cancelledBookingsInApp} active, ${result.cancelledBookingsInApp} cancelled) aur ${result.purchasesInApp} purchases. ${result.cancelledBookingsInApp > 0 ? 'Cancelled bookings “Cancelled Bookings” section mein dekhein.' : ''} Purana phone data delete nahi hua.`);
    } catch (e) {
      console.error('Google Drive restore failed', e);
      setError(e instanceof Error ? e.message : 'Google Drive backup restore नहीं हो पाया।');
    } finally {
      setSyncBusy(false); setBusy(false);
    }
  };

  const handleExport = async () => {
    setBusy(true); setMessage(''); setError('');
    try {
      const backup = await createAppBackup();
      const data = JSON.stringify(backup, null, 2);
      const name = `Raunak_Pictures_Backup_${fileDate()}.json`;
      if (Capacitor.isNativePlatform()) {
        try {
          await Filesystem.writeFile({
            path: `Raunak Pictures Backups/${name}`,
            data,
            directory: Directory.Documents,
            encoding: Encoding.UTF8,
            recursive: true,
          });
          setMessage(`पूरा बैकअप Documents/Raunak Pictures Backups/${name} में सेव हो गया।`);
        } catch (saveError) {
          // Android versions with restricted Documents access can still export
          // through the native share/save sheet using an app-cache file URI.
          await Filesystem.writeFile({
            path: name,
            data,
            directory: Directory.Cache,
            encoding: Encoding.UTF8,
            recursive: true,
          });
          const { uri } = await Filesystem.getUri({ directory: Directory.Cache, path: name });
          await Share.share({
            title: 'Raunak Pictures Backup',
            text: 'Backup JSON file ko Downloads, Drive ya Files mein save karein',
            url: uri,
            dialogTitle: 'Backup file save/share karein',
          });
          console.warn('Documents backup save failed; opened share fallback.', saveError);
          setMessage('Backup file share/save sheet mein khol di गई है। वहाँ Downloads या Google Drive चुनकर Save करें।');
        }
      } else {
        const blob = new Blob([data], { type: 'application/json;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.href = url; anchor.download = name; anchor.click();
        window.setTimeout(() => URL.revokeObjectURL(url), 1000);
        setMessage('पूरा बैकअप फ़ाइल आपके डाउनलोड में सेव हो गया।');
      }
    } catch (e) {
      console.error('Backup export failed', e);
      setError('बैकअप सेव नहीं हो पाया। जगह खाली है या स्टोरेज अनुमति उपलब्ध नहीं है; फिर कोशिश करें।');
    } finally { setBusy(false); }
  };

  const handleImport = async (file?: File) => {
    if (!file) return;
    setBusy(true); setMessage(''); setError('');
    try {
      const parsed: unknown = JSON.parse(await file.text());
      if (!window.confirm('यह बैकअप इस डिवाइस के मौजूदा बुकिंग और खरीद रिकॉर्ड को बदल देगा। आगे बढ़ें?')) return;
      await restoreAppBackup(parsed);
      await onRestored();
      setMessage('बैकअप सफलतापूर्वक बहाल हो गया। सभी बुकिंग और खरीद रिकॉर्ड लोड कर दिए गए हैं।');
    } catch (e) {
      console.error('Backup restore failed', e);
      setError(e instanceof Error ? e.message : 'बैकअप फ़ाइल पढ़ी नहीं जा सकी।');
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = '';
    }
  };

  return (
    <section className="max-w-3xl space-y-6">
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-[#F5C542]">Data safety</p>
        <h1 className="mt-2 text-2xl sm:text-3xl font-bold text-white">Backup & Restore</h1>
        <p className="mt-2 text-sm text-[#A3A3A3]">सभी bookings, payments, cancelled records, purchases और custom logo को एक फ़ाइल में सुरक्षित रखें।</p>
      </div>
      <div className="rounded-2xl border border-white/10 bg-[#151515] p-5 sm:p-7 space-y-5">
        <div className="flex items-start gap-3 rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-4 text-sm text-[#D1D5DB]">
          <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-emerald-400" />
          <p>सुरक्षित आदत: नियमित रूप से बैकअप फ़ाइल बनाकर फोन से अलग सुरक्षित जगह रखें। फ़ोन reset या खो जाने पर यही फ़ाइल नए इंस्टॉल में Restore की जा सकती है।</p>
        </div>
        {isNativeRoomApp() && (
          <div className="rounded-xl border border-white/10 bg-[#1B1B1B] p-4 space-y-3">
            <div className="flex items-start gap-3">
              <Cloud className="mt-0.5 h-5 w-5 shrink-0 text-[#F5C542]" />
              <div className="min-w-0 flex-1">
                <p className="font-semibold text-white">Google Drive visible backup sync</p>
                <p className="mt-1 text-xs text-[#A3A3A3]">Bookings, purchases aur settings “Raunak Pictures Backups” folder mein ek compressed backup file mein sync hote hain. Sirf phone se hatayi booking agle sync/restore par wapas aa sakti hai.</p>
                {syncStatus && <p className="mt-2 text-xs text-[#D1D5DB]">{syncStatus.connected ? `Connected${syncStatus.email ? `: ${syncStatus.email}` : ''}` : 'Google account not connected'} · Pending {syncStatus.pendingCount} · Failed {syncStatus.failedCount}{syncStatus.driveFileCount !== undefined && syncStatus.driveFileCount >= 0 ? ` · Drive backup ${syncStatus.driveFileCount > 0 ? 'ready' : 'not found'}` : ''}{syncStatus.lastSyncTime ? ` · Last success ${new Date(syncStatus.lastSyncTime).toLocaleString()}` : ''}</p>}
                {syncStatus?.lastError && <p className="mt-2 flex items-start gap-1 text-xs text-red-300"><AlertCircle className="h-3.5 w-3.5 shrink-0" />{syncStatus.lastError}</p>}
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <button disabled={syncBusy} onClick={handleConnectDrive} className="inline-flex items-center gap-2 rounded-lg bg-[#F5C542] px-3 py-2 text-xs font-semibold text-[#0B0B0B] disabled:opacity-60"><Cloud className="h-4 w-4" />{syncBusy ? 'Connecting…' : syncStatus?.connected ? 'Reconnect Google' : 'Connect Google Drive'}</button>
              <button disabled={syncBusy || !syncStatus?.connected} onClick={handleSyncNow} className="inline-flex items-center gap-2 rounded-lg border border-white/15 px-3 py-2 text-xs font-semibold text-white disabled:opacity-50"><RefreshCw className="h-4 w-4" />Sync now</button>
            </div>
            <p className="text-[11px] leading-relaxed text-[#8B8B8B]">Google Drive mein “My Drive/Raunak Pictures Backups” folder ke andar ek hi backup file rahegi. “Sirf phone se hatayein” karne par Drive backup bachi rahegi; “App + Drive se delete” karne par booking dono taraf se hat jayegi.</p>
          </div>
        )}
        <div className="grid gap-3 sm:grid-cols-2">
          <button disabled={busy} onClick={handleExport} className="flex items-center justify-center gap-2 rounded-xl bg-[#F5C542] px-4 py-3 font-semibold text-[#0B0B0B] disabled:opacity-60">
            <Download className="h-4 w-4" /> {busy ? 'कृपया प्रतीक्षा करें…' : 'सभी डेटा का बैकअप सेव करें'}
          </button>
          <button disabled={busy} onClick={() => inputRef.current?.click()} className="flex items-center justify-center gap-2 rounded-xl border border-white/15 bg-[#1C1C1C] px-4 py-3 font-semibold text-white disabled:opacity-60">
            <FileUp className="h-4 w-4" /> बैकअप से Restore करें
          </button>
          {isNativeRoomApp() && (
            <button disabled={busy || syncBusy || !syncStatus?.connected} onClick={() => void handleDriveRestore()} className="flex items-center justify-center gap-2 rounded-xl border border-[#F5C542]/40 bg-[#F5C542]/10 px-4 py-3 font-semibold text-[#F5C542] disabled:opacity-50">
              <Cloud className="h-4 w-4" /> Google Drive से Restore करें
            </button>
          )}
          <input ref={inputRef} type="file" accept=".json,application/json" className="hidden" onChange={e => void handleImport(e.target.files?.[0])} />
        </div>
        {message && <p role="status" className="rounded-lg border border-emerald-500/20 bg-emerald-500/10 p-3 text-sm text-emerald-300">{message}</p>}
        {error && <p role="alert" className="rounded-lg border border-red-500/20 bg-red-500/10 p-3 text-sm text-red-300">{error}</p>}
        <div className="border-t border-white/10 pt-4 text-xs leading-relaxed text-[#8B8B8B]">
          <p className="flex items-center gap-2 font-semibold text-[#C8C8C8]"><HardDrive className="h-4 w-4" /> फिलहाल यह मैन्युअल फ़ाइल बैकअप है</p>
          <p className="mt-2">Automatic Google Drive sync Google account permission ke baad chalega. Factory reset se pehle current device ka manual JSON backup bhi alag save karein.</p>
        </div>
      </div>
    </section>
  );
};

import React, { useEffect, useState } from 'react';
import { Camera, Sparkles } from 'lucide-react';
import { RAUNAK_BUSINESS_PROFILE } from '../types';

interface SplashScreenProps {
  logoUrl?: string | null;
  onFinish?: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  logoUrl,
  onFinish,
}) => {
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    // Show splash screen for 1.8 seconds then smoothly fade out
    const timer = setTimeout(() => {
      setFadeOut(true);
    }, 1800);

    const finishTimer = setTimeout(() => {
      if (onFinish) onFinish();
    }, 2200);

    return () => {
      clearTimeout(timer);
      clearTimeout(finishTimer);
    };
  }, [onFinish]);

  return (
    <div
      className={`fixed inset-0 z-[100] bg-[#0B0B0B] flex flex-col items-center justify-center p-6 transition-opacity duration-500 ease-out ${
        fadeOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Background ambient gold radiance */}
      <div className="absolute w-72 h-72 sm:w-96 sm:h-96 rounded-full bg-[#F5C542]/10 blur-3xl pointer-events-none animate-pulse" />

      <div className="relative z-10 flex flex-col items-center text-center space-y-5">
        {/* Logo or Icon with Circular Luxury Glow */}
        <div className="relative">
          <div className="w-36 h-36 sm:w-44 sm:h-44 rounded-full bg-[#151515] border-2 border-[#F5C542]/50 p-1 flex items-center justify-center shadow-[0_0_50px_rgba(245,197,66,0.25),0_0_25px_rgba(239,68,68,0.2)] overflow-hidden transition-transform duration-700 scale-100 hover:scale-105">
            <img
              src={logoUrl || '/assets/aistudio/logo.r_1362e06b.png'}
              alt={RAUNAK_BUSINESS_PROFILE.name}
              className="w-full h-full object-cover rounded-full"
            />
          </div>
          <div className="absolute bottom-1 right-2 w-7 h-7 rounded-full bg-[#F5C542] border-2 border-[#0B0B0B] flex items-center justify-center text-[#0B0B0B] shadow-lg">
            <Sparkles className="w-4 h-4" />
          </div>
        </div>

        {/* Brand Name */}
        <div className="space-y-1">
          <h1 className="font-brand font-black text-3xl sm:text-4xl tracking-wider text-white">
            RAUNAK <span className="text-[#F5C542]">PICTURES</span>
          </h1>
          <p className="font-hindi text-sm sm:text-base text-[#D1C5AE] font-medium tracking-wide">
            {RAUNAK_BUSINESS_PROFILE.tagline}
          </p>
        </div>

        {/* Location & Loading Bar */}
        <div className="pt-4 flex flex-col items-center space-y-3">
          <span className="text-xs text-[#737373] font-hindi">
            मुड़िला बाजार, कादीपुर रोड, सुल्तानपुर
          </span>
          <div className="w-36 h-1 bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-[#F5C542] to-[#DDAE30] rounded-full animate-[progress_1.6s_ease-in-out_infinite]" />
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { XCircle, X, AlertTriangle, ShieldAlert } from 'lucide-react';
import { Booking } from '../types';
import { formatINR } from '../services/storage';

interface CancelBookingModalProps {
  booking: Booking;
  onClose: () => void;
  onConfirmCancel: (bookingId: string, reason: string) => void;
}

export const CancelBookingModal: React.FC<CancelBookingModalProps> = ({
  booking,
  onClose,
  onConfirmCancel,
}) => {
  const [reason, setReason] = useState('पारिवारिक कारणों से तारीख आगे बढ़ाई गई');
  const [customReason, setCustomReason] = useState('');

  const commonReasons = [
    'पारिवारिक कारणों से तारीख आगे बढ़ाई गई',
    'ग्राहक द्वारा शादी का कार्यक्रम स्थगित',
    'तारीख में टकराव (Date Conflict)',
    'ग्राहक द्वारा बजट समस्या',
    'अन्य कारण',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalReason = reason === 'अन्य कारण' ? (customReason.trim() || 'अन्य कारण') : reason;
    onConfirmCancel(booking.id, finalReason);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm font-hindi">
      <div className="relative w-full max-w-lg bg-[#1C1C1C] border border-[#EF4444]/30 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 bg-[#151515] border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5 text-[#EF4444]">
            <XCircle className="w-5 h-5 shrink-0" />
            <h3 className="text-lg font-bold text-white">
              बुकिंग रद्द करें (Cancel Booking)
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-[#1C1C1C] text-[#A3A3A3] hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          <div className="p-3.5 rounded-lg bg-[#EF4444]/10 border border-[#EF4444]/20 space-y-1.5 text-xs">
            <div className="flex items-center gap-2 font-bold text-[#EF4444]">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>बुकिंग विवरण एवं भुगतान इतिहास सुरक्षित रहेगा</span>
            </div>
            <p className="text-[#D1C5AE]">
              ग्राहक: <strong className="text-white">{booking.customerName}</strong> ({booking.mobile})
            </p>
            <p className="text-[#D1C5AE]">
              बुकिंग राशि: {formatINR(booking.totalAmount)} | प्राप्त अग्रिम: {formatINR(booking.totalPaid)}
            </p>
            <p className="text-[#A3A3A3]">
              यह बुकिंग सक्रिय सूची से 'Cancelled Bookings' अनुभाग में स्थानांतरित हो जाएगी और डैशबोर्ड योग से हटा दी जाएगी।
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#A3A3A3] mb-2">
              रद्द करने का मुख्य कारण चुनें *
            </label>
            <div className="space-y-2">
              {commonReasons.map(r => (
                <label 
                  key={r}
                  className={`flex items-center gap-3 p-2.5 rounded-lg border text-xs cursor-pointer transition-all ${
                    reason === r 
                      ? 'bg-[#EF4444]/15 border-[#EF4444]/40 text-white font-medium' 
                      : 'bg-[#151515] border-white/5 text-[#A3A3A3] hover:border-white/20'
                  }`}
                >
                  <input
                    type="radio"
                    name="cancelReason"
                    value={r}
                    checked={reason === r}
                    onChange={() => setReason(r)}
                    className="accent-[#EF4444]"
                  />
                  <span>{r}</span>
                </label>
              ))}
            </div>
          </div>

          {reason === 'अन्य कारण' && (
            <div>
              <label className="block text-xs font-semibold text-[#A3A3A3] mb-1">
                विस्तृत कारण दर्ज करें
              </label>
              <input
                type="text"
                value={customReason}
                onChange={e => setCustomReason(e.target.value)}
                placeholder="उदा. ग्राहक की विशेष मांग या अन्य स्पष्टीकरण"
                required
                className="w-full h-10 px-3 rounded bg-[#151515] border border-white/15 text-white placeholder-[#525252] focus:border-[#EF4444] focus:outline-none text-xs"
              />
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-lg bg-transparent border border-white/20 text-white hover:bg-white/5 text-xs font-medium"
            >
              वापस जाएं (रद्द न करें)
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-lg bg-[#EF4444] hover:bg-red-600 text-white text-xs font-bold transition-all shadow-[0_0_15px_rgba(239,68,68,0.25)] flex items-center gap-1.5"
            >
              <XCircle className="w-4 h-4" />
              <span>हाँ, बुकिंग रद्द करें</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

import React, { useDeferredValue, useMemo, useState } from 'react';
import { 
  CreditCard, 
  Search, 
  PlusCircle, 
  CheckCircle2, 
  Clock, 
  Calendar, 
  Phone, 
  ArrowUpRight,
  Eye,
  FileText
} from 'lucide-react';
import { Booking, PaymentMethod, PaymentItem } from '../types';
import { formatINR } from '../services/storage';

const PAYMENTS_PAGE_SIZE = 50;

interface PaymentsViewProps {
  bookings: Booking[];
  onAddPayment: (booking: Booking) => void;
  onViewBooking: (booking: Booking) => void;
  onGenerateReceipt: (booking: Booking) => void;
}

export const PaymentsView: React.FC<PaymentsViewProps> = ({
  bookings,
  onAddPayment,
  onViewBooking,
  onGenerateReceipt,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [methodFilter, setMethodFilter] = useState<string>('all');
  const [ledgerPage, setLedgerPage] = useState(1);
  const [pendingPage, setPendingPage] = useState(1);
  const deferredSearchTerm = useDeferredValue(searchTerm);

  const activeBookings = useMemo(() => bookings.filter(b => b.status !== 'cancelled'), [bookings]);

  // Overall financial sums across active contracts
  const { totalBilled, totalCollected, totalPending } = useMemo(() => activeBookings.reduce((totals, b) => ({
    totalBilled: totals.totalBilled + (b.totalAmount || 0),
    totalCollected: totals.totalCollected + (b.totalPaid || 0),
    totalPending: totals.totalPending + (b.remainingAmount || 0),
  }), { totalBilled: 0, totalCollected: 0, totalPending: 0 }), [activeBookings]);

  // Flatten all payments across all bookings into an audit ledger
  interface FlatPayment extends PaymentItem {
    bookingId: string;
    customerName: string;
    mobile: string;
    eventDate: string;
    booking: Booking;
  }

  const allTransactions = useMemo(() => {
    const transactions: FlatPayment[] = [];
    activeBookings.forEach(booking => {
      booking.payments.forEach(p => {
        transactions.push({
          ...p,
          bookingId: booking.id,
          customerName: booking.customerName,
          mobile: booking.mobile,
          eventDate: booking.events[0]?.date || '',
          booking,
        });
      });
    });
    return transactions.sort((a, b) => b.date.localeCompare(a.date));
  }, [activeBookings]);

  // Filtered transactions
  const filteredTransactions = useMemo(() => allTransactions.filter(t => {
    const query = deferredSearchTerm.trim().toLowerCase();
    const matchesSearch = !query ||
      t.customerName.toLowerCase().includes(query) ||
      t.mobile.includes(deferredSearchTerm.trim()) ||
      (t.notes && t.notes.toLowerCase().includes(query));

    const matchesMethod = methodFilter === 'all' || t.method === methodFilter;

    return matchesSearch && matchesMethod;
  }), [allTransactions, deferredSearchTerm, methodFilter]);
  const filteredTotal = useMemo(
    () => filteredTransactions.reduce((sum, t) => sum + (t.amount || 0), 0),
    [filteredTransactions],
  );
  const ledgerPageCount = Math.max(1, Math.ceil(filteredTransactions.length / PAYMENTS_PAGE_SIZE));
  const currentLedgerPage = Math.min(ledgerPage, ledgerPageCount);
  const visibleTransactions = filteredTransactions.slice(
    (currentLedgerPage - 1) * PAYMENTS_PAGE_SIZE,
    currentLedgerPage * PAYMENTS_PAGE_SIZE,
  );

  // Pending balance clients list
  const pendingBookings = useMemo(() => activeBookings.filter(b => b.remainingAmount > 0), [activeBookings]);
  const pendingPageCount = Math.max(1, Math.ceil(pendingBookings.length / PAYMENTS_PAGE_SIZE));
  const currentPendingPage = Math.min(pendingPage, pendingPageCount);
  const visiblePendingBookings = pendingBookings.slice(
    (currentPendingPage - 1) * PAYMENTS_PAGE_SIZE,
    currentPendingPage * PAYMENTS_PAGE_SIZE,
  );

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Top 3 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-xl bg-[#1C1C1C] border border-white/10">
          <div className="flex items-center justify-between text-[#A3A3A3] text-xs font-semibold uppercase">
            <span>Total Booking Value</span>
            <CreditCard className="w-4 h-4 text-[#F5C542]" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-white mt-2">
            {formatINR(totalBilled)}
          </div>
          <div className="text-xs text-[#737373] mt-1 font-hindi">
            सक्रिय अनुबंधों का कुल मूल्य
          </div>
        </div>

        <div className="p-5 rounded-xl bg-[#1C1C1C] border border-white/10">
          <div className="flex items-center justify-between text-[#A3A3A3] text-xs font-semibold uppercase">
            <span>Total Collected</span>
            <CheckCircle2 className="w-4 h-4 text-[#22C55E]" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-[#22C55E] mt-2">
            {formatINR(totalCollected)}
          </div>
          <div className="text-xs text-[#737373] mt-1 font-hindi">
            कुल प्राप्त अग्रिम व किश्तें
          </div>
        </div>

        <div className="p-5 rounded-xl bg-[#1C1C1C] border border-white/10">
          <div className="flex items-center justify-between text-[#A3A3A3] text-xs font-semibold uppercase">
            <span>Pending Balance</span>
            <Clock className="w-4 h-4 text-[#F5C542]" />
          </div>
          <div className={`text-2xl sm:text-3xl font-bold font-mono mt-2 ${totalPending > 0 ? 'text-[#F5C542]' : 'text-[#22C55E]'}`}>
            {formatINR(totalPending)}
          </div>
          <div className="text-xs text-[#737373] mt-1 font-hindi">
            ग्राहकों से बाकी देय राशि
          </div>
        </div>
      </div>

      {/* Clients with Pending Balance section */}
      {pendingBookings.length > 0 && (
        <div className="rounded-xl bg-[#1C1C1C] border border-white/10 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white font-hindi">
                बाकी भुगतान वाले ग्राहक ({pendingBookings.length})
              </h3>
              <p className="text-xs text-[#A3A3A3]">
                शीघ्र भुगतान प्रविष्टि के लिए 'भुगतान जोड़ें' पर क्लिक करें
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {visiblePendingBookings.map(b => (
              <div 
                key={b.id}
                className="p-3.5 rounded-lg bg-[#151515] border border-white/10 hover:border-[#F5C542]/40 transition-all flex flex-col justify-between space-y-3 font-hindi"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-sm">{b.customerName}</span>
                    <span className="font-mono text-xs font-bold text-[#F5C542]">
                      बाकी: {formatINR(b.remainingAmount)}
                    </span>
                  </div>
                  <div className="text-xs text-[#A3A3A3] font-mono mt-0.5">{b.mobile}</div>
                  <div className="text-[11px] text-[#737373] mt-1">
                    इवेंट: {b.events[0]?.name || 'कार्यक्रम'} ({b.events[0]?.date || ''})
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/5">
                  <span className="text-[11px] text-[#A3A3A3]">
                    जमा: {formatINR(b.totalPaid)} / कुल: {formatINR(b.totalAmount)}
                  </span>
                  <button
                    onClick={() => onAddPayment(b)}
                    className="px-2.5 py-1 rounded bg-[#22C55E]/15 hover:bg-[#22C55E]/25 text-[#22C55E] border border-[#22C55E]/30 text-xs font-semibold flex items-center gap-1 transition-colors"
                  >
                    <PlusCircle className="w-3 h-3" />
                    <span>भुगतान जोड़ें</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
          {pendingPageCount > 1 && (
            <div className="flex items-center justify-between text-xs text-[#A3A3A3]">
              <span>Page {currentPendingPage} of {pendingPageCount}</span>
              <div className="flex gap-2">
                <button disabled={currentPendingPage <= 1} onClick={() => setPendingPage(currentPendingPage - 1)} className="rounded-lg border border-white/10 px-3 py-2 text-white disabled:opacity-40">Previous</button>
                <button disabled={currentPendingPage >= pendingPageCount} onClick={() => setPendingPage(currentPendingPage + 1)} className="rounded-lg border border-white/10 px-3 py-2 text-white disabled:opacity-40">Next</button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Payment Transactions Ledger */}
      <div className="rounded-xl bg-[#1C1C1C] border border-white/10 overflow-hidden font-hindi">
        <div className="p-4 sm:p-5 border-b border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white">
              सभी भुगतान लेनदेन (Transaction History)
            </h3>
            <p className="text-xs text-[#A3A3A3]">
              स्टूडियो में दर्ज सभी भुगतानों का पारदर्शी लेजर
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-[#737373] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={e => { setSearchTerm(e.target.value); setLedgerPage(1); }}
                placeholder="सर्च ग्राहक या नोट..."
                className="h-9 pl-8 pr-3 rounded bg-[#151515] border border-white/10 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none text-xs"
              />
            </div>

            {/* Method Filter */}
            <select
              value={methodFilter}
              onChange={e => { setMethodFilter(e.target.value); setLedgerPage(1); }}
              className="h-9 px-3 rounded bg-[#151515] border border-white/10 text-white text-xs focus:border-[#F5C542] focus:outline-none"
            >
              <option value="all">सभी माध्यम (All Methods)</option>
              <option value="नकद">नकद (Cash)</option>
              <option value="UPI">UPI</option>
              <option value="बैंक">बैंक</option>
              <option value="अन्य">अन्य</option>
            </select>
          </div>
        </div>

        {filteredTransactions.length === 0 ? (
          <div className="p-8 text-center text-xs text-[#737373]">
            कोई भुगतान लेनदेन नहीं मिला।
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-[#151515] text-[#A3A3A3] border-b border-white/10">
                <tr>
                  <th className="p-3">तारीख</th>
                  <th className="p-3">ग्राहक का नाम</th>
                  <th className="p-3">मोबाइल</th>
                  <th className="p-3">माध्यम</th>
                  <th className="p-3">विवरण / संदर्भ</th>
                  <th className="p-3 text-right">जमा राशि</th>
                  <th className="p-3 text-center">कार्रवाई</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {visibleTransactions.map((t, idx) => (
                  <tr key={t.id || idx} className="hover:bg-white/[0.02]">
                    <td className="p-3 font-mono text-white whitespace-nowrap">{t.date}</td>
                    <td className="p-3 font-medium text-white">{t.customerName}</td>
                    <td className="p-3 text-[#A3A3A3] font-mono">{t.mobile}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded bg-white/10 text-[#D1C5AE]">
                        {t.method}
                      </span>
                    </td>
                    <td className="p-3 text-[#A3A3A3]">
                      {t.notes || '-'}
                      {t.isAdvance && (
                        <span className="ml-1.5 text-[10px] px-1.5 py-0.2 rounded bg-[#22C55E]/15 text-[#22C55E]">
                          अग्रिम
                        </span>
                      )}
                    </td>
                    <td className="p-3 text-right font-mono font-bold text-[#22C55E] whitespace-nowrap">
                      {formatINR(t.amount)}
                    </td>
                    <td className="p-3 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => onViewBooking(t.booking)}
                          className="p-1 rounded text-[#A3A3A3] hover:text-white"
                          title="बुकिंग देखें"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onGenerateReceipt(t.booking)}
                          className="p-1 rounded text-[#F5C542] hover:text-[#DDAE30]"
                          title="रसीद बनाएं"
                        >
                          <FileText className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-[#151515] border-t border-white/10 font-bold">
                <tr>
                  <td colSpan={5} className="p-3 text-right text-white">कुल जमा लेनदेन:</td>
                  <td className="p-3 text-right font-mono text-base text-[#22C55E]">
                    {formatINR(filteredTotal)}
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
        {ledgerPageCount > 1 && (
          <div className="flex items-center justify-between border-t border-white/10 px-4 py-3 text-xs text-[#A3A3A3]">
            <span>Showing {(currentLedgerPage - 1) * PAYMENTS_PAGE_SIZE + 1}–{Math.min(currentLedgerPage * PAYMENTS_PAGE_SIZE, filteredTransactions.length)} of {filteredTransactions.length} payments · Page {currentLedgerPage} of {ledgerPageCount}</span>
            <div className="flex gap-2">
              <button disabled={currentLedgerPage <= 1} onClick={() => setLedgerPage(currentLedgerPage - 1)} className="rounded-lg border border-white/10 px-3 py-2 text-white disabled:opacity-40">Previous</button>
              <button disabled={currentLedgerPage >= ledgerPageCount} onClick={() => setLedgerPage(currentLedgerPage + 1)} className="rounded-lg border border-white/10 px-3 py-2 text-white disabled:opacity-40">Next</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

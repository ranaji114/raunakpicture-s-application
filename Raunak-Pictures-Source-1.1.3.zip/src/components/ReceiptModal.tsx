import React, { useRef, useState } from 'react';
import { 
  X, 
  Download, 
  Printer, 
  Phone, 
  Instagram, 
  Youtube, 
  MapPin, 
  CheckCircle,
  Loader2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  MessageCircle,
  Camera
} from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Capacitor } from '@capacitor/core';
import { Directory, Filesystem } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { Booking, RAUNAK_BUSINESS_PROFILE } from '../types';
import { formatINR } from '../services/storage';

interface ReceiptModalProps {
  booking: Booking;
  onClose: () => void;
  logoUrl?: string | null;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  booking,
  onClose,
  logoUrl,
}) => {
  const receiptRef = useRef<HTMLDivElement>(null);
  const pinchStartRef = useRef<{ distance: number; zoom: number } | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [zoomLevel, setZoomLevel] = useState<number>(() => {
    if (typeof window !== 'undefined' && window.innerWidth < 640) {
      return 0.78; // Comfortable readable zoom on phone
    }
    return 1;
  });

  const effectiveLogo = logoUrl || '/assets/aistudio/logo.r_1362e06b.png';

  const zoomIn = () => {
    setZoomLevel(prev => Math.min(1.8, Number((prev + 0.1).toFixed(2))));
  };

  const zoomOut = () => {
    setZoomLevel(prev => Math.max(0.5, Number((prev - 0.1).toFixed(2))));
  };

  const resetZoom = () => {
    if (typeof window !== 'undefined' && window.innerWidth < 640) {
      setZoomLevel(0.78);
    } else {
      setZoomLevel(1);
    }
  };

  const getTouchDistance = (first: React.Touch, second: React.Touch) =>
    Math.hypot(second.clientX - first.clientX, second.clientY - first.clientY);

  const handlePreviewTouchStart = (event: React.TouchEvent<HTMLDivElement>) => {
    if (event.touches.length === 2) {
      pinchStartRef.current = {
        distance: getTouchDistance(event.touches[0], event.touches[1]),
        zoom: zoomLevel,
      };
    }
  };

  const handlePreviewTouchMove = (event: React.TouchEvent<HTMLDivElement>) => {
    const start = pinchStartRef.current;
    if (!start || event.touches.length !== 2) return;
    event.preventDefault();
    const distance = getTouchDistance(event.touches[0], event.touches[1]);
    setZoomLevel(Math.max(0.5, Math.min(2.5, Number((start.zoom * distance / start.distance).toFixed(2)))));
  };

  const handlePreviewTouchEnd = (event: React.TouchEvent<HTMLDivElement>) => {
    if (event.touches.length < 2) pinchStartRef.current = null;
  };

  // Unique receipt number
  const receiptNumber = `RP-${booking.id.replace('rp-book-', '').toUpperCase()}`;
  const currentDateFormatted = new Date().toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  // Working PDF Export
  const handleDownloadPDF = async () => {
    if (!receiptRef.current) return;
    try {
      setIsExporting(true);

      const element = receiptRef.current;
      if (document.fonts?.ready) await document.fonts.ready;
      // Explicitly request the receipt's actual fonts before the DOM snapshot;
      // this avoids capturing fallback metrics for mixed Latin/Devanagari text.
      await Promise.all([
        document.fonts.load('400 12px "Plus Jakarta Sans"'),
        document.fonts.load('400 12px "Noto Sans Devanagari"'),
        document.fonts.load('700 24px "Cinzel"'),
      ]);
      const receiptImages = Array.from(element.querySelectorAll('img'));
      await Promise.all(receiptImages.map(async image => {
        if (image.complete) return;
        await new Promise<void>(resolve => {
          image.addEventListener('load', () => resolve(), { once: true });
          image.addEventListener('error', () => resolve(), { once: true });
        });
      }));
      // Android WebView's SVG foreignObject snapshot can omit same-origin <img>
      // URLs. Inline a downsampled PNG copy in the export clone (not the preview)
      // so both the header logo and watermark are self-contained in the PDF.
      const embeddedReceiptImages = receiptImages.map(image => {
        if (!image.naturalWidth || !image.naturalHeight) return null;
        try {
          const maxDimension = 800;
          const imageScale = Math.min(1, maxDimension / Math.max(image.naturalWidth, image.naturalHeight));
          const imageCanvas = document.createElement('canvas');
          imageCanvas.width = Math.max(1, Math.round(image.naturalWidth * imageScale));
          imageCanvas.height = Math.max(1, Math.round(image.naturalHeight * imageScale));
          const imageContext = imageCanvas.getContext('2d');
          if (!imageContext) return null;
          imageContext.drawImage(image, 0, 0, imageCanvas.width, imageCanvas.height);
          return imageCanvas.toDataURL('image/png');
        } catch (imageError) {
          console.warn('Could not inline receipt image for PDF export', imageError);
          return null;
        }
      });
      // Capture the receipt at its real layout size, not at the preview's
      // pinch/zoom scale. Keep the current viewport width so responsive styles
      // (notably the receipt padding on phones) match what the user sees.
      const zoomWrapper = element.parentElement as HTMLElement | null;
      const previewViewport = zoomWrapper?.parentElement as HTMLElement | null;
      const originalTransform = zoomWrapper?.style.transform ?? '';
      const originalTransition = zoomWrapper?.style.transition ?? '';
      const originalMarginBottom = zoomWrapper?.style.marginBottom ?? '';
      const originalPosition = element.style.position;
      const originalTop = element.style.top;
      const originalLeft = element.style.left;
      const originalMargin = element.style.margin;
      const originalOverflow = previewViewport?.style.overflow ?? '';
      const originalScrollLeft = previewViewport?.scrollLeft ?? 0;
      const originalScrollTop = previewViewport?.scrollTop ?? 0;
      let canvas: HTMLCanvasElement;
      try {
        if (zoomWrapper) {
          zoomWrapper.style.transition = 'none';
          zoomWrapper.style.transform = 'none';
          zoomWrapper.style.marginBottom = '0';
        }
        // ForeignObject capture in Android WebView can inherit the preview's
        // scroll-container offset and clip the receipt's branding at the top.
        // Anchor only during capture so the complete sheet starts at (0, 0).
        element.style.position = 'fixed';
        element.style.top = '0';
        element.style.left = '0';
        element.style.margin = '0';
        if (previewViewport) {
          previewViewport.style.overflow = 'visible';
          previewViewport.scrollLeft = 0;
          previewViewport.scrollTop = 0;
        }
        // Allow layout to settle after temporarily removing preview zoom.
        await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
        canvas = await html2canvas(element, {
          // Render the cloned DOM through the browser's SVG foreignObject
          // engine so complex-script shaping, font kerning, and mixed Hindi /
          // Latin text are preserved instead of being reassembled glyph-wise.
          foreignObjectRendering: true,
          scale: 2,
          useCORS: true,
          allowTaint: false,
          backgroundColor: '#ffffff',
          logging: false,
          width: element.offsetWidth,
          height: element.offsetHeight,
          scrollX: 0,
          scrollY: 0,
          windowWidth: window.innerWidth,
          windowHeight: window.innerHeight,
          onclone: clonedDocument => {
            const clonedReceipt = clonedDocument.querySelector<HTMLElement>('[data-receipt-export="true"]');
            if (!clonedReceipt) return;

            clonedReceipt.querySelectorAll<HTMLImageElement>('img').forEach((image, index) => {
              const embeddedSource = embeddedReceiptImages[index];
              if (!embeddedSource) return;
              image.removeAttribute('crossorigin');
              image.removeAttribute('srcset');
              image.src = embeddedSource;
            });

            // Keep the payment history inside its grid track. Its reference
            // text can otherwise force the left track wider and collide with
            // the settlement summary in exported PDFs.
            const paymentGrid = clonedReceipt.querySelector<HTMLElement>('.grid-cols-12');
            if (paymentGrid) {
              Array.from(paymentGrid.children).forEach(child => {
                (child as HTMLElement).style.minWidth = '0';
              });
              const paymentTable = paymentGrid.querySelector<HTMLTableElement>('table');
              if (paymentTable) {
                paymentTable.style.width = '100%';
                paymentTable.style.tableLayout = 'fixed';
                paymentTable.querySelectorAll<HTMLElement>('th, td').forEach(cell => {
                  cell.style.whiteSpace = 'normal';
                  cell.style.overflowWrap = 'anywhere';
                });
              }
            }
          },
        });
      } finally {
        element.style.position = originalPosition;
        element.style.top = originalTop;
        element.style.left = originalLeft;
        element.style.margin = originalMargin;
        if (zoomWrapper) {
          zoomWrapper.style.transform = originalTransform;
          zoomWrapper.style.transition = originalTransition;
          zoomWrapper.style.marginBottom = originalMarginBottom;
        }
        if (previewViewport) {
          previewViewport.style.overflow = originalOverflow;
          previewViewport.scrollLeft = originalScrollLeft;
          previewViewport.scrollTop = originalScrollTop;
        }
      }

      if (canvas.width < 1 || canvas.height < 1) {
        throw new Error('Receipt image खाली है। कृपया दोबारा प्रयास करें।');
      }
      const canvasContext = canvas.getContext('2d');
      if (!canvasContext) throw new Error('Receipt image पढ़ी नहीं जा सकी।');
      const sample = canvasContext.getImageData(0, 0, canvas.width, canvas.height);
      let hasVisibleContent = false;
      for (let index = 0; index < sample.data.length; index += 4) {
        if (sample.data[index] < 245 || sample.data[index + 1] < 245 || sample.data[index + 2] < 245) {
          hasVisibleContent = true;
          break;
        }
      }
      if (!hasVisibleContent) throw new Error('Receipt image blank बनी है। कृपया दोबारा प्रयास करें।');

      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 8;
      const contentWidth = pdfWidth - margin * 2;
      const contentHeight = pageHeight - margin * 2;
      const sliceHeightPx = Math.max(1, Math.floor(canvas.width * contentHeight / contentWidth));

      // Split long receipts across A4 pages instead of clipping the footer.
      for (let offset = 0, page = 0; offset < canvas.height; offset += sliceHeightPx, page += 1) {
        if (page > 0) pdf.addPage();
        const currentHeightPx = Math.min(sliceHeightPx, canvas.height - offset);
        const pageCanvas = document.createElement('canvas');
        pageCanvas.width = canvas.width;
        pageCanvas.height = currentHeightPx;
        const pageContext = pageCanvas.getContext('2d');
        if (!pageContext) throw new Error('PDF canvas तैयार नहीं हो पाया।');
        pageContext.fillStyle = '#ffffff';
        pageContext.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
        pageContext.drawImage(canvas, 0, offset, canvas.width, currentHeightPx, 0, 0, canvas.width, currentHeightPx);
        const pageImage = pageCanvas.toDataURL('image/jpeg', 0.96);
        const renderedHeight = currentHeightPx * contentWidth / canvas.width;
        pdf.addImage(pageImage, 'JPEG', margin, margin, contentWidth, renderedHeight);
      }

      const fileName = `Raunak_Pictures_Receipt_${booking.id}.pdf`;
      if (Capacitor.isNativePlatform()) {
        const base64 = pdf.output('datauristring').split(',')[1];
        // Android WebView cannot reliably invoke window.print(). Write a
        // temporary PDF URI first, then let the native chooser handle Save,
        // Drive, Files, WhatsApp, or a connected printer.
        try {
          await Filesystem.writeFile({
            path: fileName,
            data: base64,
            directory: Directory.Cache,
            recursive: true,
          });
          const { uri } = await Filesystem.getUri({ directory: Directory.Cache, path: fileName });
          await Share.share({
            title: 'Raunak Pictures Receipt',
            text: 'Receipt PDF ko Downloads, Drive, Files ya printer mein bhejein',
            url: uri,
            dialogTitle: 'Receipt PDF save ya print karein',
          });
        } catch (shareError) {
          console.error('Native PDF save/share failed', shareError);
          throw new Error('Android ka Save/Print chooser nahi khul saka. Dobara try karein.');
        }
      } else {
        pdf.save(fileName);
      }
    } catch (error) {
      console.error('Error generating PDF:', error);
      const detail = error instanceof Error ? ` (${error.message})` : '';
      alert(`PDF तैयार या सेव नहीं हो पाई${detail}। कृपया दोबारा प्रयास करें या Print बटन इस्तेमाल करें।`);
    } finally {
      setIsExporting(false);
    }
  };

  // Native Android WebView has no dependable window.print(). Generate the
  // same PDF and open the system chooser, where Print is one of the targets.
  const handlePrint = () => {
    void handleDownloadPDF();
  };

  // WhatsApp Share with pre-formatted receipt details
  const handleWhatsAppShare = () => {
    const eventsStr = booking.events.map(e => `${e.name} (${e.date})`).join(', ');
    const text = `*RAUNAK PICTURES - आधिकारिक रसीद*\n\n` +
      `नमस्ते *${booking.customerName}* जी,\n` +
      `आपके कार्यक्रम की बुकिंग रसीद का विवरण:\n\n` +
      `📅 *कार्यक्रम:* ${eventsStr}\n` +
      `💰 *कुल बुकिंग राशि:* ${formatINR(booking.totalAmount)}\n` +
      `✅ *जमा अग्रिम राशि:* ${formatINR(booking.totalPaid)}\n` +
      `⏳ *बाकी देय राशि:* ${formatINR(booking.remainingAmount)}\n\n` +
      `📸 *Raunak Pictures*\n` +
      `📍 मुड़िला बाजार, कादीपुर रोड, सुल्तानपुर\n` +
      `📞 6387675525\n` +
      `📷 Insta: ${RAUNAK_BUSINESS_PROFILE.instagram}\n` +
      `🎥 YouTube: Raunak Pictures\n` +
      `आपकी कल्पना, हमारी रचना..`;

    const cleanMobile = booking.mobile.replace(/\D/g, '');
    const url = `https://api.whatsapp.com/send?phone=91${cleanMobile}&text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const isFullyPaid = booking.remainingAmount <= 0;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black/95 backdrop-blur-md overflow-hidden">
      {/* Top Floating App Bar with Controls (no-print) */}
      <header className="sticky top-0 z-30 bg-[#151515] border-b border-white/10 px-3 sm:px-6 py-2.5 flex items-center justify-between gap-2 shadow-md no-print shrink-0">
        {/* Left: Brand title & Zoom controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="w-8 h-8 rounded-full border border-[#EF4444]/60 overflow-hidden shrink-0 hidden sm:block">
            <img src={effectiveLogo} alt="Logo" className="w-full h-full object-cover rounded-full" />
          </div>
          <div>
            <h3 className="font-brand font-bold text-xs sm:text-sm text-white flex items-center gap-1.5 leading-tight">
              <span>Customer Receipt</span>
              <span className="text-[10px] text-[#A3A3A3] font-mono hidden md:inline">({receiptNumber})</span>
            </h3>
            <span className="text-[10px] text-[#F5C542] font-hindi block truncate max-w-[130px] sm:max-w-xs">
              {booking.customerName}
            </span>
          </div>

          {/* Zoom In / Zoom Out Controls */}
          <div className="flex items-center bg-[#1C1C1C] border border-white/10 rounded-lg p-0.5 ml-1 sm:ml-2">
            <button
              onClick={zoomOut}
              className="p-1 sm:p-1.5 text-[#A3A3A3] hover:text-white transition-colors"
              title="Zoom Out (छोटा करें)"
              aria-label="Zoom out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={resetZoom}
              className="px-1.5 py-0.5 text-[10px] sm:text-xs font-mono font-bold text-[#F5C542] hover:underline"
              title="Reset Zoom"
            >
              {Math.round(zoomLevel * 100)}%
            </button>
            <button
              onClick={zoomIn}
              className="p-1 sm:p-1.5 text-[#A3A3A3] hover:text-white transition-colors"
              title="Zoom In (बड़ा करें)"
              aria-label="Zoom in"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* WhatsApp Share Button */}
          <button
            onClick={handleWhatsAppShare}
            className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg bg-[#22C55E]/15 hover:bg-[#22C55E]/25 text-[#22C55E] border border-[#22C55E]/30 text-xs font-semibold flex items-center gap-1 transition-colors"
            title="WhatsApp पर विवरण भेजें"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span className="hidden md:inline">WhatsApp</span>
          </button>

          {/* Download PDF Button */}
          <button
            onClick={handleDownloadPDF}
            disabled={isExporting}
            className="px-2.5 sm:px-3.5 py-1.5 rounded-lg bg-[#F5C542] hover:bg-[#DDAE30] text-[#0B0B0B] font-bold text-xs flex items-center gap-1.5 shadow transition-all active:scale-95 disabled:opacity-50"
            title="Save or share PDF receipt"
          >
            {isExporting ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span className="text-[11px]">Saving...</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Save PDF</span>
                <span className="sm:hidden text-[11px]">PDF</span>
              </>
            )}
          </button>

          {/* Print Button */}
          <button
            onClick={handlePrint}
            className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg bg-[#1C1C1C] hover:bg-white/10 text-white text-xs border border-white/20 flex items-center gap-1 transition-colors"
            title="Open save/print chooser"
          >
            <Printer className="w-3.5 h-3.5 text-[#F5C542]" />
            <span className="hidden md:inline">Save / Print</span>
          </button>

          {/* Close Button */}
          <button
            onClick={onClose}
            className="p-1.5 sm:p-2 rounded-lg bg-[#1C1C1C] hover:bg-[#EF4444]/20 text-[#A3A3A3] hover:text-[#EF4444] border border-white/20 transition-colors ml-1"
            title="रसीद बंद करें"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Scrollable Canvas Area (Pinch/Zoomable on phone) */}
      <div
        className="flex-1 overflow-auto p-2 sm:p-6 flex items-start justify-start sm:justify-center touch-pan-x touch-pan-y"
        style={{ touchAction: 'pan-x pan-y' }}
        onTouchStart={handlePreviewTouchStart}
        onTouchMove={handlePreviewTouchMove}
        onTouchEnd={handlePreviewTouchEnd}
        onTouchCancel={handlePreviewTouchEnd}
      >
        <div 
          className="transition-transform duration-150 origin-top my-2 sm:my-4"
          style={{ 
            transform: zoomLevel !== 1 ? `scale(${zoomLevel})` : undefined,
            transformOrigin: window.innerWidth < 640 ? 'top left' : 'top center',
            marginBottom: zoomLevel > 1 ? `${(zoomLevel - 1) * 800}px` : undefined
          }}
        >
          {/* Printable Receipt Sheet (Classic Luxury Format) */}
          <div 
            ref={receiptRef}
            data-receipt-export="true"
            className="receipt-printable-area bg-white text-[#111111] p-8 sm:p-12 relative overflow-hidden font-sans border border-gray-200 shadow-2xl rounded-xl mx-auto"
            style={{ 
              width: '780px',
              maxWidth: '780px',
              minHeight: '1050px' 
            }}
          >
            {/* Subtle Luxury Golden Border */}
            <div className="absolute inset-3 border-2 border-[#D4AF37]/35 rounded-lg pointer-events-none" />
            <div className="absolute inset-4 border border-[#D4AF37]/15 rounded-md pointer-events-none" />

            {/* WATERMARK BACKGROUND: Exact Raunak Pictures Logo Image */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none overflow-hidden z-0">
              <div className="w-[360px] h-[360px] opacity-[0.08] flex items-center justify-center transform -rotate-12">
                <img
                  src={effectiveLogo}
                  alt="Watermark"
                  className="w-full h-full object-contain rounded-full"
                  crossOrigin="anonymous"
                />
              </div>
            </div>

            {/* Content Foreground */}
            <div className="relative z-10 space-y-6">
              {/* Header: Studio Branding & Circular Logo */}
              <div className="flex items-start justify-between gap-4 pb-6 border-b-2 border-gray-100">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-3">
                    {/* Official Circular Logo in Header */}
                    <div className="w-14 h-14 rounded-full border-2 border-[#EF4444] p-0.5 shadow-md overflow-hidden bg-black shrink-0">
                      <img 
                        src={effectiveLogo} 
                        alt="Raunak Pictures" 
                        className="w-full h-full object-cover rounded-full"
                        crossOrigin="anonymous"
                      />
                    </div>

                    <div>
                      <h1 className="font-brand font-extrabold text-2xl tracking-wider text-[#0B0B0B] leading-none">
                        RAUNAK <span className="text-[#C59B27]">PICTURES</span>
                      </h1>
                      <p className="font-hindi text-xs text-[#8B7355] font-semibold tracking-wide mt-1">
                        {RAUNAK_BUSINESS_PROFILE.tagline}
                      </p>
                    </div>
                  </div>

                  <div className="pt-2 text-[12px] text-gray-600 space-y-0.5 font-hindi">
                    <div className="flex items-start gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#C59B27] shrink-0 mt-0.5" />
                      <span>{RAUNAK_BUSINESS_PROFILE.address}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-[#C59B27] shrink-0" />
                      <span className="font-mono font-bold text-gray-900">{RAUNAK_BUSINESS_PROFILE.mobile}</span>
                      <span className="text-gray-400">• प्रो. {RAUNAK_BUSINESS_PROFILE.owner}</span>
                    </div>
                  </div>

                  {/* Social Channels: Instagram logo + username & YouTube logo + channel name */}
                  <div className="flex items-center gap-3.5 pt-1.5 text-[11px] text-gray-600">
                    {/* Instagram */}
                    <a
                      href={`https://instagram.com/${RAUNAK_BUSINESS_PROFILE.instagram.replace('@', '')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1.5 hover:text-pink-600 transition-colors"
                      title="Instagram Profile"
                    >
                      <Instagram className="w-3.5 h-3.5 text-pink-600 shrink-0" />
                      <span className="font-mono font-semibold text-gray-800">
                        {RAUNAK_BUSINESS_PROFILE.instagram}
                      </span>
                    </a>

                    <span className="text-gray-300">•</span>

                    {/* YouTube */}
                    <a
                      href={RAUNAK_BUSINESS_PROFILE.youtube}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1.5 hover:text-red-600 transition-colors"
                      title="YouTube Channel"
                    >
                      <Youtube className="w-4 h-4 text-red-600 shrink-0" />
                      <span className="font-semibold text-gray-800">
                        Raunak Pictures
                      </span>
                    </a>
                  </div>
                </div>

                {/* Receipt Metadata Badge */}
                <div className="text-right space-y-1 shrink-0">
                  <div className="inline-block px-3 py-1 bg-amber-50 text-[#8B6508] border border-amber-200 text-xs font-bold uppercase tracking-wider rounded">
                    OFFICIAL RECEIPT
                  </div>
                  <div className="text-xs text-gray-500 font-mono pt-1">
                    Receipt No: <strong className="text-gray-900 font-bold">{receiptNumber}</strong>
                  </div>
                  <div className="text-xs text-gray-500">
                    Date: <span className="font-medium text-gray-800">{currentDateFormatted}</span>
                  </div>
                  <div className="text-xs">
                    {isFullyPaid ? (
                      <span className="text-emerald-700 font-bold font-hindi">FULLY PAID (पूर्ण भुगतान)</span>
                    ) : (
                      <span className="text-amber-700 font-bold font-hindi">बाकी: {formatINR(booking.remainingAmount)}</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Bill To Customer & Booking Overview */}
              <div className="grid grid-cols-2 gap-4 p-4 rounded-lg bg-gray-50/80 border border-gray-100 text-xs">
                <div className="space-y-1">
                  <div className="font-bold text-gray-400 uppercase tracking-wider text-[10px]">
                    CLIENT DETAILS (ग्राहक का विवरण)
                  </div>
                  <div className="font-hindi text-base font-bold text-gray-900">
                    {booking.customerName}
                  </div>
                  <div className="text-gray-600 flex items-center gap-1 font-mono font-medium">
                    <Phone className="w-3 h-3 text-[#C59B27]" />
                    <span>{booking.mobile}</span>
                  </div>
                  {booking.address && (
                    <div className="text-gray-600 font-hindi flex items-start gap-1">
                      <MapPin className="w-3 h-3 text-[#C59B27] shrink-0 mt-0.5" />
                      <span>{booking.address}</span>
                    </div>
                  )}
                </div>

                <div className="space-y-1">
                  <div className="font-bold text-gray-400 uppercase tracking-wider text-[10px]">
                    EVENT DETAILS (कार्यक्रम का विवरण)
                  </div>
                  <div className="space-y-1.5 pt-0.5 font-hindi">
                    {booking.events.map((ev, i) => (
                      <div key={ev.id || i} className="text-gray-800">
                        <span className="font-bold text-gray-900">• {ev.name}:</span>{' '}
                        <span className="font-mono text-[#8B6508] font-semibold">{ev.date}</span>
                        {ev.location && <span className="text-gray-500"> ({ev.location})</span>}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Selected Services Table */}
              <div className="space-y-2">
                <div className="text-xs font-bold text-gray-800 uppercase tracking-wider border-b border-gray-200 pb-1.5 flex items-center justify-between">
                  <span>SELECTED SERVICES (चुनी गई सेवाएँ)</span>
                  <span className="text-[11px] text-gray-500 font-normal">Actual Pricing</span>
                </div>

                <div className="border border-gray-200 rounded-lg overflow-hidden">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-gray-100/80 text-gray-700 font-semibold border-b border-gray-200">
                      <tr>
                        <th className="p-2.5">#</th>
                        <th className="p-2.5">Service Description</th>
                        <th className="p-2.5 text-center">Qty</th>
                        <th className="p-2.5 text-right">Price</th>
                        <th className="p-2.5 text-right">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {booking.services.map((srv, idx) => (
                        <tr key={srv.id || idx}>
                          <td className="p-2.5 text-gray-400">{idx + 1}</td>
                          <td className="p-2.5 font-medium font-hindi text-gray-900">
                            {srv.name}
                            {srv.isMainPackage && (
                              <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 font-sans">
                                Main Package
                              </span>
                            )}
                          </td>
                          <td className="p-2.5 text-center font-mono text-gray-600">{srv.quantity}</td>
                          <td className="p-2.5 text-right font-mono text-gray-600">{formatINR(srv.price)}</td>
                          <td className="p-2.5 text-right font-mono font-bold text-gray-900">{formatINR(srv.total)}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-gray-50/70 border-t border-gray-200 font-bold">
                      <tr>
                        <td colSpan={4} className="p-2.5 text-right text-gray-700 font-hindi">
                          TOTAL BOOKING AMOUNT (कुल अनुबंध राशि):
                        </td>
                        <td className="p-2.5 text-right font-mono text-gray-900 text-sm">
                          {formatINR(booking.totalAmount)}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>

              {/* Payment History & Balances */}
              <div className="grid grid-cols-12 gap-6 pt-2">
                {/* Payment History Table (Left 7 cols) */}
                <div className="col-span-7 space-y-2">
                  <div className="text-xs font-bold text-gray-800 uppercase tracking-wider border-b border-gray-200 pb-1">
                    PAYMENT HISTORY (भुगतान इतिहास)
                  </div>
                  {booking.payments.length === 0 ? (
                    <p className="text-xs text-gray-500 font-hindi italic">कोई भुगतान रिकॉर्ड नहीं मिला।</p>
                  ) : (
                    <div className="border border-gray-200 rounded-lg overflow-hidden text-xs">
                      <table className="w-full text-left">
                        <thead className="bg-gray-100/70 text-gray-600 border-b border-gray-200">
                          <tr>
                            <th className="p-2">Date</th>
                            <th className="p-2">Method</th>
                            <th className="p-2">Reference</th>
                            <th className="p-2 text-right">Amount</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                          {booking.payments.map((p, idx) => (
                            <tr key={p.id || idx}>
                              <td className="p-2 font-mono text-gray-800">{p.date}</td>
                              <td className="p-2 text-gray-700 font-hindi">{p.method}</td>
                              <td className="p-2 text-gray-500 font-hindi truncate max-w-[120px]">
                                {p.notes || (p.isAdvance ? 'अग्रिम राशि' : '-')}
                              </td>
                              <td className="p-2 text-right font-mono font-bold text-emerald-700">
                                {formatINR(p.amount)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* Final Financial Balance Summary (Right 5 cols) */}
                <div className="col-span-5 bg-amber-50/60 border border-amber-200/80 rounded-lg p-3.5 space-y-2 text-xs">
                  <div className="font-bold text-[#8B6508] uppercase tracking-wider text-[11px] border-b border-amber-200/60 pb-1">
                    SETTLEMENT SUMMARY
                  </div>
                  <div className="space-y-1.5 pt-1">
                    <div className="flex justify-between text-gray-600">
                      <span>Total Amount:</span>
                      <span className="font-mono font-medium text-gray-900">{formatINR(booking.totalAmount)}</span>
                    </div>
                    <div className="flex justify-between text-gray-600">
                      <span>Advance Received:</span>
                      <span className="font-mono text-emerald-700 font-medium">{formatINR(booking.totalAdvance)}</span>
                    </div>
                    <div className="flex justify-between text-gray-600">
                      <span>Total Paid:</span>
                      <span className="font-mono text-emerald-700 font-bold">{formatINR(booking.totalPaid)}</span>
                    </div>
                    <div className="pt-2 border-t border-amber-200 flex justify-between items-center text-sm font-bold">
                      <span className="text-gray-900 font-hindi">बाकी राशि (Balance Due):</span>
                      <span className={`font-mono text-base ${isFullyPaid ? 'text-emerald-700' : 'text-amber-800'}`}>
                        {formatINR(booking.remainingAmount)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Terms & Authorized Signature */}
              <div className="pt-8 border-t border-gray-200 flex items-end justify-between gap-6 text-xs">
                <div className="space-y-1 text-gray-500 max-w-sm font-hindi text-[11px] leading-relaxed">
                  <div className="font-bold text-gray-700 uppercase tracking-wider text-[10px]">
                    नियम एवं शर्तें (Terms & Conditions)
                  </div>
                  <p>1. कार्यक्रम की तारीख सुरक्षित रखने हेतु अग्रिम भुगतान अनिवार्य है।</p>
                  <p>2. शेष राशि का भुगतान शूट पूर्ण होने या एल्बम डिलीवरी के समय देय होगा।</p>
                  <p className="font-bold text-[#8B6508]">Raunak Pictures को चुनने के लिए धन्यवाद!</p>
                </div>

                <div className="text-right space-y-5">
                  <div className="h-8 border-b-2 border-gray-400 w-44 ml-auto" />
                  <div className="text-[11px] font-semibold text-gray-700 leading-tight">
                    अधिकृत हस्ताक्षर (Authorized Signatory)<br />
                    <span className="font-brand font-bold text-xs text-[#0B0B0B]">RAUNAK PICTURES</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Download, Smartphone, X, CheckCircle2, Share2, Sparkles } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);

  // If already installed and running standalone as APK / PWA, don't show prompt
  if (isInstalled) {
    return (
      <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#22C55E]/15 border border-[#22C55E]/30 text-[#22C55E] text-xs font-semibold">
        <CheckCircle2 className="w-3.5 h-3.5" />
        <span>Installed</span>
      </div>
    );
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (!success) {
        setShowModal(true);
      }
    } else {
      setShowModal(true);
    }
  };

  return (
    <>
      <button
        onClick={handleInstallClick}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#22C55E] hover:bg-[#1ea750] text-[#0B0B0B] font-bold text-xs shadow-[0_0_15px_rgba(34,197,94,0.3)] transition-all active:scale-95"
        title="फोन में ऐप (APK) इनस्टॉल करें"
      >
        <Smartphone className="w-4 h-4" />
        <span>Install App</span>
      </button>

      {/* APK / PWA Installation Instructions Modal */}
      {showModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm font-hindi">
          <div className="relative w-full max-w-md bg-[#1C1C1C] border border-white/10 rounded-2xl p-6 shadow-2xl space-y-4 text-white">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full border-2 border-[#EF4444] overflow-hidden bg-black shrink-0">
                  <img src="/logo.png" alt="Raunak Pictures" className="w-full h-full object-cover" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-1.5">
                    <span>Raunak Pictures ऐप</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-[#22C55E]/20 text-[#22C55E] font-mono">
                      APK / PWA
                    </span>
                  </h3>
                  <p className="text-xs text-[#A3A3A3]">
                    अपने फोन में असली एंड्रॉयड ऐप की तरह इनस्टॉल करें
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowModal(false)}
                className="p-1 rounded-lg bg-[#151515] text-[#A3A3A3] hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 pt-2 text-xs">
              <div className="p-3.5 rounded-xl bg-[#151515] border border-white/5 space-y-2">
                <span className="font-bold text-[#F5C542] block">
                  Android फोन में इनस्टॉल कैसे करें:
                </span>
                <ol className="list-decimal list-inside space-y-1.5 text-[#D1C5AE] leading-relaxed">
                  <li>
                    अपने ब्राउज़र (Google Chrome) में ऊपर दाईं ओर <strong>तीन बिंदुओं (⋮ Menu)</strong> पर टैप करें।
                  </li>
                  <li>
                    मेन्यू में <strong>"Install app"</strong> या <strong>"Add to Home screen"</strong> चुनें।
                  </li>
                  <li>
                    <strong>"Install"</strong> पर क्लिक करें। Chrome ऑटोमैटिकली इसका <strong>WebAPK</strong> जनरेट कर आपके फोन में इनस्टॉल कर देगा!
                  </li>
                  <li>
                    ऐप सीधे आपके फोन की होमस्क्रीन और ऐप लिस्ट में आपके ओरिजिनल लोगो के साथ खुल जाएगी!
                  </li>
                </ol>
              </div>

              {isIOS && (
                <div className="p-3.5 rounded-xl bg-[#151515] border border-white/5 space-y-2">
                  <span className="font-bold text-[#F5C542] block">
                    iPhone / iPad (iOS Safari) के लिए:
                  </span>
                  <ol className="list-decimal list-inside space-y-1 text-[#D1C5AE]">
                    <li>नीचे <strong>Share</strong> बटन पर टैप करें।</li>
                    <li>नीचे स्क्रॉल करके <strong>"Add to Home Screen"</strong> चुनें।</li>
                  </ol>
                </div>
              )}
            </div>

            <div className="pt-2 flex items-center justify-end">
              <button
                onClick={() => setShowModal(false)}
                className="w-full py-2.5 rounded-lg bg-[#F5C542] hover:bg-[#DDAE30] text-[#0B0B0B] font-bold text-xs text-center transition-colors"
              >
                समझ गया (Got It)
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

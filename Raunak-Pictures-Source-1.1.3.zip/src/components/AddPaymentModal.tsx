import React, { useState } from 'react';
import { X, CreditCard, AlertCircle, Save, CheckCircle2 } from 'lucide-react';
import { Booking, PaymentMethod, PaymentItem } from '../types';
import { formatINR } from '../services/storage';

interface AddPaymentModalProps {
  booking: Booking;
  onClose: () => void;
  onSavePayment: (bookingId: string, payment: Omit<PaymentItem, 'id'>) => void;
}

export const AddPaymentModal: React.FC<AddPaymentModalProps> = ({
  booking,
  onClose,
  onSavePayment,
}) => {
  const [amount, setAmount] = useState<number | ''>(booking.remainingAmount || '');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [method, setMethod] = useState<PaymentMethod>('नकद');
  const [notes, setNotes] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const amtNum = Number(amount) || 0;
    if (amtNum <= 0) {
      setErrorMessage('कृपया 0 से अधिक वैध भुगतान राशि दर्ज करें।');
      return;
    }

    onSavePayment(booking.id, {
      date,
      amount: amtNum,
      method,
      notes: notes.trim() || undefined,
      isAdvance: false,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
      <div className="relative w-full max-w-lg bg-[#1C1C1C] border border-white/10 rounded-2xl shadow-2xl overflow-hidden font-hindi">
        {/* Header */}
        <div className="p-5 bg-[#151515] border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[#22C55E]/10 border border-[#22C55E]/30 text-[#22C55E]">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">
                नया भुगतान जोड़ें (Add Payment)
              </h3>
              <p className="text-xs text-[#A3A3A3]">
                ग्राहक: <strong className="text-white">{booking.customerName}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-[#1C1C1C] text-[#A3A3A3] hover:text-white border border-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current Balance Bar */}
        <div className="p-4 bg-[#151515]/60 border-b border-white/5 flex items-center justify-between text-xs">
          <div>
            <span className="text-[#A3A3A3]">कुल बुकिंग राशि: </span>
            <span className="font-mono text-white font-bold">{formatINR(booking.totalAmount)}</span>
          </div>
          <div>
            <span className="text-[#A3A3A3]">वर्तमान बाकी राशि: </span>
            <span className="font-mono text-[#F5C542] font-bold">{formatINR(booking.remainingAmount)}</span>
          </div>
        </div>

        {/* Hindi Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          {errorMessage && (
            <div className="p-3 rounded-lg bg-[#EF4444]/15 border border-[#EF4444]/40 text-[#EF4444] text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-[#A3A3A3] mb-1.5">
              भुगतान की राशि (₹) *
            </label>
            <input
              type="number"
              min="1"
              step="100"
              value={amount}
              onChange={e => setAmount(e.target.value === '' ? '' : Math.max(0, Number(e.target.value)))}
              placeholder="0"
              required
              className="w-full h-11 px-3.5 rounded bg-[#151515] border border-white/15 text-white font-mono font-bold text-lg focus:border-[#22C55E] focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#A3A3A3] mb-1.5">
                भुगतान की तारीख *
              </label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                required
                className="w-full h-11 px-3.5 rounded bg-[#151515] border border-white/15 text-white focus:border-[#F5C542] focus:outline-none text-xs [color-scheme:dark]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A3A3A3] mb-1.5">
                भुगतान का माध्यम *
              </label>
              <select
                value={method}
                onChange={e => setMethod(e.target.value as PaymentMethod)}
                className="w-full h-11 px-3.5 rounded bg-[#151515] border border-white/15 text-white focus:border-[#F5C542] focus:outline-none text-xs"
              >
                <option value="नकद">नकद (Cash)</option>
                <option value="UPI">UPI (PhonePe / GPay / Paytm)</option>
                <option value="बैंक">बैंक ट्रांसफर (Bank Transfer)</option>
                <option value="अन्य">अन्य</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#A3A3A3] mb-1.5">
              भुगतान से संबंधित जानकारी / नोट
            </label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="उदा. शेष राशि भुगतान, UPI रिफरेंस नंबर, चेक नंबर"
              className="w-full h-11 px-3.5 rounded bg-[#151515] border border-white/15 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none text-xs"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-lg bg-transparent border border-white/20 text-white hover:bg-white/5 text-xs font-medium transition-colors"
            >
              रद्द करें
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-lg bg-[#22C55E] hover:bg-emerald-600 text-[#0B0B0B] text-xs font-bold transition-all shadow-[0_0_15px_rgba(34,197,94,0.2)] flex items-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              <span>भुगतान सेव करें</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Plus, 
  Trash2, 
  Calendar, 
  Phone, 
  Lock, 
  DollarSign, 
  AlertCircle,
  FileSpreadsheet,
  CheckCircle2
} from 'lucide-react';
import { Booking, InternalPurchase } from '../types';
import { formatINR } from '../services/storage';

interface InternalPurchasesProps {
  purchases: InternalPurchase[];
  bookings: Booking[];
  onAddPurchase: (purchase: InternalPurchase) => void;
  onDeletePurchase: (id: string) => void;
}

export const InternalPurchases: React.FC<InternalPurchasesProps> = ({
  purchases,
  bookings,
  onAddPurchase,
  onDeletePurchase,
}) => {
  // Form state in pure Hindi
  const [name, setName] = useState('');
  const [supplierName, setSupplierName] = useState('');
  const [mobile, setMobile] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [amount, setAmount] = useState<number | ''>('');
  const [selectedBookingId, setSelectedBookingId] = useState<string>('');
  const [notes, setNotes] = useState('');

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Filter active bookings for linking
  const activeBookings = bookings.filter(b => b.status !== 'cancelled');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!name.trim()) {
      setErrorMessage('कृपया खरीद का नाम दर्ज करें।');
      return;
    }
    if (!supplierName.trim()) {
      setErrorMessage('कृपया सप्लायर का नाम दर्ज करें।');
      return;
    }
    const amtNum = Number(amount) || 0;
    if (amtNum <= 0) {
      setErrorMessage('कृपया सही खरीद राशि दर्ज करें।');
      return;
    }

    const linkedBooking = bookings.find(b => b.id === selectedBookingId);
    let linkedEventName = '';
    if (linkedBooking) {
      linkedEventName = `${linkedBooking.customerName} (${linkedBooking.events[0]?.name || 'इवेंट'})`;
    }

    const newPurchase: InternalPurchase = {
      id: 'pur-' + Date.now(),
      name: name.trim(),
      supplierName: supplierName.trim(),
      mobile: mobile.trim(),
      date,
      amount: amtNum,
      bookingId: selectedBookingId || undefined,
      eventName: linkedEventName || undefined,
      notes: notes.trim() || undefined,
      createdAt: new Date().toISOString(),
    };

    onAddPurchase(newPurchase);

    // Reset Form
    setName('');
    setSupplierName('');
    setMobile('');
    setAmount('');
    setSelectedBookingId('');
    setNotes('');
    setSuccessMessage('आंतरिक खरीद रिकॉर्ड सफलतापूर्वक जोड़ दिया गया!');
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  const totalExpense = purchases.reduce((sum, p) => sum + (p.amount || 0), 0);

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Privacy Notice Header */}
      <div className="p-4 rounded-xl bg-[#151515] border border-amber-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-[#F5C542]">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <span>आंतरिक खर्च एवं सप्लायर रिकॉर्ड</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-[#F5C542] font-normal">
                Private Business
              </span>
            </h3>
            <p className="text-xs text-[#A3A3A3] font-hindi">
              यह जानकारी केवल स्टूडियो के आंतरिक हिसाब और कैलेंडर के लिए है। ग्राहक रसीद पर यह कभी नहीं दिखेगी।
            </p>
          </div>
        </div>

        <div className="text-right pl-11 sm:pl-0">
          <div className="text-[11px] text-[#A3A3A3] uppercase">कुल दर्ज खर्च</div>
          <div className="text-xl font-bold font-mono text-[#F5C542]">
            {formatINR(totalExpense)}
          </div>
        </div>
      </div>

      {/* Hindi Form for adding purchase */}
      <div className="rounded-xl bg-[#1C1C1C] border border-white/10 p-5 sm:p-6 space-y-4 font-hindi">
        <div className="border-b border-white/10 pb-3 flex items-center justify-between">
          <h4 className="text-base font-bold text-white flex items-center gap-2">
            <ShoppingBag className="w-4 h-4 text-[#F5C542]" />
            <span>नई खरीद / सप्लायर खर्च जोड़ें</span>
          </h4>
          <span className="text-xs text-[#737373]">* अनिवार्य फ़ील्ड</span>
        </div>

        {errorMessage && (
          <div className="p-3 rounded-lg bg-[#EF4444]/15 border border-[#EF4444]/40 text-[#EF4444] text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="p-3 rounded-lg bg-[#22C55E]/15 border border-[#22C55E]/40 text-[#22C55E] text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#A3A3A3] mb-1">
                खरीद का नाम *
              </label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="उदा. कैमरा बैटरी, ड्रोन प्रोपेलर, एल्बम प्रिंटिंग"
                required
                className="w-full h-10 px-3 rounded bg-[#151515] border border-white/15 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A3A3A3] mb-1">
                सप्लायर का नाम *
              </label>
              <input
                type="text"
                value={supplierName}
                onChange={e => setSupplierName(e.target.value)}
                placeholder="उदा. गुप्ता फोटो गुड्स, सुल्तानपुर"
                required
                className="w-full h-10 px-3 rounded bg-[#151515] border border-white/15 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A3A3A3] mb-1">
                सप्लायर मोबाइल नंबर
              </label>
              <input
                type="tel"
                value={mobile}
                onChange={e => setMobile(e.target.value.replace(/\D/g, '').slice(0, 10))}
                placeholder="उदा. 9839001122"
                className="w-full h-10 px-3 rounded bg-[#151515] border border-white/15 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none text-xs font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A3A3A3] mb-1">
                खरीद की तारीख *
              </label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                required
                className="w-full h-10 px-3 rounded bg-[#151515] border border-white/15 text-white focus:border-[#F5C542] focus:outline-none text-xs [color-scheme:dark]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A3A3A3] mb-1">
                राशि (₹) *
              </label>
              <input
                type="number"
                min="0"
                step="50"
                value={amount}
                onChange={e => setAmount(e.target.value === '' ? '' : Math.max(0, Number(e.target.value)))}
                placeholder="0"
                required
                className="w-full h-10 px-3 rounded bg-[#151515] border border-white/15 text-white font-mono font-bold focus:border-[#F5C542] focus:outline-none text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A3A3A3] mb-1">
                संबंधित कार्यक्रम (Optional)
              </label>
              <select
                value={selectedBookingId}
                onChange={e => setSelectedBookingId(e.target.value)}
                className="w-full h-10 px-3 rounded bg-[#151515] border border-white/15 text-white focus:border-[#F5C542] focus:outline-none text-xs"
              >
                <option value="">सामान्य स्टूडियो खर्च (General Expense)</option>
                {activeBookings.map(b => (
                  <option key={b.id} value={b.id}>
                    {b.customerName} - {b.events[0]?.name || 'इवेंट'} ({b.events[0]?.date || ''})
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2 lg:col-span-3">
              <label className="block text-xs font-semibold text-[#A3A3A3] mb-1">
                अन्य जानकारी
              </label>
              <input
                type="text"
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="उदा. बिल नंबर, वारंटी, या उपकरण उपयोग का उद्देश्य"
                className="w-full h-10 px-3 rounded bg-[#151515] border border-white/15 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none text-xs"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-6 py-2.5 rounded-lg bg-[#F5C542] text-[#0B0B0B] font-bold text-xs sm:text-sm hover:bg-[#DDAE30] transition-colors flex items-center gap-2 shadow-[0_0_15px_rgba(245,197,66,0.15)]"
            >
              <Plus className="w-4 h-4" />
              <span>खरीद रिकॉर्ड सेव करें (Save Record)</span>
            </button>
          </div>
        </form>
      </div>

      {/* Purchases List Table */}
      <div className="rounded-xl bg-[#1C1C1C] border border-white/10 overflow-hidden font-hindi">
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between">
          <h4 className="text-base font-bold text-white">
            दर्ज आंतरिक खरीद एवं खर्च सूची ({purchases.length})
          </h4>
          <span className="text-xs text-[#737373]">
            कैलेंडर एवं संबंधित बुकिंग में स्वतः दिखाई देगा
          </span>
        </div>

        {purchases.length === 0 ? (
          <div className="p-8 text-center text-xs text-[#737373]">
            कोई आंतरिक खरीद दर्ज नहीं है। ऊपर दिए गए फ़ॉर्म से जोड़ें।
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-[#151515] text-[#A3A3A3] border-b border-white/10">
                <tr>
                  <th className="p-3">तारीख</th>
                  <th className="p-3">खरीद का नाम</th>
                  <th className="p-3">सप्लायर</th>
                  <th className="p-3">संबंधित कार्यक्रम</th>
                  <th className="p-3">अन्य विवरण</th>
                  <th className="p-3 text-right">राशि</th>
                  <th className="p-3 text-center">हटाएं</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {purchases.map(p => (
                  <tr key={p.id} className="hover:bg-white/[0.02]">
                    <td className="p-3 font-mono text-white whitespace-nowrap">{p.date}</td>
                    <td className="p-3 font-medium text-white">{p.name}</td>
                    <td className="p-3 text-[#D1C5AE]">
                      <div>{p.supplierName}</div>
                      {p.mobile && <div className="text-[11px] font-mono text-[#737373]">{p.mobile}</div>}
                    </td>
                    <td className="p-3 text-[#A3A3A3]">
                      {p.eventName ? (
                        <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10">
                          {p.eventName}
                        </span>
                      ) : (
                        <span className="text-[#737373]">सामान्य</span>
                      )}
                    </td>
                    <td className="p-3 text-[#737373] max-w-xs truncate">{p.notes || '-'}</td>
                    <td className="p-3 text-right font-mono font-bold text-[#F5C542] whitespace-nowrap">
                      {formatINR(p.amount)}
                    </td>
                    <td className="p-3 text-center">
                      <button
                        onClick={() => {
                          if (window.confirm(`क्या आप इस खरीद रिकॉर्ड "${p.name}" को हटाना चाहते हैं?`)) {
                            onDeletePurchase(p.id);
                          }
                        }}
                        className="p-1 text-[#EF4444] hover:text-red-400"
                        title="हटाएं"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-[#151515] border-t border-white/10 font-bold">
                <tr>
                  <td colSpan={5} className="p-3 text-right text-white">कुल खर्च:</td>
                  <td className="p-3 text-right font-mono text-base text-[#F5C542]">
                    {formatINR(totalExpense)}
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

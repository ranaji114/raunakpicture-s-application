import { Menu, Plus, Phone, Sparkles } from 'lucide-react';
import { ActiveTab, RAUNAK_BUSINESS_PROFILE } from '../types';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  setIsOpenMobile: (open: boolean) => void;
  logoUrl?: string | null;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  setIsOpenMobile,
  logoUrl,
}) => {
  const getTabTitle = () => {
    switch (activeTab) {
      case 'dashboard':
        return { title: 'Dashboard', subtitle: 'Overview & Studio Performance' };
      case 'new-booking':
        return { title: 'New Booking', subtitle: 'नया ग्राहक एवं कार्यक्रम पंजीकरण' };
      case 'all-bookings':
        return { title: 'All Bookings', subtitle: 'Manage Client Bookings & Schedules' };
      case 'calendar':
        return { title: 'Calendar', subtitle: 'Monthly Event Schedules & Availability' };
      case 'payments':
        return { title: 'Payments', subtitle: 'Payment Records & Revenue Tracking' };
      case 'internal-purchases':
        return { title: 'Internal Purchases', subtitle: 'Business Expenses & Supplier Records (Private)' };
      case 'cancelled-bookings':
        return { title: 'Cancelled Bookings', subtitle: 'Preserved History of Cancelled Orders' };
      case 'creator':
        return { title: 'Creator & Support', subtitle: 'App creator and bug-report contact' };
      case 'backup-restore':
        return { title: 'Backup & Restore', subtitle: 'Export and restore all studio records' };
      default:
        return { title: 'Dashboard', subtitle: 'Studio Management' };
    }
  };

  const { title, subtitle } = getTabTitle();

  return (
    <header className="sticky top-0 z-30 bg-[#0B0B0B]/90 backdrop-blur-md border-b border-white/10 px-4 sm:px-6 py-4 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <button
          onClick={() => setIsOpenMobile(true)}
          className="p-2 -ml-2 rounded-lg text-[#A3A3A3] hover:text-white hover:bg-white/5 lg:hidden"
          aria-label="Open sidebar"
        >
          <Menu className="w-6 h-6" />
        </button>

        {/* Mobile Logo Badge */}
        <div className="lg:hidden w-8 h-8 rounded-full border border-[#EF4444]/60 overflow-hidden shrink-0">
          <img
            src={logoUrl || '/assets/aistudio/logo.r_1362e06b.png'}
            alt="Logo"
            className="w-full h-full object-cover rounded-full"
          />
        </div>

        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            {title}
            {activeTab === 'new-booking' && (
              <span className="text-xs px-2 py-0.5 rounded bg-[#F5C542]/20 text-[#F5C542] border border-[#F5C542]/30 font-hindi font-normal">
                हिंदी फॉर्म
              </span>
            )}
          </h2>
          <p className="text-xs text-[#A3A3A3]">{subtitle}</p>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">

        {/* Studio Phone Tag */}
        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#151515] border border-white/10 text-xs">
          <Phone className="w-3.5 h-3.5 text-[#F5C542]" />
          <span className="text-white font-mono">{RAUNAK_BUSINESS_PROFILE.mobile}</span>
        </div>

        {/* Quick New Booking Button */}
        {activeTab !== 'new-booking' && (
          <button
            onClick={() => setActiveTab('new-booking')}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#F5C542] text-[#0B0B0B] text-xs sm:text-sm font-semibold hover:bg-[#DDAE30] active:scale-95 transition-all shadow-[0_0_15px_rgba(245,197,66,0.2)]"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">New Booking</span>
            <span className="sm:hidden">New</span>
          </button>
        )}
      </div>
    </header>
  );
};

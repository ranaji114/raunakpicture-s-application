import React, { useMemo, useState } from 'react';
import { 
  XCircle, 
  RotateCcw, 
  Eye, 
  Calendar, 
  Phone, 
  Trash2, 
  AlertOctagon,
  FileText
} from 'lucide-react';
import { Booking } from '../types';
import { formatINR } from '../services/storage';

const CANCELLED_PAGE_SIZE = 50;

interface CancelledBookingsProps {
  bookings: Booking[];
  onViewBooking: (booking: Booking) => void;
  onRestoreBooking: (id: string) => void;
  onDeletePermanently: (id: string) => void;
  onGenerateReceipt: (booking: Booking) => void;
}

export const CancelledBookings: React.FC<CancelledBookingsProps> = ({
  bookings,
  onViewBooking,
  onRestoreBooking,
  onDeletePermanently,
  onGenerateReceipt,
}) => {
  const [requestedPage, setRequestedPage] = useState(1);
  const cancelledList = useMemo(() => bookings.filter(b => b.status === 'cancelled'), [bookings]);
  const pageCount = Math.max(1, Math.ceil(cancelledList.length / CANCELLED_PAGE_SIZE));
  const currentPage = Math.min(requestedPage, pageCount);
  const visibleBookings = cancelledList.slice((currentPage - 1) * CANCELLED_PAGE_SIZE, currentPage * CANCELLED_PAGE_SIZE);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Banner */}
      <div className="p-4 rounded-xl bg-[#151515] border border-[#EF4444]/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-[#EF4444]/10 border border-[#EF4444]/30 text-[#EF4444]">
            <XCircle className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <span>Cancelled Bookings (रद्द की गई बुकिंग्स)</span>
              <span className="text-xs px-2 py-0.5 rounded bg-[#EF4444]/20 text-[#EF4444] font-mono">
                {cancelledList.length}
              </span>
            </h2>
            <p className="text-xs text-[#A3A3A3] font-hindi">
              रद्द की गई बुकिंग्स का संपूर्ण विवरण, भुगतान इतिहास एवं कारण यहाँ सुरक्षित रहता है।
            </p>
          </div>
        </div>

        <div className="text-xs text-[#737373] font-hindi pl-11 sm:pl-0">
          ये बुकिंग्स मुख्य डैशबोर्ड या एक्टिव बुकिंग्स के योग में नहीं जोड़ी जातीं।
        </div>
      </div>

      {cancelledList.length === 0 ? (
        <div className="p-12 text-center rounded-xl bg-[#1C1C1C] border border-white/10 space-y-2">
          <AlertOctagon className="w-8 h-8 text-[#737373] mx-auto" />
          <p className="text-white font-medium font-hindi text-base">कोई रद्द बुकिंग नहीं है।</p>
          <p className="text-xs text-[#737373]">
            जब कोई बुकिंग रद्द की जाती है, तो वह स्वतः यहाँ सुरक्षित रूप से स्थानांतरित हो जाती है।
          </p>
        </div>
      ) : (
        <div className="space-y-3 font-hindi">
          {visibleBookings.map(b => (
            <div
              key={b.id}
              className="p-5 rounded-xl bg-[#1C1C1C] border border-[#EF4444]/20 hover:border-[#EF4444]/40 transition-all space-y-4 shadow-sm"
            >
              {/* Header Info */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/5">
                <div className="flex items-center gap-3 flex-wrap">
                  <span className="text-xs px-2 py-0.5 rounded bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/30 font-semibold font-mono">
                    रद्द (CANCELLED)
                  </span>
                  <h3 className="font-bold text-lg text-white">
                    {b.customerName}
                  </h3>
                  <a
                    href={`tel:${b.mobile}`}
                    className="flex items-center gap-1 text-xs font-mono text-[#F5C542] hover:underline bg-[#151515] px-2 py-0.5 rounded border border-white/10"
                  >
                    <Phone className="w-3 h-3" />
                    <span>{b.mobile}</span>
                  </a>
                </div>

                <div className="text-xs text-[#EF4444] bg-[#EF4444]/10 px-3 py-1 rounded border border-[#EF4444]/20">
                  कारण: <strong className="text-white">{b.cancellationReason || 'ग्राहक अनुरोध'}</strong>
                  {b.cancelledAt && (
                    <span className="text-[#A3A3A3] ml-1.5 font-mono">
                      ({new Date(b.cancelledAt).toLocaleDateString('hi-IN')})
                    </span>
                  )}
                </div>
              </div>

              {/* Event Dates & Amounts Grid */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                <div className="md:col-span-6 space-y-1.5">
                  <span className="text-[11px] font-semibold text-[#737373] uppercase tracking-wider block">
                    कार्यक्रम एवं मूल तारीखें ({b.events.length})
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {b.events.map((ev, idx) => (
                      <div
                        key={ev.id || idx}
                        className="px-2.5 py-1 rounded bg-[#151515] border border-white/10 text-xs text-[#A3A3A3] flex items-center gap-1.5 line-through opacity-80"
                      >
                        <Calendar className="w-3 h-3 text-[#EF4444]" />
                        <span className="font-mono">{ev.date}</span>
                        <span>({ev.name})</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="md:col-span-6 grid grid-cols-2 gap-2 bg-[#151515] p-3 rounded-lg border border-white/5 text-center">
                  <div>
                    <div className="text-[10px] text-[#A3A3A3] uppercase">मूल बुकिंग राशि</div>
                    <div className="text-sm font-bold font-mono text-white mt-0.5">
                      {formatINR(b.totalAmount)}
                    </div>
                  </div>
                  <div className="border-l border-white/10">
                    <div className="text-[10px] text-[#A3A3A3] uppercase">प्राप्त अग्रिम (सुरक्षित)</div>
                    <div className="text-sm font-bold font-mono text-[#22C55E] mt-0.5">
                      {formatINR(b.totalPaid)}
                    </div>
                  </div>
                </div>
              </div>

              {/* Footer Actions */}
              <div className="pt-3 border-t border-white/5 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onViewBooking(b)}
                    className="px-3 py-1.5 rounded-lg bg-[#151515] hover:bg-white/10 text-white text-xs border border-white/10 flex items-center gap-1.5 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5 text-[#F5C542]" />
                    <span>विवरण देखें (Details)</span>
                  </button>

                  <button
                    onClick={() => onGenerateReceipt(b)}
                    className="px-3 py-1.5 rounded-lg bg-[#151515] hover:bg-white/10 text-[#A3A3A3] hover:text-white text-xs border border-white/10 flex items-center gap-1.5 transition-colors"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>रसीद रिकॉर्ड</span>
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onRestoreBooking(b.id)}
                    className="px-3 py-1.5 rounded-lg bg-[#22C55E]/15 hover:bg-[#22C55E]/25 text-[#22C55E] border border-[#22C55E]/30 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                    title="बुकिंग पुनः सक्रिय करें"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>पुनः सक्रिय करें (Restore)</span>
                  </button>

                  <button
                    onClick={() => {
                      if (window.confirm(`क्या आप इस रद्द बुकिंग "${b.customerName}" को हमेशा के लिए हटाना चाहते हैं?`)) {
                        onDeletePermanently(b.id);
                      }
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-[#EF4444]/30 bg-[#EF4444]/10 px-2.5 py-1.5 text-[11px] font-semibold text-[#EF4444] transition-colors hover:bg-[#EF4444]/20"
                    title="App + Drive से permanently हटाएं"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>App + Drive से permanently delete</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
          {pageCount > 1 && (
            <div className="flex items-center justify-between gap-3 pt-2 text-xs text-[#A3A3A3]">
              <span>Showing {(currentPage - 1) * CANCELLED_PAGE_SIZE + 1}–{Math.min(currentPage * CANCELLED_PAGE_SIZE, cancelledList.length)} of {cancelledList.length} · Page {currentPage} of {pageCount}</span>
              <div className="flex gap-2">
                <button disabled={currentPage <= 1} onClick={() => setRequestedPage(currentPage - 1)} className="rounded-lg border border-white/10 px-3 py-2 text-white disabled:opacity-40">Previous</button>
                <button disabled={currentPage >= pageCount} onClick={() => setRequestedPage(currentPage + 1)} className="rounded-lg border border-white/10 px-3 py-2 text-white disabled:opacity-40">Next</button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

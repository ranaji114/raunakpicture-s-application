import React, { useDeferredValue, useMemo, useState } from 'react';
import { 
  Search, 
  Filter, 
  Calendar, 
  Phone, 
  MapPin, 
  Eye, 
  Edit3, 
  FileText, 
  PlusCircle, 
  Trash2, 
  XCircle,
  CheckCircle,
  AlertTriangle,
  ArrowUpDown,
  EyeOff
} from 'lucide-react';
import { Booking } from '../types';
import { formatINR } from '../services/storage';

const BOOKINGS_PAGE_SIZE = 50;

interface AllBookingsProps {
  bookings: Booking[];
  onViewBooking: (booking: Booking) => void;
  onEditBooking: (booking: Booking) => void;
  onGenerateReceipt: (booking: Booking) => void;
  onAddPayment: (booking: Booking) => void;
  onCancelBooking: (booking: Booking) => void;
  onDeleteBooking: (bookingId: string) => void;
  onRemoveBookingLocally: (bookingId: string) => void;
  onNewBookingClick: () => void;
}

export const AllBookings: React.FC<AllBookingsProps> = ({
  bookings,
  onViewBooking,
  onEditBooking,
  onGenerateReceipt,
  onAddPayment,
  onCancelBooking,
  onDeleteBooking,
  onRemoveBookingLocally,
  onNewBookingClick,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'completed'>('all');
  const [sortOrder, setSortOrder] = useState<'date-asc' | 'date-desc'>('date-asc');
  const [requestedPage, setRequestedPage] = useState(1);
  const deferredSearchTerm = useDeferredValue(searchTerm);

  // Filter out cancelled bookings from this active view
  const activeBookings = useMemo(() => bookings.filter(b => b.status !== 'cancelled'), [bookings]);

  // Defer full-history search work until typing settles, then memoize it.
  const filteredBookings = useMemo(() => {
    const query = deferredSearchTerm.trim().toLowerCase();
    return activeBookings.filter(b => {
      const matchesSearch = !query ||
        b.customerName.toLowerCase().includes(query) ||
        b.mobile.includes(deferredSearchTerm.trim()) ||
        b.address.toLowerCase().includes(query) ||
        b.events.some(e => e.name.toLowerCase().includes(query) || (e.location && e.location.toLowerCase().includes(query)));

      const matchesDate = !dateFilter || b.events.some(e => e.date === dateFilter || e.date.startsWith(dateFilter));

      let matchesStatus = true;
      if (statusFilter === 'pending') {
        matchesStatus = b.remainingAmount > 0;
      } else if (statusFilter === 'completed') {
        matchesStatus = b.remainingAmount <= 0;
      }

      return matchesSearch && matchesDate && matchesStatus;
    });
  }, [activeBookings, deferredSearchTerm, dateFilter, statusFilter]);

  // Sort by event date
  const sortedBookings = useMemo(() => [...filteredBookings].sort((a, b) => {
    const dateA = a.events[0]?.date || '';
    const dateB = b.events[0]?.date || '';
    return sortOrder === 'date-asc' ? dateA.localeCompare(dateB) : dateB.localeCompare(dateA);
  }), [filteredBookings, sortOrder]);
  const pageCount = Math.max(1, Math.ceil(sortedBookings.length / BOOKINGS_PAGE_SIZE));
  const currentPage = Math.min(requestedPage, pageCount);
  const firstVisible = sortedBookings.length === 0 ? 0 : (currentPage - 1) * BOOKINGS_PAGE_SIZE + 1;
  const lastVisible = Math.min(currentPage * BOOKINGS_PAGE_SIZE, sortedBookings.length);
  const visibleBookings = useMemo(
    () => sortedBookings.slice((currentPage - 1) * BOOKINGS_PAGE_SIZE, currentPage * BOOKINGS_PAGE_SIZE),
    [sortedBookings, currentPage],
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Controls Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#151515] border border-white/10 p-4 rounded-xl">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-[#737373] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => { setSearchTerm(e.target.value); setRequestedPage(1); }}
            placeholder="Search by customer name, mobile, event, address..."
            className="w-full h-11 pl-10 pr-4 rounded-lg bg-[#1C1C1C] border border-white/10 text-white placeholder-[#525252] focus:border-[#F5C542] focus:outline-none text-sm"
          />
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3 flex-wrap sm:flex-nowrap">
          {/* Date Picker Filter */}
          <div className="flex items-center gap-2 bg-[#1C1C1C] border border-white/10 px-3 py-1.5 rounded-lg h-11">
            <Calendar className="w-4 h-4 text-[#F5C542] shrink-0" />
            <input
              type="date"
              value={dateFilter}
              onChange={e => { setDateFilter(e.target.value); setRequestedPage(1); }}
              className="bg-transparent text-white text-xs focus:outline-none [color-scheme:dark]"
              title="Filter by event date"
            />
            {dateFilter && (
              <button
                onClick={() => { setDateFilter(''); setRequestedPage(1); }}
                className="text-xs text-[#A3A3A3] hover:text-white ml-1"
                title="Clear date"
              >
                ✕
              </button>
            )}
          </div>

          {/* Payment Status Filter */}
          <select
            value={statusFilter}
            onChange={e => { setStatusFilter(e.target.value as any); setRequestedPage(1); }}
            className="h-11 px-3 rounded-lg bg-[#1C1C1C] border border-white/10 text-white text-xs focus:border-[#F5C542] focus:outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="pending">Pending Payment (बाकी)</option>
            <option value="completed">Fully Paid (पूर्ण भुगतान)</option>
          </select>

          {/* Sort Order Toggle */}
          <button
              onClick={() => { setSortOrder(sortOrder === 'date-asc' ? 'date-desc' : 'date-asc'); setRequestedPage(1); }}
            className="h-11 px-3 rounded-lg bg-[#1C1C1C] border border-white/10 text-[#A3A3A3] hover:text-white text-xs flex items-center gap-1.5 whitespace-nowrap"
            title="तारीख के अनुसार क्रम बदलें"
          >
            <ArrowUpDown className="w-3.5 h-3.5 text-[#F5C542]" />
            <span className="hidden sm:inline">
              {sortOrder === 'date-asc' ? 'Date (Asc)' : 'Date (Desc)'}
            </span>
          </button>

          {/* New Booking Button */}
          <button
            onClick={onNewBookingClick}
            className="h-11 px-4 rounded-lg bg-[#F5C542] text-[#0B0B0B] font-semibold text-xs sm:text-sm hover:bg-[#DDAE30] transition-colors whitespace-nowrap flex items-center gap-1.5 shadow-[0_0_15px_rgba(245,197,66,0.15)]"
          >
            <PlusCircle className="w-4 h-4" />
            <span>New Booking</span>
          </button>
        </div>
      </div>

      {/* Bookings Count Summary */}
      <div className="flex items-center justify-between text-xs text-[#A3A3A3] px-1">
        <span>Showing <strong className="text-white">{firstVisible}–{lastVisible}</strong> of <strong className="text-white">{sortedBookings.length}</strong> active client bookings</span>
        {searchTerm && (
          <button
            onClick={() => { setSearchTerm(''); setRequestedPage(1); }}
            className="text-[#F5C542] hover:underline"
          >
            Clear Search
          </button>
        )}
      </div>

      {/* Bookings Table / List */}
      {sortedBookings.length === 0 ? (
        <div className="p-12 text-center rounded-xl bg-[#1C1C1C] border border-white/10 space-y-3">
          <p className="text-white font-medium text-base font-hindi">कोई बुकिंग नहीं मिली।</p>
          <p className="text-xs text-[#737373]">
            {searchTerm || dateFilter
              ? 'कृपया सर्च या फ़िल्टर बदलकर पुनः प्रयास करें।'
              : 'नई बुकिंग दर्ज करने के लिए नीचे दिए गए बटन पर क्लिक करें।'}
          </p>
          <button
            onClick={onNewBookingClick}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#F5C542] text-[#0B0B0B] text-xs font-semibold"
          >
            <PlusCircle className="w-4 h-4" />
            नया ग्राहक जोड़ें
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {visibleBookings.map((b) => {
            const isFullyPaid = b.remainingAmount <= 0;
            return (
              <div
                key={b.id}
                className="rounded-xl bg-[#1C1C1C] border border-white/10 hover:border-[#F5C542]/40 transition-all p-5 shadow-sm space-y-4"
              >
                {/* Header Row: Customer, Mobile, Status Badge */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/5">
                  <div className="flex items-center gap-3 flex-wrap">
                    <h4 className="font-hindi font-bold text-lg text-white">
                      {b.customerName}
                    </h4>
                    <a
                      href={`tel:${b.mobile}`}
                      className="flex items-center gap-1.5 text-xs font-mono text-[#F5C542] hover:underline bg-[#151515] px-2.5 py-1 rounded border border-white/10"
                    >
                      <Phone className="w-3 h-3" />
                      <span>{b.mobile}</span>
                    </a>
                    {b.address && (
                      <span className="text-xs text-[#737373] flex items-center gap-1 line-clamp-1">
                        <MapPin className="w-3 h-3 text-[#A3A3A3]" />
                        <span className="font-hindi">{b.address}</span>
                      </span>
                    )}
                  </div>

                  {/* Status Badge */}
                  <div>
                    {isFullyPaid ? (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-[#22C55E]/15 text-[#22C55E] border border-[#22C55E]/30 font-hindi">
                        <CheckCircle className="w-3.5 h-3.5" />
                        पूर्ण भुगतान (Fully Paid)
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-[#F5C542]/15 text-[#F5C542] border border-[#F5C542]/30 font-hindi">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        बाकी राशि: {formatINR(b.remainingAmount)}
                      </span>
                    )}
                  </div>
                </div>

                {/* Body Row: Event Dates and Financial Details */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                  {/* Event Badges (All Dates) */}
                  <div className="md:col-span-6 space-y-1.5">
                    <span className="text-[11px] font-semibold text-[#737373] uppercase tracking-wider block font-hindi">
                      कार्यक्रम एवं तारीखें ({b.events.length})
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {b.events.map((ev, idx) => (
                        <div
                          key={ev.id || idx}
                          className="px-2.5 py-1.5 rounded-lg bg-[#151515] border border-white/10 text-xs text-white flex items-center gap-2"
                        >
                          <Calendar className="w-3.5 h-3.5 text-[#F5C542] shrink-0" />
                          <span className="font-mono font-medium text-[#F5C542]">{ev.date}</span>
                          <span className="font-hindi text-[#D1C5AE]">({ev.name})</span>
                          {ev.location && (
                            <span className="text-[11px] text-[#737373] hidden sm:inline">
                              • {ev.location}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Financials Breakdown */}
                  <div className="md:col-span-6 grid grid-cols-3 gap-2 bg-[#151515] p-3 rounded-lg border border-white/5 text-center">
                    <div>
                      <div className="text-[10px] text-[#A3A3A3] uppercase">Booking Amount</div>
                      <div className="text-sm font-bold font-mono text-white mt-0.5">
                        {formatINR(b.totalAmount)}
                      </div>
                    </div>
                    <div className="border-x border-white/10">
                      <div className="text-[10px] text-[#A3A3A3] uppercase">Advance Recd</div>
                      <div className="text-sm font-bold font-mono text-[#22C55E] mt-0.5">
                        {formatINR(b.totalPaid)}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-[#A3A3A3] uppercase">Pending Amount</div>
                      <div className={`text-sm font-bold font-mono mt-0.5 ${isFullyPaid ? 'text-[#737373]' : 'text-[#F5C542]'}`}>
                        {formatINR(b.remainingAmount)}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer Action Buttons */}
                <div className="pt-3 border-t border-white/5 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {/* View Details */}
                    <button
                      onClick={() => onViewBooking(b)}
                      className="px-3 py-1.5 rounded-lg bg-[#151515] hover:bg-white/10 text-white text-xs border border-white/10 flex items-center gap-1.5 transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5 text-[#F5C542]" />
                      <span>Details</span>
                    </button>

                    {/* Generate Receipt */}
                    <button
                      onClick={() => onGenerateReceipt(b)}
                      className="px-3 py-1.5 rounded-lg bg-[#F5C542]/10 hover:bg-[#F5C542]/20 text-[#F5C542] text-xs border border-[#F5C542]/30 flex items-center gap-1.5 font-medium transition-colors"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>Receipt (रसीद)</span>
                    </button>

                    {/* Add Payment */}
                    {b.remainingAmount > 0 && (
                      <button
                        onClick={() => onAddPayment(b)}
                        className="px-3 py-1.5 rounded-lg bg-[#22C55E]/10 hover:bg-[#22C55E]/20 text-[#22C55E] text-xs border border-[#22C55E]/30 flex items-center gap-1.5 font-medium transition-colors"
                      >
                        <PlusCircle className="w-3.5 h-3.5" />
                        <span>भुगतान जोड़ें</span>
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Edit Booking */}
                    <button
                      onClick={() => onEditBooking(b)}
                      className="p-2 rounded-lg bg-[#151515] hover:bg-white/10 text-[#A3A3A3] hover:text-white border border-white/10 text-xs transition-colors"
                      title="बुकिंग संपादित करें"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>

                    {/* Cancel Booking */}
                    <button
                      onClick={() => onCancelBooking(b)}
                      className="px-2.5 py-1.5 rounded-lg bg-[#EF4444]/10 hover:bg-[#EF4444]/20 text-[#EF4444] text-xs border border-[#EF4444]/30 flex items-center gap-1 transition-colors"
                      title="बुकिंग रद्द करें"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Cancel</span>
                    </button>

                    {/* Permanent delete from app and Drive */}
                    <button
                      onClick={() => {
                        if (window.confirm(`क्या आप वाकई "${b.customerName}" की बुकिंग को app और Google Drive backup दोनों से permanently हटाना चाहते हैं?`)) {
                          onDeleteBooking(b.id);
                        }
                      }}
                      className="px-2.5 py-1.5 rounded-lg bg-[#EF4444]/10 hover:bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/30 text-[11px] font-semibold transition-colors flex items-center gap-1.5"
                      title="App + Drive से हमेशा के लिए हटाएं"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>App + Drive से delete</span>
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm(`"${b.customerName}" की बुकिंग सिर्फ इस फोन से हटेगी। Google Drive backup में बची रहेगी और अगली successful sync पर वापस आ सकती है। जारी रखें?`)) {
                          onRemoveBookingLocally(b.id);
                        }
                      }}
                      className="px-2.5 py-1.5 rounded-lg bg-[#F5C542]/10 hover:bg-[#F5C542]/20 text-[#F5C542] border border-[#F5C542]/30 text-[11px] font-semibold transition-colors flex items-center gap-1.5"
                      title="सिर्फ इस फोन से हटाएं; Drive backup बचा रहेगा"
                    >
                      <EyeOff className="w-3.5 h-3.5" />
                      <span>Sirf phone se hatao</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
          {pageCount > 1 && (
            <div className="flex items-center justify-between gap-3 pt-2 text-xs text-[#A3A3A3]">
              <span>Page {currentPage} of {pageCount}</span>
              <div className="flex gap-2">
                <button disabled={currentPage <= 1} onClick={() => setRequestedPage(currentPage - 1)} className="rounded-lg border border-white/10 px-3 py-2 text-white disabled:opacity-40">Previous</button>
                <button disabled={currentPage >= pageCount} onClick={() => setRequestedPage(currentPage + 1)} className="rounded-lg border border-white/10 px-3 py-2 text-white disabled:opacity-40">Next</button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

import React from 'react';
import { Bug, Mail, UserRound } from 'lucide-react';

export const CreatorPage: React.FC = () => (
  <section className="max-w-3xl space-y-6">
    <div>
      <p className="text-xs uppercase tracking-[0.2em] text-[#F5C542]">About this app</p>
      <h1 className="mt-2 text-2xl sm:text-3xl font-bold text-white">Creator & Support</h1>
      <p className="mt-2 text-sm text-[#A3A3A3]">App ke creator se sampark karein ya bug report bhejein.</p>
    </div>
    <div className="rounded-2xl border border-white/10 bg-[#151515] p-6 sm:p-8 space-y-5">
      <div className="flex items-center gap-4">
        <div className="grid h-14 w-14 place-items-center rounded-full border border-[#F5C542]/40 bg-[#F5C542]/10 text-[#F5C542]">
          <UserRound className="h-7 w-7" />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-white">Ankur Rana</h2>
          <p className="text-sm text-[#A3A3A3]">App Creator</p>
        </div>
      </div>
      <div className="rounded-xl border border-white/5 bg-[#0E0E0E] p-4">
        <div className="flex items-center gap-2 text-sm font-semibold text-[#F5C542]"><Bug className="h-4 w-4" /> Bug report / feedback</div>
        <p className="mt-2 text-sm leading-relaxed text-[#D1D5DB]">Agar app mein koi dikkat dikhe, to neeche email link se detail bhejein. Email mein phone model, app mein kya kiya, aur error ka screenshot ho to zaroor attach karein.</p>
        <a href="mailto:ranaankur442@gmail.com?subject=Raunak%20Pictures%20App%20Bug%20Report" className="mt-4 inline-flex items-center gap-2 rounded-lg bg-[#F5C542] px-4 py-2.5 text-sm font-semibold text-[#0B0B0B] hover:bg-[#DDAE30]">
          <Mail className="h-4 w-4" /> ranaankur442@gmail.com
        </a>
      </div>
    </div>
  </section>
);

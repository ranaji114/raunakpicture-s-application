import React, { useMemo, useState } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  MapPin, 
  Phone, 
  Eye, 
  FileText, 
  ShoppingBag,
  AlertCircle,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { Booking, InternalPurchase } from '../types';
import { formatINR } from '../services/storage';

interface CalendarViewProps {
  bookings: Booking[];
  purchases: InternalPurchase[];
  onViewBooking: (booking: Booking) => void;
  onGenerateReceipt: (booking: Booking) => void;
  onNewBookingForDate?: (dateStr: string) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  bookings,
  purchases,
  onViewBooking,
  onGenerateReceipt,
}) => {
  // Calendar current view month/year
  const [currentDate, setCurrentDate] = useState(() => new Date());
  
  // Selected date string (YYYY-MM-DD)
  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth(); // 0-indexed

  // Month navigation
  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const goToToday = () => {
    const now = new Date();
    setCurrentDate(now);
    setSelectedDate(now.toISOString().split('T')[0]);
  };

  // Build date indexes once per data update, not on every calendar interaction.
  const eventsByDate = useMemo(() => {
    const byDate = new Map<string, Array<{ booking: Booking; event: any }>>();
    bookings.forEach(booking => {
      if (booking.status === 'cancelled') return;
      booking.events.forEach(event => {
        if (!event.date) return;
        const list = byDate.get(event.date) || [];
        list.push({ booking, event });
        byDate.set(event.date, list);
      });
    });
    return byDate;
  }, [bookings]);

  const purchasesByDate = useMemo(() => {
    const byDate = new Map<string, InternalPurchase[]>();
    purchases.forEach(purchase => {
      if (!purchase.date) return;
      const list = byDate.get(purchase.date) || [];
      list.push(purchase);
      byDate.set(purchase.date, list);
    });
    return byDate;
  }, [purchases]);

  // Month days calculation
  const firstDayOfMonth = new Date(year, month, 1).getDay(); // 0 = Sunday
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  // Days array
  const calendarCells = [];
  // Empty cells before start of month
  for (let i = 0; i < firstDayOfMonth; i++) {
    calendarCells.push(null);
  }
  // Days of month
  for (let d = 1; d <= daysInMonth; d++) {
    const dStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    calendarCells.push(dStr);
  }

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const weekDayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  // Data for the currently selected date
  const selectedDayEvents = eventsByDate.get(selectedDate) || [];
  const selectedDayPurchases = purchasesByDate.get(selectedDate) || [];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Calendar Header & Controls */}
      <div className="bg-[#151515] border border-white/10 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-[#F5C542]/10 border border-[#F5C542]/30 text-[#F5C542]">
            <CalendarIcon className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              {monthNames[month]} {year}
            </h2>
            <p className="text-xs text-[#A3A3A3] font-hindi">
              शूट कैलेंडर एवं तारीख-वार उपलब्धता
            </p>
          </div>
        </div>

        {/* Navigation & Legend */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-3 text-xs px-3 py-1.5 rounded-lg bg-[#1C1C1C] border border-white/5 mr-2 font-hindi">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#22C55E]" />
              <span className="text-[#A3A3A3]">1 बुकिंग (उपलब्ध/व्यस्त)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#EF4444]" />
              <span className="text-[#A3A3A3]">एकाधिक बुकिंग (2+ मल्टीपल)</span>
            </div>
          </div>

          <button
            onClick={goToToday}
            className="px-3 py-1.5 rounded-lg bg-[#1C1C1C] hover:bg-white/10 text-white text-xs border border-white/10 font-medium transition-colors"
          >
            Today
          </button>

          <div className="flex items-center gap-1">
            <button
              onClick={prevMonth}
              className="p-2 rounded-lg bg-[#1C1C1C] hover:bg-white/10 text-[#A3A3A3] hover:text-white border border-white/10 transition-colors"
              title="पिछला महीना"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={nextMonth}
              className="p-2 rounded-lg bg-[#1C1C1C] hover:bg-white/10 text-[#A3A3A3] hover:text-white border border-white/10 transition-colors"
              title="अगला महीना"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Calendar Grid (7 columns) */}
        <div className="lg:col-span-8 bg-[#151515] border border-white/10 rounded-xl overflow-hidden p-4 sm:p-5">
          {/* Day of week headers */}
          <div className="grid grid-cols-7 gap-1 sm:gap-2 mb-2">
            {weekDayNames.map((d, i) => (
              <div 
                key={d} 
                className={`text-center py-2 text-xs font-bold uppercase tracking-wider ${
                  i === 0 ? 'text-[#EF4444]' : 'text-[#A3A3A3]'
                }`}
              >
                {d}
              </div>
            ))}
          </div>

          {/* Day Cells */}
          <div className="grid grid-cols-7 gap-1 sm:gap-2">
            {calendarCells.map((dateStr, idx) => {
              if (!dateStr) {
                return (
                  <div 
                    key={'empty-' + idx} 
                    className="min-h-[70px] sm:min-h-[85px] rounded-lg bg-[#1C1C1C]/20 border border-transparent"
                  />
                );
              }

              const dayNum = parseInt(dateStr.split('-')[2], 10);
              const events = eventsByDate.get(dateStr) || [];
              const dayPurchases = purchasesByDate.get(dateStr) || [];
              const count = events.length;
              const isSelected = selectedDate === dateStr;
              const isToday = todayStr === dateStr;

              // Color rule according to spec:
              // - Green: One booking on that date
              // - Red: Multiple bookings on that date
              // - Normal: No booking
              let statusBadge = null;
              let borderStyle = 'border-white/5';
              let bgStyle = 'bg-[#1C1C1C]';

              if (count === 1) {
                // Green: Single booking
                borderStyle = 'border-[#22C55E]/40';
                bgStyle = 'bg-[#22C55E]/5';
                statusBadge = (
                  <div className="w-2 h-2 rounded-full bg-[#22C55E] shadow-[0_0_8px_rgba(34,197,94,0.6)]" />
                );
              } else if (count >= 2) {
                // Red: Multiple bookings
                borderStyle = 'border-[#EF4444]/60';
                bgStyle = 'bg-[#EF4444]/10';
                statusBadge = (
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 rounded-full bg-[#EF4444] animate-pulse" />
                    <span className="text-[10px] font-bold text-[#EF4444] font-mono leading-none">
                      {count}
                    </span>
                  </div>
                );
              }

              return (
                <button
                  key={dateStr}
                  onClick={() => setSelectedDate(dateStr)}
                  className={`min-h-[70px] sm:min-h-[85px] p-2 rounded-lg border text-left transition-all relative flex flex-col justify-between ${bgStyle} ${borderStyle} ${
                    isSelected
                      ? 'ring-2 ring-[#F5C542] !border-[#F5C542] shadow-[0_0_20px_rgba(245,197,66,0.15)] z-10'
                      : 'hover:border-white/30'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span
                      className={`text-xs font-mono font-bold ${
                        isToday
                          ? 'w-6 h-6 rounded-full bg-[#F5C542] text-[#0B0B0B] flex items-center justify-center font-bold'
                          : isSelected
                          ? 'text-[#F5C542]'
                          : 'text-white'
                      }`}
                    >
                      {dayNum}
                    </span>
                    {statusBadge}
                  </div>

                  {/* Micro indicator summary */}
                  <div className="mt-1 space-y-0.5">
                    {count > 0 && (
                      <p className={`text-[10px] font-hindi truncate ${
                        count >= 2 ? 'text-[#EF4444] font-bold' : 'text-[#22C55E]'
                      }`}>
                        {events[0].booking.customerName}
                      </p>
                    )}
                    {count > 1 && (
                      <p className="text-[9px] text-[#EF4444] font-bold font-hindi">
                        +{count - 1} और कार्यक्रम
                      </p>
                    )}
                    {dayPurchases.length > 0 && (
                      <div className="flex items-center gap-1 text-[9px] text-[#A3A3A3] font-mono">
                        <ShoppingBag className="w-2.5 h-2.5 text-[#F5C542]" />
                        <span>{dayPurchases.length} खरीद</span>
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Date Detail Drawer / Panel */}
        <div className="lg:col-span-4 bg-[#151515] border border-white/10 rounded-xl p-5 space-y-4">
          <div className="border-b border-white/10 pb-3">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-[#F5C542] block">
              तारीख का कार्यक्रम विवरण
            </span>
            <h3 className="text-lg font-bold text-white font-mono mt-0.5 flex items-center gap-2">
              <CalendarIcon className="w-4 h-4 text-[#F5C542]" />
              <span>{selectedDate}</span>
              {selectedDate === todayStr && (
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#F5C542]/20 text-[#F5C542] font-normal">
                  Today
                </span>
              )}
            </h3>
          </div>

          {/* Bookings on this date */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-[#A3A3A3] uppercase">
                Active Bookings ({selectedDayEvents.length})
              </span>
              {selectedDayEvents.length >= 2 && (
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/30 font-hindi font-medium flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  मल्टीपल बुकिंग अलर्ट!
                </span>
              )}
            </div>

            {selectedDayEvents.length === 0 ? (
              <div className="p-6 rounded-lg bg-[#1C1C1C] border border-white/5 text-center text-xs text-[#737373] font-hindi">
                इस तारीख पर कोई सक्रिय बुकिंग निर्धारित नहीं है।
              </div>
            ) : (
              <div className="space-y-3">
                {selectedDayEvents.map(({ booking, event }, idx) => (
                  <div
                    key={booking.id + '-' + idx}
                    className="p-4 rounded-lg bg-[#1C1C1C] border border-white/10 hover:border-[#F5C542]/40 transition-all space-y-2.5"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-[#F5C542]/10 text-[#F5C542] font-hindi">
                          {event.name}
                        </span>
                        <h4 className="font-hindi font-bold text-white text-base mt-1">
                          {booking.customerName}
                        </h4>
                      </div>
                      <span className="font-mono text-xs font-bold text-white">
                        {formatINR(booking.totalAmount)}
                      </span>
                    </div>

                    <div className="space-y-1 text-xs text-[#A3A3A3] font-hindi">
                      <a
                        href={`tel:${booking.mobile}`}
                        className="flex items-center gap-1.5 text-[#F5C542] hover:underline font-mono"
                      >
                        <Phone className="w-3 h-3" />
                        <span>{booking.mobile}</span>
                      </a>
                      {event.location && (
                        <div className="flex items-center gap-1.5 text-[#D1C5AE]">
                          <MapPin className="w-3 h-3 text-[#A3A3A3] shrink-0" />
                          <span>{event.location}</span>
                        </div>
                      )}
                      {event.notes && (
                        <div className="flex items-center gap-1.5 text-[#737373]">
                          <Clock className="w-3 h-3 shrink-0" />
                          <span>समय/नोट: {event.notes}</span>
                        </div>
                      )}
                    </div>

                    <div className="pt-2 border-t border-white/5 flex items-center justify-between text-xs">
                      <div className="text-[11px] font-hindi">
                        {booking.remainingAmount > 0 ? (
                          <span className="text-[#F5C542]">बाकी: {formatINR(booking.remainingAmount)}</span>
                        ) : (
                          <span className="text-[#22C55E]">पूर्ण भुगतान प्राप्त</span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onViewBooking(booking)}
                          className="p-1.5 rounded bg-[#151515] hover:bg-white/10 text-white text-xs border border-white/10 transition-colors"
                          title="विवरण देखें"
                        >
                          <Eye className="w-3.5 h-3.5 text-[#F5C542]" />
                        </button>
                        <button
                          onClick={() => onGenerateReceipt(booking)}
                          className="px-2 py-1 rounded bg-[#F5C542]/10 hover:bg-[#F5C542]/20 text-[#F5C542] text-xs border border-[#F5C542]/30 flex items-center gap-1 font-medium"
                          title="रसीद"
                        >
                          <FileText className="w-3 h-3" />
                          <span>रसीद</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Internal Purchases associated with this date */}
          <div className="pt-3 border-t border-white/10 space-y-2">
            <span className="text-xs font-semibold text-[#A3A3A3] uppercase flex items-center gap-1.5">
              <ShoppingBag className="w-3.5 h-3.5 text-[#F5C542]" />
              <span>Supplier & Purchase Details ({selectedDayPurchases.length})</span>
            </span>

            {selectedDayPurchases.length === 0 ? (
              <p className="text-xs text-[#737373] font-hindi">
                इस तारीख पर कोई सामग्री या सप्लायर खरीद दर्ज नहीं है।
              </p>
            ) : (
              <div className="space-y-2">
                {selectedDayPurchases.map(p => (
                  <div 
                    key={p.id}
                    className="p-2.5 rounded-lg bg-[#1C1C1C] border border-white/5 text-xs space-y-1 font-hindi"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-white">{p.name}</span>
                      <span className="font-mono text-[#F5C542] font-bold">{formatINR(p.amount)}</span>
                    </div>
                    <div className="text-[11px] text-[#A3A3A3]">
                      सप्लायर: {p.supplierName} ({p.mobile})
                    </div>
                    {p.eventName && (
                      <div className="text-[10px] text-[#737373]">
                        संबंधित: {p.eventName}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

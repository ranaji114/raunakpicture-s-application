import { Booking, InternalPurchase, PaymentItem, ServiceItem } from '../types';
import { OfflineData, isNativeRoomApp, NativeAppData } from './offlineData';

const BOOKINGS_STORAGE_KEY = 'raunak_pictures_bookings_v2';
const PURCHASES_STORAGE_KEY = 'raunak_pictures_purchases_v2';
const LOGO_STORAGE_KEY = 'raunak_pictures_custom_logo';

export async function initializeAppData(): Promise<NativeAppData> {
  if (isNativeRoomApp()) {
    const data = await OfflineData.initialize({
      legacyBookings: localStorage.getItem(BOOKINGS_STORAGE_KEY),
      legacyPurchases: localStorage.getItem(PURCHASES_STORAGE_KEY),
      legacyLogo: localStorage.getItem(LOGO_STORAGE_KEY),
    });
    // The one-time Room migration has succeeded; remove the old WebView copy so it cannot be mistaken for the source of truth.
    localStorage.removeItem(BOOKINGS_STORAGE_KEY);
    localStorage.removeItem(PURCHASES_STORAGE_KEY);
    localStorage.removeItem(LOGO_STORAGE_KEY);
    return data;
  }
  return { bookings: getBookings(), purchases: getPurchases(), customLogo: getCustomLogo() === DEFAULT_LOGO_URL ? null : getCustomLogo() };
}

export async function readAppData(): Promise<NativeAppData> {
  if (isNativeRoomApp()) return OfflineData.getData();
  return { bookings: getBookings(), purchases: getPurchases(), customLogo: getCustomLogo() === DEFAULT_LOGO_URL ? null : getCustomLogo() };
}

export interface AppBackup {
  app: 'raunak-pictures';
  schemaVersion: 1;
  createdAt: string;
  bookings: Booking[];
  purchases: InternalPurchase[];
  customLogo: string | null;
}

export async function createAppBackup(): Promise<unknown> {
  if (isNativeRoomApp()) return (await OfflineData.exportBackup()).backup;
  return {
    app: 'raunak-pictures',
    schemaVersion: 1,
    createdAt: new Date().toISOString(),
    bookings: getBookings(),
    purchases: getPurchases(),
    customLogo: localStorage.getItem(LOGO_STORAGE_KEY),
  } satisfies AppBackup;
}

export async function restoreAppBackup(value: unknown): Promise<void> {
  if (isNativeRoomApp()) {
    await OfflineData.restoreBackup({ backup: value });
    return;
  }
  if (!value || typeof value !== 'object') throw new Error('Backup file format is invalid.');
  const data = value as Partial<AppBackup>;
  if (data.app !== 'raunak-pictures' || data.schemaVersion !== 1 || !Array.isArray(data.bookings) || !Array.isArray(data.purchases)) {
    throw new Error('Yeh Raunak Pictures ka valid backup nahi hai ya version supported nahi hai.');
  }
  if (data.bookings.some(b => !b || typeof b.id !== 'string' || !Array.isArray(b.events) || !Array.isArray(b.services) || !Array.isArray(b.payments))) {
    throw new Error('Backup mein booking data adhura ya galat hai; current data nahi badla.');
  }
  if (data.purchases.some(p => !p || typeof p.id !== 'string' || typeof p.name !== 'string')) {
    throw new Error('Backup mein purchase data adhura ya galat hai; current data nahi badla.');
  }
  const oldBookings = localStorage.getItem(BOOKINGS_STORAGE_KEY);
  const oldPurchases = localStorage.getItem(PURCHASES_STORAGE_KEY);
  const oldLogo = localStorage.getItem(LOGO_STORAGE_KEY);
  try {
    localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(data.bookings));
    localStorage.setItem(PURCHASES_STORAGE_KEY, JSON.stringify(data.purchases));
    if (typeof data.customLogo === 'string') localStorage.setItem(LOGO_STORAGE_KEY, data.customLogo);
    else localStorage.removeItem(LOGO_STORAGE_KEY);
  } catch (error) {
    if (oldBookings === null) localStorage.removeItem(BOOKINGS_STORAGE_KEY); else localStorage.setItem(BOOKINGS_STORAGE_KEY, oldBookings);
    if (oldPurchases === null) localStorage.removeItem(PURCHASES_STORAGE_KEY); else localStorage.setItem(PURCHASES_STORAGE_KEY, oldPurchases);
    if (oldLogo === null) localStorage.removeItem(LOGO_STORAGE_KEY); else localStorage.setItem(LOGO_STORAGE_KEY, oldLogo);
    throw error;
  }
}

export const DEFAULT_LOGO_URL = '/assets/aistudio/logo.r_1362e06b.png';

export function getCustomLogo(): string {
  try {
    return localStorage.getItem(LOGO_STORAGE_KEY) || DEFAULT_LOGO_URL;
  } catch {
    return DEFAULT_LOGO_URL;
  }
}

export async function saveCustomLogo(url: string): Promise<void> {
  if (isNativeRoomApp()) { await OfflineData.saveCustomLogo({ value: url }); return; }
  try { localStorage.setItem(LOGO_STORAGE_KEY, url); } catch (e) { console.error('Error saving logo:', e); }
}

export const MAIN_PACKAGE_NAME = 'Main Package (Photography, Videography, Drone, Album)';
export const MAIN_PACKAGE_HINDI_NAME = 'मुख्य पैकेज (फोटोग्राफी, वीडियोग्राफी, ड्रोन, एल्बम)';

export const DEFAULT_SERVICES: Array<{ name: string; isMain?: boolean; defaultPrice: number }> = [
  { name: MAIN_PACKAGE_HINDI_NAME, isMain: true, defaultPrice: 45000 },
  { name: 'कैंडिड फोटोग्राफी (Candid Photography)', defaultPrice: 12000 },
  { name: 'सिनेमैटिक वीडियो (Cinematic Video)', defaultPrice: 15000 },
  { name: 'क्रेन / एलईडी (Crane / LED)', defaultPrice: 8000 },
  { name: 'एलईडी वॉल (LED Wall)', defaultPrice: 18000 },
  { name: 'नंबर शीट (Number Sheet)', defaultPrice: 2500 },
];

export function calculateBookingFinancials(services: ServiceItem[], payments: PaymentItem[]) {
  const totalAmount = services.reduce((sum, s) => sum + (Number(s.total) || 0), 0);
  const totalPaid = payments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
  
  // Advance payment is either marked explicitly or the first payment made at booking
  const advancePayment = payments.find(p => p.isAdvance) || (payments.length > 0 ? payments[0] : null);
  const totalAdvance = advancePayment ? Number(advancePayment.amount) || 0 : 0;
  
  const remainingAmount = Math.max(0, totalAmount - totalPaid);

  return {
    totalAmount,
    totalAdvance,
    totalPaid,
    remainingAmount,
  };
}

// Initial demo seed data to demonstrate working state immediately
const SEED_BOOKINGS: Booking[] = [
  {
    id: 'rp-book-101',
    customerName: 'अमित कुमार सिंह',
    mobile: '9838123456',
    address: 'कादीपुर रोड, निकट हनुमान मंदिर, सुल्तानपुर',
    events: [
      {
        id: 'ev-1',
        name: 'तिलक एवं संगीत',
        date: '2026-11-12',
        location: 'कादीपुर मैरिज लॉन',
        notes: 'शाम 6:00 बजे से कार्यक्रम शुरू'
      },
      {
        id: 'ev-2',
        name: 'शुभ विवाह (मुख्य समारोह)',
        date: '2026-11-14',
        location: 'रॉयल पैलेस, सुल्तानपुर',
        notes: 'बारात आगमन रात्रि 8 बजे'
      }
    ],
    services: [
      {
        id: 'srv-1',
        name: MAIN_PACKAGE_HINDI_NAME,
        quantity: 1,
        price: 50000,
        total: 50000,
        isMainPackage: true
      },
      {
        id: 'srv-2',
        name: 'कैंडिड फोटोग्राफी (Candid Photography)',
        quantity: 1,
        price: 12000,
        total: 12000
      },
      {
        id: 'srv-3',
        name: 'क्रेन / एलईडी (Crane / LED)',
        quantity: 1,
        price: 8000,
        total: 8000
      }
    ],
    payments: [
      {
        id: 'pay-1',
        date: '2026-10-15',
        amount: 25000,
        method: 'UPI',
        notes: 'बुकिंग के समय अग्रिम भुगतान (GPay)',
        isAdvance: true
      },
      {
        id: 'pay-2',
        date: '2026-11-01',
        amount: 15000,
        method: 'नकद',
        notes: 'द्वितीय किस्त प्राप्त'
      }
    ],
    totalAmount: 70000,
    totalAdvance: 25000,
    totalPaid: 40000,
    remainingAmount: 30000,
    status: 'active',
    createdAt: '2026-10-15T10:00:00.000Z',
    updatedAt: '2026-11-01T15:30:00.000Z'
  },
  {
    id: 'rp-book-102',
    customerName: 'राजेश वर्मा',
    mobile: '9450987654',
    address: 'मुड़िला बाजार, सुल्तानपुर',
    events: [
      {
        id: 'ev-3',
        name: 'सगाई एवं रिंग सेरेमनी',
        date: '2026-11-14', // Same date as Amit's wedding to showcase multi-event red alert on calendar!
        location: 'अतिथि भवन, मुड़िला',
        notes: 'दोपहर 12:00 बजे'
      }
    ],
    services: [
      {
        id: 'srv-4',
        name: MAIN_PACKAGE_HINDI_NAME,
        quantity: 1,
        price: 45000,
        total: 45000,
        isMainPackage: true
      },
      {
        id: 'srv-5',
        name: 'सिनेमैटिक वीडियो (Cinematic Video)',
        quantity: 1,
        price: 15000,
        total: 15000
      }
    ],
    payments: [
      {
        id: 'pay-3',
        date: '2026-10-20',
        amount: 20000,
        method: 'बैंक',
        notes: 'बैंक ट्रांसफर द्वारा अग्रिम',
        isAdvance: true
      }
    ],
    totalAmount: 60000,
    totalAdvance: 20000,
    totalPaid: 20000,
    remainingAmount: 40000,
    status: 'active',
    createdAt: '2026-10-20T11:20:00.000Z',
    updatedAt: '2026-10-20T11:20:00.000Z'
  },
  {
    id: 'rp-book-103',
    customerName: 'दिलीप प्रजापति',
    mobile: '8874112233',
    address: 'ग्राम पूरे बंशी, कादीपुर, सुल्तानपुर',
    events: [
      {
        id: 'ev-4',
        name: 'विवाह समारोह',
        date: '2026-11-20',
        location: 'शान वाटिका, कादीपुर',
        notes: 'संपूर्ण रात्रि कवरेज'
      }
    ],
    services: [
      {
        id: 'srv-6',
        name: MAIN_PACKAGE_HINDI_NAME,
        quantity: 1,
        price: 40000,
        total: 40000,
        isMainPackage: true
      }
    ],
    payments: [
      {
        id: 'pay-4',
        date: '2026-10-28',
        amount: 15000,
        method: 'नकद',
        notes: 'दुकान पर नकद जमा',
        isAdvance: true
      }
    ],
    totalAmount: 40000,
    totalAdvance: 15000,
    totalPaid: 15000,
    remainingAmount: 25000,
    status: 'active',
    createdAt: '2026-10-28T09:15:00.000Z',
    updatedAt: '2026-10-28T09:15:00.000Z'
  },
  {
    id: 'rp-book-104',
    customerName: 'संजय मौर्या',
    mobile: '7905114477',
    address: 'कादीपुर बाईपास, सुल्तानपुर',
    events: [
      {
        id: 'ev-5',
        name: 'हल्दी एवं मेहंदी',
        date: '2026-11-05',
        location: 'गृह निवास, कादीपुर',
        notes: 'कार्यक्रम रद्द किया गया'
      }
    ],
    services: [
      {
        id: 'srv-7',
        name: MAIN_PACKAGE_HINDI_NAME,
        quantity: 1,
        price: 35000,
        total: 35000,
        isMainPackage: true
      }
    ],
    payments: [
      {
        id: 'pay-5',
        date: '2026-10-10',
        amount: 10000,
        method: 'UPI',
        notes: 'अग्रिम राशि',
        isAdvance: true
      }
    ],
    totalAmount: 35000,
    totalAdvance: 10000,
    totalPaid: 10000,
    remainingAmount: 25000,
    status: 'cancelled',
    cancellationReason: 'ग्राहक के परिवार में तारीख आगे बढ़ाई गई',
    cancelledAt: '2026-10-25T14:00:00.000Z',
    createdAt: '2026-10-10T12:00:00.000Z',
    updatedAt: '2026-10-25T14:00:00.000Z'
  }
];

const SEED_PURCHASES: InternalPurchase[] = [
  {
    id: 'pur-1',
    name: 'कैनन कैमरा बैटरी एवं 128GB एसडी कार्ड',
    supplierName: 'गुप्ता फोटो गुड्स, सुल्तानपुर',
    mobile: '9839001122',
    date: '2026-11-10',
    amount: 4500,
    bookingId: 'rp-book-101',
    eventName: 'अमित कुमार सिंह (विवाह)',
    notes: 'मुख्य शादी शूट के लिए आवश्यक बैकअप स्टोरेज',
    createdAt: '2026-11-01T10:00:00.000Z'
  },
  {
    id: 'pur-2',
    name: 'ड्रोन प्रोपेलर सेट एवं स्पेयर केबल',
    supplierName: 'वाराणसी कैमरा हब',
    mobile: '9415223344',
    date: '2026-11-14',
    amount: 2800,
    bookingId: 'rp-book-102',
    eventName: 'राजेश वर्मा (सगाई)',
    notes: 'ड्रोन सर्विस के लिए',
    createdAt: '2026-11-02T11:00:00.000Z'
  }
];

export function getBookings(): Booking[] {
  try {
    const raw = localStorage.getItem(BOOKINGS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(SEED_BOOKINGS));
      return SEED_BOOKINGS;
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Error reading bookings:', e);
    return SEED_BOOKINGS;
  }
}

export async function saveBooking(booking: Booking): Promise<Booking> {
  if (isNativeRoomApp()) {
    const result = await OfflineData.saveBooking({ booking });
    if (!result.booking) throw new Error('Saved booking could not be read back from Room.');
    return result.booking;
  }
  const bookings = getBookings();
  const index = bookings.findIndex(b => b.id === booking.id);
  
  // recalculate financials safely
  const fin = calculateBookingFinancials(booking.services, booking.payments);
  const updatedBooking: Booking = {
    ...booking,
    totalAmount: fin.totalAmount,
    totalAdvance: fin.totalAdvance,
    totalPaid: fin.totalPaid,
    remainingAmount: fin.remainingAmount,
    updatedAt: new Date().toISOString()
  };

  if (index >= 0) {
    bookings[index] = updatedBooking;
  } else {
    bookings.unshift(updatedBooking);
  }

  localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(bookings));
  return updatedBooking;
}

export async function cancelBooking(id: string, reason: string): Promise<Booking | null> {
  if (isNativeRoomApp()) return (await OfflineData.cancelBooking({ id, reason })).booking;
  const bookings = getBookings();
  const booking = bookings.find(b => b.id === id);
  if (!booking) return null;

  booking.status = 'cancelled';
  booking.cancellationReason = reason || 'ग्राहक द्वारा अनुरोध';
  booking.cancelledAt = new Date().toISOString();
  booking.updatedAt = new Date().toISOString();

  localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(bookings));
  return booking;
}

export async function restoreBooking(id: string): Promise<Booking | null> {
  if (isNativeRoomApp()) return (await OfflineData.restoreBooking({ id })).booking;
  const bookings = getBookings();
  const booking = bookings.find(b => b.id === id);
  if (!booking) return null;

  booking.status = 'active';
  booking.cancellationReason = undefined;
  booking.cancelledAt = undefined;
  booking.updatedAt = new Date().toISOString();

  localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(bookings));
  return booking;
}

export async function deleteBooking(id: string): Promise<void> {
  if (isNativeRoomApp()) { await OfflineData.deleteBooking({ id }); return; }
  const bookings = getBookings().filter(b => b.id !== id);
  localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(bookings));
}

export async function removeBookingLocally(id: string): Promise<void> {
  if (isNativeRoomApp()) { await OfflineData.removeBookingLocally({ id }); return; }
  const bookings = getBookings().filter(b => b.id !== id);
  localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(bookings));
}

export async function addPaymentToBooking(bookingId: string, paymentData: Omit<PaymentItem, 'id'>): Promise<Booking | null> {
  if (isNativeRoomApp()) return (await OfflineData.addPayment({ bookingId, payment: paymentData })).booking;
  const bookings = getBookings();
  const booking = bookings.find(b => b.id === bookingId);
  if (!booking) return null;

  const newPayment: PaymentItem = {
    id: `pay-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    ...paymentData
  };

  booking.payments.push(newPayment);
  const fin = calculateBookingFinancials(booking.services, booking.payments);
  booking.totalAmount = fin.totalAmount;
  booking.totalAdvance = fin.totalAdvance;
  booking.totalPaid = fin.totalPaid;
  booking.remainingAmount = fin.remainingAmount;
  booking.updatedAt = new Date().toISOString();

  localStorage.setItem(BOOKINGS_STORAGE_KEY, JSON.stringify(bookings));
  return booking;
}

export function getPurchases(): InternalPurchase[] {
  try {
    const raw = localStorage.getItem(PURCHASES_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(PURCHASES_STORAGE_KEY, JSON.stringify(SEED_PURCHASES));
      return SEED_PURCHASES;
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Error reading purchases:', e);
    return SEED_PURCHASES;
  }
}

export async function savePurchase(purchase: InternalPurchase): Promise<InternalPurchase> {
  if (isNativeRoomApp()) {
    const result = await OfflineData.savePurchase({ purchase });
    if (!result.purchase) throw new Error('Saved purchase could not be read back from Room.');
    return result.purchase;
  }
  const purchases = getPurchases();
  const index = purchases.findIndex(p => p.id === purchase.id);
  if (index >= 0) {
    purchases[index] = purchase;
  } else {
    purchases.unshift(purchase);
  }
  localStorage.setItem(PURCHASES_STORAGE_KEY, JSON.stringify(purchases));
  return purchase;
}

export async function deletePurchase(id: string): Promise<void> {
  if (isNativeRoomApp()) { await OfflineData.deletePurchase({ id }); return; }
  const purchases = getPurchases().filter(p => p.id !== id);
  localStorage.setItem(PURCHASES_STORAGE_KEY, JSON.stringify(purchases));
}

export function formatINR(val: number): string {
  return '₹' + Number(val || 0).toLocaleString('en-IN');
}

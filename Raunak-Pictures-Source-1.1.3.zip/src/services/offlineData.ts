import { Capacitor, registerPlugin } from '@capacitor/core';
import type { Booking, InternalPurchase, PaymentItem } from '../types';

export interface NativeSyncStatus {
  connected: boolean;
  email?: string | null;
  pendingCount: number;
  failedCount: number;
  authRequired: boolean;
  driveFileCount?: number;
  lastError?: string | null;
  lastSyncTime?: string | null;
}

export interface NativeAppData {
  bookings: Booking[];
  purchases: InternalPurchase[];
  customLogo: string | null;
}

interface OfflineDataPlugin {
  initialize(options: { legacyBookings?: string | null; legacyPurchases?: string | null; legacyLogo?: string | null }): Promise<NativeAppData>;
  getData(): Promise<NativeAppData>;
  saveBooking(options: { booking: Booking }): Promise<{ saved: boolean; booking: Booking | null }>;
  cancelBooking(options: { id: string; reason: string }): Promise<{ saved: boolean; booking: Booking | null }>;
  restoreBooking(options: { id: string }): Promise<{ saved: boolean; booking: Booking | null }>;
  deleteBooking(options: { id: string }): Promise<{ saved: boolean }>;
  removeBookingLocally(options: { id: string }): Promise<{ saved: boolean }>;
  addPayment(options: { bookingId: string; payment: Omit<PaymentItem, 'id'> }): Promise<{ saved: boolean; booking: Booking | null }>;
  savePurchase(options: { purchase: InternalPurchase }): Promise<{ saved: boolean; purchase: InternalPurchase | null }>;
  deletePurchase(options: { id: string }): Promise<{ saved: boolean }>;
  saveCustomLogo(options: { value: string | null }): Promise<{ saved: boolean }>;
  exportBackup(): Promise<{ backup: unknown }>;
  restoreBackup(options: { backup: unknown }): Promise<{ restored: boolean }>;
  getSyncStatus(): Promise<NativeSyncStatus>;
  connectGoogle(): Promise<{ connected: boolean; email: string }>;
  disconnectGoogle(): Promise<{ connected: boolean }>;
  syncNow(): Promise<{ scheduled: boolean }>;
  restoreFromDrive(): Promise<{ restored: boolean; driveBookings: number; cancelledBookingsInApp: number; driveOtherRecords: number; bookingsInApp: number; purchasesInApp: number }>;
}

export const OfflineData = registerPlugin<OfflineDataPlugin>('OfflineData');
export const isNativeRoomApp = () => Capacitor.isNativePlatform();

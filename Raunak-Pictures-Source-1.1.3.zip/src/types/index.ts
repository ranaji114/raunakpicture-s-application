export interface BusinessProfile {
  name: string;
  owner: string;
  address: string;
  mobile: string;
  instagram: string;
  youtube: string;
  tagline: string;
}

export const RAUNAK_BUSINESS_PROFILE: BusinessProfile = {
  name: "Raunak Pictures",
  owner: "Raunak",
  address: "मुड़िला बाजार, कादीपुर रोड, सुल्तानपुर, ग्रामीण बैंक के पास",
  mobile: "6387675525",
  instagram: "@raunakpictures101",
  youtube: "https://www.youtube.com/channel/UCTt7dQQsJlpjGWiObV0q8Cg",
  tagline: "आपकी कल्पना, हमारी रचना..",
};

export interface EventItem {
  id: string;
  name: string;      // कार्यक्रम का नाम
  date: string;      // कार्यक्रम की तारीख (YYYY-MM-DD)
  location?: string;  // कार्यक्रम का स्थान
  notes?: string;     // अन्य जानकारी
}

export interface ServiceItem {
  id: string;
  name: string;       // सेवा का नाम
  quantity: number;   // मात्रा
  price: number;      // कीमत
  total: number;      // कुल राशि
  isMainPackage?: boolean; // Main package: Photography + Videography + Drone + Album
}

export type PaymentMethod = 'नकद' | 'UPI' | 'बैंक' | 'अन्य';

export interface PaymentItem {
  id: string;
  date: string;       // भुगतान की तारीख
  amount: number;     // भुगतान की राशि
  method: PaymentMethod; // भुगतान का माध्यम
  notes?: string;     // भुगतान से संबंधित जानकारी
  isAdvance?: boolean;
}

export interface InternalPurchase {
  id: string;
  name: string;         // खरीद का नाम
  supplierName: string; // सप्लायर का नाम
  mobile: string;       // मोबाइल नंबर
  date: string;         // खरीद की तारीख
  amount: number;       // राशि
  bookingId?: string;   // संबंधित बुकिंग
  eventName?: string;   // संबंधित कार्यक्रम
  notes?: string;       // अन्य जानकारी
  createdAt: string;
}

export interface Booking {
  id: string;
  customerName: string;    // ग्राहक का नाम
  mobile: string;          // मोबाइल नंबर
  address: string;         // पता
  events: EventItem[];     // Multiple events & dates
  services: ServiceItem[]; // Services & prices
  payments: PaymentItem[]; // Payment entries
  totalAmount: number;     // Total Booking Amount
  totalAdvance: number;    // Advance Received
  totalPaid: number;       // Total Payments Received
  remainingAmount: number; // Remaining Amount = Total - TotalPaid
  status: 'active' | 'cancelled' | 'completed';
  cancellationReason?: string; // रद्द करने का कारण
  cancelledAt?: string;
  createdAt: string;
  updatedAt: string;
}

export type ActiveTab = 
  | 'dashboard' 
  | 'new-booking' 
  | 'all-bookings' 
  | 'calendar' 
  | 'payments' 
  | 'internal-purchases' 
  | 'cancelled-bookings'
  | 'creator'
  | 'backup-restore';
